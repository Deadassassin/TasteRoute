import { config } from '../config.js';
import { menuItemsFrom, sameSiteMenuUrl } from './menu.js';

/**
 * The restaurant's own website.
 *
 * The only content source with no licence, no key, no quota and no brand obligation attached — and
 * for photographs and menus, frequently the only one. Restaurants publish schema.org JSON-LD and
 * OpenGraph tags precisely so that machines will read them; that is what the markup is FOR. Reading
 * it is not scraping a competitor's index, which is why this connector exists and a Yelp scraper
 * does not.
 *
 * Three rules keep it honest:
 *  - robots.txt is checked and obeyed before anything is fetched.
 *  - The response is capped and the connection is timed out; one slow venue site cannot hold up
 *    a place screen.
 *  - `aggregateRating` from a venue's own page is NEVER surfaced as a rating. A restaurant
 *    publishing 4.9 stars about itself is marketing, not a review aggregate. It is stored under
 *    `self_rating` so the fact is not lost, and the connector reports `rating: 0` so it can never
 *    reach a star row.
 */

const UA = 'GexemyBot/1.0 (+https://gexemy.space/bot)';
const PHOTO_LIMIT = 6;

const robotsCache = new Map(); // origin -> { disallow: string[], at: number }
const ROBOTS_TTL_MS = 6 * 60 * 60 * 1000;

function normaliseUrl(raw) {
  if (!raw) return null;
  try {
    const url = new URL(/^https?:\/\//i.test(raw) ? raw : `https://${raw}`);
    if (url.protocol !== 'http:' && url.protocol !== 'https:') return null;
    // Anything resolving inside the network the API itself sits on is not a restaurant's website.
    if (/^(localhost|127\.|10\.|192\.168\.|169\.254\.|\[?::1)/i.test(url.hostname)) return null;
    // Social profiles are handled as `socials`; fetching them yields a login wall, not a menu.
    if (/(facebook|instagram|twitter|x)\.com$/i.test(url.hostname)) return null;
    return url;
  } catch {
    return null;
  }
}

async function fetchText(url, { timeoutMs, maxBytes }) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      signal: controller.signal,
      redirect: 'follow',
      headers: { 'User-Agent': UA, Accept: 'text/html,application/xhtml+xml,text/plain' },
    });
    if (!res.ok) return null;
    const type = res.headers.get('content-type') ?? '';
    if (type && !/text\/html|text\/plain|xhtml/i.test(type)) return null;

    // Streamed with a hard ceiling rather than res.text(): a misconfigured server advertising a
    // 200 MB body would otherwise be read into memory in full before anyone noticed.
    const reader = res.body?.getReader();
    if (!reader) return null;
    const chunks = [];
    let size = 0;
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      size += value.length;
      chunks.push(value);
      if (size > maxBytes) { await reader.cancel().catch(() => {}); break; }
    }
    return Buffer.concat(chunks).toString('utf8');
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

/** Minimal robots.txt: the rules for `*` and for us. Anything unparseable is treated as allow-all. */
async function allowedByRobots(url) {
  const origin = url.origin;
  const cached = robotsCache.get(origin);
  const now = Date.now();
  if (!cached || now - cached.at > ROBOTS_TTL_MS) {
    const body = await fetchText(new URL('/robots.txt', origin), { timeoutMs: 3_000, maxBytes: 60_000 });
    const disallow = [];
    if (body) {
      let applies = false;
      for (const line of body.split(/\r?\n/)) {
        const text = line.split('#')[0].trim();
        if (!text) continue;
        const [rawKey, ...rest] = text.split(':');
        const key = rawKey.trim().toLowerCase();
        const value = rest.join(':').trim();
        if (key === 'user-agent') {
          applies = value === '*' || value.toLowerCase() === 'gexemybot';
        } else if (applies && key === 'disallow' && value) {
          disallow.push(value);
        } else if (applies && key === 'allow' && value === '/') {
          // An explicit blanket Allow outranks a blanket Disallow in the same group.
          disallow.length = 0;
        }
      }
    }
    robotsCache.set(origin, { disallow, at: now });
  }
  const rules = robotsCache.get(origin).disallow;
  return !rules.some((rule) => rule === '/' || url.pathname.startsWith(rule));
}

/** Every JSON-LD block on the page, flattened through @graph and arrays. */
function jsonLdNodes(html) {
  const out = [];
  const re = /<script[^>]+type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi;
  for (const m of html.matchAll(re)) {
    let parsed;
    // Venue sites ship malformed JSON-LD constantly — trailing commas, stray newlines in strings,
    // HTML comments wrapped around the block. One bad block must not lose the others.
    try { parsed = JSON.parse(m[1].trim().replace(/^<!--/, '').replace(/-->$/, '')); } catch { continue; }
    const queue = Array.isArray(parsed) ? [...parsed] : [parsed];
    while (queue.length) {
      const node = queue.shift();
      if (!node || typeof node !== 'object') continue;
      if (Array.isArray(node['@graph'])) queue.push(...node['@graph']);
      out.push(node);
    }
  }
  return out;
}

const TYPES = /restaurant|foodestablishment|cafe|bar|bakery|localbusiness|store|organization/i;

/**
 * The three things nearly every restaurant site has that are NOT in JSON-LD or OpenGraph.
 *
 * Plenty of venues publish no structured data at all but still put their number in a click-to-call
 * link and their identity in the <title> — Katz's Delicatessen is exactly that shape. Reading these
 * costs three regexes and turns "we know nothing about this place" into a name and a phone number.
 */
function pageBasics(html) {
  const title = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1];
  const tel = html.match(/href=["']tel:([^"']{4,40})["']/i)?.[1];
  const mail = html.match(/href=["']mailto:([^"'?]{5,80})["']/i)?.[1];
  return {
    title: title ? decodeEntities(title).replace(/\s+/g, ' ').trim() : null,
    tel: tel ? decodeEntities(tel).trim() : null,
    email: mail ? decodeEntities(mail).trim() : null,
  };
}

const typeOf = (node) => [].concat(node['@type'] ?? []).join(' ');

const asArray = (v) => (v == null ? [] : Array.isArray(v) ? v : [v]);

/** schema.org images arrive as a string, an ImageObject, or a list of either. */
function imagesFrom(node) {
  return asArray(node.image)
    .map((i) => (typeof i === 'string' ? i : i?.url ?? i?.contentUrl))
    .filter((u) => typeof u === 'string' && /^https?:\/\//i.test(u));
}

const ENTITIES = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ', '#39': "'", '#x27': "'" };

/** Meta content is HTML-escaped by definition, so an undecoded value reaches the UI as `&#39;`. */
function decodeEntities(text) {
  return String(text).replace(/&(#x?[0-9a-f]+|\w+);/gi, (whole, body) => {
    const key = body.toLowerCase();
    if (ENTITIES[key] != null) return ENTITIES[key];
    if (key[0] === '#') {
      const code = key[1] === 'x' ? parseInt(key.slice(2), 16) : parseInt(key.slice(1), 10);
      return Number.isFinite(code) && code > 0 && code < 0x110000 ? String.fromCodePoint(code) : whole;
    }
    return whole;
  });
}

/**
 * BACKREFERENCE THE OPENING QUOTE — do not go back to a `[^"']*` character class.
 *
 * That excludes BOTH quote characters regardless of which one actually delimits the attribute, so
 * `content="Katz's Delicatessen"` captured exactly `Katz`. Restaurant names are full of
 * apostrophes, so this silently truncated a large share of every summary, name and caption while
 * looking like the sites simply had short descriptions.
 */
function metaTags(html) {
  const out = {};
  const re = /<meta\s+[^>]*?(?:property|name)=(["'])(.*?)\1[^>]*?content=(["'])(.*?)\3[^>]*>/gi;
  // FIRST occurrence wins, not the last. The canonical metadata is in <head>; storefront and
  // widget scripts inject their own og: tags further down the body, and overwriting meant a page
  // whose head said "A New York institution since 1888" reported "Katz's Deli Shipping Menu".
  for (const m of html.matchAll(re)) out[m[2].toLowerCase()] ??= decodeEntities(m[4]);
  // Attribute order is not fixed: plenty of sites emit content= before property=.
  const alt = /<meta\s+[^>]*?content=(["'])(.*?)\1[^>]*?(?:property|name)=(["'])(.*?)\3[^>]*>/gi;
  for (const m of html.matchAll(alt)) out[m[4].toLowerCase()] ??= decodeEntities(m[2]);
  return out;
}

/** "Mo,Tu 11:00-22:00" from openingHoursSpecification, which is far tidier than most sites' prose. */
function hoursText(node) {
  const spec = asArray(node.openingHoursSpecification);
  if (spec.length) {
    return spec.map((s) => {
      const days = asArray(s.dayOfWeek).map((d) => String(d).split('/').pop()).join(', ');
      if (!days) return null;
      return s.opens && s.closes ? `${days} ${s.opens}-${s.closes}` : `${days} closed`;
    }).filter(Boolean).slice(0, 7);
  }
  const plain = asArray(node.openingHours).filter((h) => typeof h === 'string');
  return plain.length ? plain.slice(0, 7) : null;
}

export const connector = {
  name: 'website',
  label: 'the venue',
  url: '',
  /** No brand obligation: this is the restaurant's own published markup about itself. */
  requiresLogo: false,
  /** A venue with nothing to link to is still worth showing — its own site IS the link. */
  requiresLink: false,
  enabled: () => config.websiteHarvest,
  ttlHours: () => config.websiteTtlHours,
  detailOnly: () => false,
  batchLookups: () => config.websiteBatchLookups,

  async lookup({ website, name, detail = false }) {
    const url = normaliseUrl(website);
    if (!url) return null;
    if (!(await allowedByRobots(url))) return null;

    const html = await fetchText(url, {
      timeoutMs: config.websiteTimeoutMs,
      maxBytes: config.websiteMaxBytes,
    });
    // Undefined, not null: a site that timed out today may answer tomorrow, and caching a miss
    // would stop us asking again for a fortnight.
    if (html === null) return undefined;

    const nodes = jsonLdNodes(html);
    const node = nodes.find((n) => TYPES.test(typeOf(n))) ?? {};
    const meta = metaTags(html);
    const basics = pageBasics(html);

    const photos = [...imagesFrom(node), meta['og:image'], meta['twitter:image']]
      .filter(Boolean)
      .map((u) => { try { return new URL(u, url).toString(); } catch { return null; } })
      .filter(Boolean);
    const unique = [...new Set(photos)].slice(0, PHOTO_LIMIT).map((u) => ({
      url: u,
      caption: '',
      credit: `${url.hostname}`,
      credit_url: url.origin,
    }));

    const socials = {};
    for (const link of asArray(node.sameAs).filter((s) => typeof s === 'string')) {
      if (/instagram\.com/i.test(link)) socials.instagram ??= link;
      else if (/facebook\.com/i.test(link)) socials.facebook ??= link;
      else if (/(twitter|x)\.com/i.test(link)) socials.x ??= link;
      else if (/tiktok\.com/i.test(link)) socials.tiktok ??= link;
    }

    const menu = node.hasMenu ?? node.menu;
    const menuUrl = typeof menu === 'string' ? menu : menu?.url ?? null;
    const address = node.address;
    const selfRating = node.aggregateRating?.ratingValue;

    // Dishes the venue itself published. See menu.js for why nothing else counts as one.
    let dishes = menuItemsFrom(nodes);

    /*
     * The menu is usually its own page: the home page carries identity and links out to it. That
     * second fetch is spent ONLY when someone has opened the place — a feed of twenty cards never
     * pays for it — and the result is cached for the whole website TTL, so the next feed to show
     * this venue gets its dishes for free. Menu harvesting being slow was the complaint; doing it
     * once per venue a fortnight, off the path a feed waits on, is the fix.
     */
    if (!dishes.length && detail && config.websiteMenuFollow) {
      const target = sameSiteMenuUrl(menuUrl, url);
      if (target && (await allowedByRobots(target))) {
        const menuHtml = await fetchText(target, {
          timeoutMs: config.websiteMenuTimeoutMs,
          maxBytes: config.websiteMenuMaxBytes,
        });
        if (menuHtml) dishes = menuItemsFrom(jsonLdNodes(menuHtml));
      }
    }

    return {
      externalId: url.hostname,
      name: decodeEntities(node.name ?? meta['og:site_name'] ?? meta['og:title'] ?? basics.title ?? name ?? url.hostname),
      // Deliberately 0. See the note at the top: a venue's own aggregateRating is a marketing
      // claim and must never reach a star row, however tempting a populated number looks.
      rating: 0,
      reviewCount: 0,
      price: typeof node.priceRange === 'string' ? (node.priceRange.match(/\$+/)?.[0] ?? '') : '',
      url: url.toString(),
      imageUrl: unique[0]?.url ?? null,
      categories: asArray(node.servesCuisine).filter((c) => typeof c === 'string').slice(0, 6),
      facts: {
        website: url.toString(),
        phone: node.telephone ?? basics.tel ?? null,
        email: (typeof node.email === 'string' ? node.email : null) ?? basics.email,
        menu: menuUrl,
        // Real dish names, straight from the venue's own MenuItem markup. The client shows one as
        // "On the menu"; when this is empty it shows a suggestion and labels it as a suggestion.
        menu_items: dishes.length ? dishes : null,
        address: typeof address === 'string'
          ? address
          : [address?.streetAddress, address?.addressLocality, address?.postalCode]
              .filter(Boolean).join(', ') || null,
        hours_text: hoursText(node),
        summary: decodeEntities(node.description ?? meta['og:description'] ?? meta.description ?? basics.title ?? '') || null,
        cuisines: asArray(node.servesCuisine).filter((c) => typeof c === 'string').slice(0, 6),
        price_range: typeof node.priceRange === 'string' ? node.priceRange : null,
        service: {
          reservable: typeof node.acceptsReservations === 'boolean'
            ? node.acceptsReservations
            : node.acceptsReservations === 'True' ? true : null,
        },
        socials: Object.keys(socials).length ? socials : null,
        // Kept, clearly named, and never rendered as a rating.
        self_rating: Number.isFinite(Number(selfRating)) ? Number(selfRating) : null,
      },
      photos: unique,
      reviews: [],
    };
  },
};
