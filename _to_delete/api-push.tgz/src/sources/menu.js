/**
 * Dishes, from the restaurant's own schema.org markup and from nowhere else.
 *
 * THE RULE THIS FILE EXISTS TO ENFORCE: a dish name we show as being on a menu must be a dish the
 * venue itself published as a `MenuItem`. No heuristics over page text, no "biggest <h3> in a div
 * whose class contains 'menu'", no guessing from the cuisine tag. The app already has a perfectly
 * good way to suggest a dish it is not sure about — it labels it as a suggestion (see DishPicks on
 * the client). Anything harvested here is presented as fact, so it has to be one.
 *
 * That is also why yield will be low and must be allowed to stay low. Most restaurant sites render
 * their menu as a PDF, an image, or a third-party ordering widget, and none of those produce
 * structured data. An empty list is the correct answer for those, forever.
 */

const NAME_MIN = 2;
const NAME_MAX = 60;
const ITEM_LIMIT = 12;
const DEPTH_LIMIT = 8;

const asArray = (v) => (v == null ? [] : Array.isArray(v) ? v : [v]);
const typeOf = (node) => [].concat(node?.['@type'] ?? []).join(' ');

/**
 * Section headings and CMS filler that arrive typed as menu content.
 *
 * Sites mark up their sections as MenuItem constantly, so without this the "dish" surfaced for
 * half of them is the word "Desserts" — which reads, on a card, as the restaurant's signature
 * offering being a category name.
 */
const NOT_A_DISH = new RegExp(
  '^(menus?|drinks?|beverages?|food|dishes|starters?|appetiz(er|ers)|small plates|mains?|entr[ée]es?|' +
  'sides?|desserts?|specials?|lunch|dinner|brunch|breakfast|kids|children|extras?|add[- ]?ons?|' +
  'sauces?|toppings?|sets?|combos?|platters?|available|see (more|menu)|view menu|order( online)?|' +
  'coming soon|tbd|n/?a|item|items|new|popular|featured|all)$',
  'i',
);

/** A name that is mostly digits and punctuation is a price row or an SKU, not a dish. */
const MOSTLY_NOISE = /^[^a-z]*$/i;

function clean(raw) {
  if (typeof raw !== 'string') return null;
  const name = raw.replace(/\s+/g, ' ').trim();
  if (name.length < NAME_MIN || name.length > NAME_MAX) return null;
  if (NOT_A_DISH.test(name)) return null;
  if (MOSTLY_NOISE.test(name)) return null;
  // A dish name with a sentence in it is a description that was put in the wrong field.
  if ((name.match(/[.!?]/g) ?? []).length > 1) return null;
  return name;
}

/**
 * Every `MenuItem` reachable from a set of already-flattened JSON-LD nodes.
 *
 * `itemListElement` is followed ONLY once we are inside a menu. It is also how breadcrumbs, site
 * navigation and product carousels are marked up, and pulling those in would put "Contact Us" on a
 * restaurant card as its recommended dish.
 */
export function menuItemsFrom(nodes) {
  const out = [];
  const seen = new Set();

  const take = (raw) => {
    const name = clean(raw);
    if (!name) return;
    const key = name.toLowerCase();
    if (seen.has(key)) return;
    seen.add(key);
    out.push(name);
  };

  const walk = (node, depth, inMenu) => {
    if (!node || typeof node !== 'object' || depth > DEPTH_LIMIT || out.length >= ITEM_LIMIT) return;
    const type = typeOf(node);
    const here = inMenu || /\bmenu\b|menusection|menuitem/i.test(type);
    if (/menuitem/i.test(type)) take(node.name);

    for (const key of ['hasMenu', 'menu', 'hasMenuSection', 'hasMenuItem']) {
      for (const child of asArray(node[key])) {
        // `hasMenu` is frequently just a URL to the menu page — that is handled by the caller,
        // which may fetch it; there is nothing to walk here.
        if (child && typeof child === 'object') walk(child, depth + 1, true);
      }
    }
    // Items listed directly under hasMenuItem are dishes whatever they call themselves.
    for (const child of asArray(node.hasMenuItem)) {
      if (child && typeof child === 'object') take(child.name);
      else take(child);
    }
    if (here) {
      for (const child of asArray(node.itemListElement)) {
        if (child && typeof child === 'object') {
          walk(/listitem/i.test(typeOf(child)) && child.item ? child.item : child, depth + 1, true);
        }
      }
    }
  };

  for (const node of nodes) walk(node, 0, false);
  return out.slice(0, ITEM_LIMIT);
}

/**
 * The URL a venue points at for its menu, if it is worth fetching.
 *
 * Restricted to the venue's own domain on purpose. Most sites link their menu out to an ordering
 * platform — Toast, Square, ChowNow — and those pages are client-rendered, usually disallow bots,
 * and are somebody else's property rather than the restaurant's own publication. Following them
 * would be scraping a third party, which is the line this project has already drawn and kept.
 */
export function sameSiteMenuUrl(rawMenu, pageUrl) {
  if (typeof rawMenu !== 'string' || !rawMenu) return null;
  // `hasMenu` is a free-text field in practice — "Our menu changes daily" is a real value people
  // put there. Resolved against the page it becomes a plausible-looking relative path, so require
  // it to actually look like a URL before treating it as one.
  if (!/^(https?:)?\/\/|^\.{0,2}\//i.test(rawMenu)) return null;
  let url;
  try {
    url = new URL(rawMenu, pageUrl);
  } catch {
    return null;
  }
  if (url.protocol !== 'https:' && url.protocol !== 'http:') return null;
  const host = url.hostname.replace(/^www\./i, '').toLowerCase();
  const base = pageUrl.hostname.replace(/^www\./i, '').toLowerCase();
  if (host !== base && !host.endsWith(`.${base}`)) return null;
  // Already read it.
  if (url.toString() === pageUrl.toString()) return null;
  // A PDF or an image menu has nothing machine-readable in it, and fetching it wastes the budget.
  if (/\.(pdf|jpe?g|png|webp|gif|docx?)$/i.test(url.pathname)) return null;
  return url;
}
