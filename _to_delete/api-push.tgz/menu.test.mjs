import { menuItemsFrom, sameSiteMenuUrl } from '../src/sources/menu.js';

let fail = 0;
const eq = (name, got, want) => {
  const ok = JSON.stringify(got) === JSON.stringify(want);
  if (!ok) fail++;
  console.log(`${ok ? 'ok  ' : 'BAD '} ${name}\n     got  ${JSON.stringify(got)}${ok ? '' : `\n     want ${JSON.stringify(want)}`}`);
};

// 1. The common shape: Restaurant -> hasMenu -> hasMenuSection -> hasMenuItem
eq('restaurant with a full inline menu', menuItemsFrom([{
  '@type': 'Restaurant', name: "Katz's",
  hasMenu: { '@type': 'Menu', hasMenuSection: [
    { '@type': 'MenuSection', name: 'Sandwiches', hasMenuItem: [
      { '@type': 'MenuItem', name: 'Pastrami on Rye' },
      { '@type': 'MenuItem', name: 'Corned Beef' },
    ]},
    { '@type': 'MenuSection', name: 'Sides', hasMenuItem: [{ '@type': 'MenuItem', name: 'Half Sour Pickles' }]},
  ]},
}]), ['Pastrami on Rye', 'Corned Beef', 'Half Sour Pickles']);

// 2. A dedicated menu page: the Menu is the top-level node.
eq('standalone menu page', menuItemsFrom([
  { '@type': 'Menu', name: 'Dinner', hasMenuSection: { '@type': 'MenuSection', name: 'Mains',
      hasMenuItem: [{ '@type': 'MenuItem', name: 'Green Curry' }, { '@type': 'MenuItem', name: 'Khao Soi' }] } },
]), ['Green Curry', 'Khao Soi']);

// 3. Sections marked up as MenuItem — the failure mode that puts "Desserts" on a card.
eq('section headings rejected', menuItemsFrom([{ '@type': 'Menu', hasMenuItem: [
  { '@type': 'MenuItem', name: 'Desserts' }, { '@type': 'MenuItem', name: 'DRINKS' },
  { '@type': 'MenuItem', name: 'Order Online' }, { '@type': 'MenuItem', name: 'Tiramisu' },
]}]), ['Tiramisu']);

// 4. Breadcrumbs and product carousels must not leak in.
eq('breadcrumbs ignored', menuItemsFrom([
  { '@type': 'BreadcrumbList', itemListElement: [
    { '@type': 'ListItem', item: { '@type': 'WebPage', name: 'Contact Us' } },
    { '@type': 'ListItem', item: { '@type': 'WebPage', name: 'About' } },
  ]},
  { '@type': 'Restaurant', name: 'X' },
]), []);

// 5. ItemList INSIDE a menu is a real dish list.
eq('itemListElement inside a menu', menuItemsFrom([{ '@type': 'Menu', itemListElement: [
  { '@type': 'ListItem', item: { '@type': 'MenuItem', name: 'Bibimbap' } },
  { '@type': 'MenuItem', name: 'Bulgogi' },
]}]), ['Bibimbap', 'Bulgogi']);

// 6. Duplicates, whitespace, junk.
eq('dedupe and clean', menuItemsFrom([{ '@type': 'Menu', hasMenuItem: [
  { '@type': 'MenuItem', name: '  Pad   Thai ' }, { '@type': 'MenuItem', name: 'PAD THAI' },
  { '@type': 'MenuItem', name: '$$$' }, { '@type': 'MenuItem', name: 'x' },
  { '@type': 'MenuItem', name: 'A very long description masquerading as a dish name. It has sentences. Several.' },
  { '@type': 'MenuItem', name: 'Som Tam' },
]}]), ['Pad Thai', 'Som Tam']);

// 7. Strings directly under hasMenuItem.
eq('bare string dishes', menuItemsFrom([{ '@type': 'Menu', hasMenuItem: ['Margherita', 'Marinara'] }]),
   ['Margherita', 'Marinara']);

// 8. Cap.
eq('capped at 12', menuItemsFrom([{ '@type': 'Menu',
  hasMenuItem: Array.from({ length: 30 }, (_, i) => ({ '@type': 'MenuItem', name: `Dish ${String.fromCharCode(97 + i)}` })) }]).length, 12);

// 9. Nothing at all.
eq('no markup', menuItemsFrom([{ '@type': 'Restaurant', name: 'X', hasMenu: 'https://x.com/menu' }]), []);

const page = new URL('https://katzsdelicatessen.com/');
const su = (v) => { const r = sameSiteMenuUrl(v, page); return r ? r.toString() : null; };
eq('menu url: relative',        su('/menu'), 'https://katzsdelicatessen.com/menu');
eq('menu url: same host',       su('https://katzsdelicatessen.com/menus/deli'), 'https://katzsdelicatessen.com/menus/deli');
eq('menu url: www variant',     su('https://www.katzsdelicatessen.com/menu'), 'https://www.katzsdelicatessen.com/menu');
eq('menu url: subdomain',       su('https://order.katzsdelicatessen.com/menu'), 'https://order.katzsdelicatessen.com/menu');
eq('menu url: third party',     su('https://www.toasttab.com/katzs/menu'), null);
eq('menu url: pdf',             su('/menu.pdf'), null);
eq('menu url: image',           su('/assets/menu.JPG'), null);
eq('menu url: same page',       su('https://katzsdelicatessen.com/'), null);
eq('menu url: prose',           su('Our menu changes daily'), null);
eq('menu url: relative dot',    su('./menu/'), 'https://katzsdelicatessen.com/menu/');
eq('menu url: protocol-rel',    su('//katzsdelicatessen.com/menu'), 'https://katzsdelicatessen.com/menu');
eq('menu url: null',            su(null), null);

console.log(fail ? `\n${fail} failure(s)` : '\nall menu cases pass');
process.exit(fail ? 1 : 0);
