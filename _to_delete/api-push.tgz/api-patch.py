#!/usr/bin/env python3
"""1.2.2 -> 1.3.0: the three small edits that go alongside the two new/replaced source files."""
import os
import sys

ROOT = os.path.expanduser("~/apisrc/accounts-api")
fails = []


def patch(rel, old, new, count=1):
    p = os.path.join(ROOT, rel)
    s = open(p, encoding="utf-8").read()
    if s.count(old) != count:
        fails.append(f"{rel}: found {s.count(old)} :: {old.strip().splitlines()[0][:60]}")
        return
    open(p, "w", encoding="utf-8").write(s.replace(old, new))


patch("package.json", '"version": "1.2.2"', '"version": "1.3.0"')

patch("src/config.js",
      "  websiteBatchLookups: num(process.env.WEBSITE_BATCH_LOOKUPS, 6),",
      """  websiteBatchLookups: num(process.env.WEBSITE_BATCH_LOOKUPS, 6),
  // A venue's menu is nearly always its own page rather than markup on the home page. Following
  // that one link is the difference between harvesting dishes and never harvesting any — but it
  // is spent ONLY on an opened place, never across a feed, and the result is cached for the whole
  // website TTL. A venue costs one extra fetch a fortnight, not one a scroll.
  websiteMenuFollow: process.env.WEBSITE_MENU_FOLLOW !== 'off',
  websiteMenuTimeoutMs: num(process.env.WEBSITE_MENU_TIMEOUT_MS, 4_000),
  websiteMenuMaxBytes: num(process.env.WEBSITE_MENU_MAX_BYTES, 700_000),""")

patch("src/index.js",
      """  // Open place catalog (Foursquare OS Places / Overture) folded into /v1/places/nearby.
  'catalog',
];""",
      """  // Open place catalog (Foursquare OS Places / Overture) folded into /v1/places/nearby.
  'catalog',
  // Real dish names, harvested from a venue's own schema.org MenuItem markup, in facts.menu_items.
  // The app checks for this before it decides whether a dish line may say "On the menu".
  'menus',
];""")

if fails:
    print("FAILED")
    for f in fails:
        print("  -", f)
    sys.exit(1)
print("api patched to 1.3.0")
