#!/usr/bin/env python3
"""NimClient: ground the conversation in the app's own place list, let it cite them by number,
and stream the reply instead of printing it in one go."""
import os
import sys

PATH = os.path.expanduser(
    "~/mnt/TasteRoute/app/src/main/java/space/gexemy/tasteroute/data/NimClient.kt")
src = open(PATH, encoding="utf-8").read()
failures = []


def sub(old, new, count=1):
    global src
    found = src.count(old)
    if found != count:
        failures.append(f"expected {count}, found {found} :: {old.strip().splitlines()[0][:70]}")
        return
    src = src.replace(old, new)


# ------------------------------------------------------------- the turn shape
sub('''@Serializable
data class AssistantTurn(
    val say: String = "",
    val search: String = "",
    /** Set only when the person states a lasting preference worth saving to their profile. */
    val profile: ParsedTaste? = null,
)''', '''@Serializable
data class AssistantTurn(
    val say: String = "",
    val search: String = "",
    /**
     * 1-based indices into the nearby list the model was shown. It never produces a name, an
     * address or a rating for a place — only a number, which the app resolves back to the real
     * object it already had. That is the whole reason it is allowed to talk about venues at all.
     */
    val places: List<Int> = emptyList(),
    /** Set only when the person states a lasting preference worth saving to their profile. */
    val profile: ParsedTaste? = null,
)''')

# ------------------------------------------------------------- converse()
sub('''    suspend fun converse(
        history: List<ChatTurn>,
        profile: TasteProfile,
        allergens: List<String>,
        cityLabel: String?,
    ): AssistantTurn {
        val messages = buildList {
            add(Msg("system", conversationSystemPrompt(profile, allergens, cityLabel)))
            history.takeLast(CHAT_HISTORY_TURNS).forEach {
                add(Msg(if (it.fromUser) "user" else "assistant", it.text.take(600)))
            }
        }
        val json = chat(
            messages = messages,
            maxTokens = CHAT_TOKENS,
            connectTimeoutMs = RANK_CONNECT_MS,
            readTimeoutMs = CHAT_TIMEOUT_MS,
            // Ranking wants the same answer every time. A conversation that answers identically
            // twice reads as a phone tree.
            temperature = 0.6,
            backoffKey = Backoff.CHAT,
            // A conversation that answers in plain sentences has answered. Demanding JSON here
            // threw away good replies and showed an error instead — the rule belongs to the
            // ranker, where prose genuinely cannot be used.
            requireJson = false,
        )
        return parseTurn(json)
    }''', '''    suspend fun converse(
        history: List<ChatTurn>,
        profile: TasteProfile,
        allergens: List<String>,
        cityLabel: String?,
        /**
         * The places the app is already showing this person. Without them the model was being
         * asked "what is good near me" with no knowledge of anywhere at all, and its only honest
         * answer was to refuse — while a screenful of real, ranked, enriched places sat one tab
         * away. These are OUR data, so naming one is a lookup, not a hallucination.
         */
        nearby: List<RestaurantResult> = emptyList(),
        /** Called with the prose written so far, every time more of it arrives. */
        onDelta: (String) -> Unit = {},
    ): AssistantTurn {
        val messages = buildList {
            add(Msg("system", conversationSystemPrompt(profile, allergens, cityLabel, nearby)))
            history.takeLast(CHAT_HISTORY_TURNS).forEach {
                add(Msg(if (it.fromUser) "user" else "assistant", it.text.take(600)))
            }
        }
        val raw = try {
            chatStream(
                messages = messages,
                maxTokens = CHAT_TOKENS,
                connectTimeoutMs = RANK_CONNECT_MS,
                readTimeoutMs = CHAT_TIMEOUT_MS,
                // Ranking wants the same answer every time. A conversation that answers
                // identically twice reads as a phone tree.
                temperature = 0.6,
                backoffKey = Backoff.CHAT,
                onPartial = { accumulated -> onDelta(partialSay(accumulated)) },
            )
        } catch (e: Exception) {
            val code = (e as? HttpException)?.code
            // A rejected key or a retired model will not answer any better without streaming, and
            // a timeout would just cost the same wait twice. Anything else — a proxy that mangles
            // SSE, a chunked-transfer oddity — is worth one plain attempt, because a reply that
            // arrives all at once still beats no reply. The animation is the least important part.
            if (e is java.net.SocketTimeoutException || (code != null && code in CONFIG_CODES)) throw e
            Log.w(TAG, "Stream failed (${e.message}); retrying without it")
            Backoff.clear(Backoff.CHAT)
            chat(
                messages = messages,
                maxTokens = CHAT_TOKENS,
                connectTimeoutMs = RANK_CONNECT_MS,
                readTimeoutMs = CHAT_TIMEOUT_MS,
                temperature = 0.6,
                backoffKey = Backoff.CHAT,
                // A conversation that answers in plain sentences has answered. Demanding JSON here
                // threw away good replies and showed an error instead — the rule belongs to the
                // ranker, where prose genuinely cannot be used.
                requireJson = false,
            )
        }
        return parseTurn(raw)
    }

    /**
     * The prose written so far, read out of a JSON envelope that is still being written.
     *
     * The reply is `{"say":"...` and the sentence inside it is the only part a person may ever
     * see, so a partial generation cannot simply be printed — the first frame would be a brace.
     * This walks the string escape by escape and stops at whatever exists, which is exactly the
     * behaviour that makes the envelope invisible while it fills in.
     */
    internal fun partialSay(raw: String): String {
        val text = raw.replace(FENCE, "")
        val opener = SAY_OPEN.find(text)
            // No envelope yet. An open brace means it is coming; anything else means the model
            // ignored the format and is just talking, which is a perfectly good reply.
            ?: return if (text.trimStart().startsWith("{")) "" else text.trim()
        val out = StringBuilder()
        var i = opener.range.last + 1
        while (i < text.length) {
            val c = text[i]
            when {
                c == '\\\\' -> {
                    when (text.getOrNull(i + 1)) {
                        'n' -> out.append('\\n')
                        't' -> out.append(' ')
                        'r' -> Unit
                        // A \\uXXXX cut in half is not decodable yet; skip the whole escape rather
                        // than leaking four hex digits into the bubble for a frame.
                        'u' -> i += 4
                        null -> Unit
                        else -> out.append(text[i + 1])
                    }
                    i += 2
                }
                c == '"' -> return out.toString().trim()
                else -> {
                    out.append(c)
                    i++
                }
            }
        }
        return out.toString().trim()
    }''')

# ------------------------------------------------------------- salvage regexes
sub('''    private val SAY_FIELD = Regex("\\"say\\"\\\\s*:\\\\s*\\"((?:\\\\\\\\.|[^\\"\\\\\\\\])*)\\"")''',
    '''    private val SAY_FIELD = Regex("\\"say\\"\\\\s*:\\\\s*\\"((?:\\\\\\\\.|[^\\"\\\\\\\\])*)\\"")

    /** Just the opening of that field, for reading a reply that has not finished arriving. */
    private val SAY_OPEN = Regex("\\"say\\"\\\\s*:\\\\s*\\"")''')

sub('''raw.replace(Regex("\\"(?:say|search|profile|cuisines|diets|vibes|price_comfort)\\"\\\\s*:"), " ")''',
    '''raw.replace(Regex("\\"(?:say|search|places|profile|cuisines|diets|vibes|price_comfort)\\"\\\\s*:"), " ")''')

# ------------------------------------------------------------- system prompt
sub('''    private fun conversationSystemPrompt(
        profile: TasteProfile,
        allergens: List<String>,
        cityLabel: String?,
    ) = buildString {''', '''    /** How many of the on-screen places the model is shown. Prompt size is latency. */
    private const val GROUND_LIMIT = 12

    /** One place, flattened to the facts worth reasoning over. No ids, no coordinates, no URLs. */
    private fun groundLine(r: RestaurantResult): String {
        val parts = buildList {
            add(r.cuisineTags.joinToString(", ").ifBlank { "Restaurant" })
            if (r.rating > 0) add("${r.rating}\\u2605 (${formatCount(r.reviewCount)})")
            else r.yelp?.takeIf { it.usable }?.let { add("${it.rating}\\u2605 on Yelp") }
            if (r.priceTier > 0) add("$".repeat(r.priceTier))
            add(formatDistanceMeters(r.distanceMeters))
            r.pulse?.let { add("wait ${it.minutesLow}-${it.minutesHigh} min, ${it.busyLabel.lowercase()}") }
            if (r.dietaryOptions.isNotEmpty()) add("venue lists ${r.dietaryOptions.joinToString("/")}")
        }
        return "${r.name} \\u2014 ${parts.joinToString(" \\u2014 ")}"
    }

    private fun conversationSystemPrompt(
        profile: TasteProfile,
        allergens: List<String>,
        cityLabel: String?,
        nearby: List<RestaurantResult>,
    ) = buildString {''')

sub('''            YOU DO NOT KNOW ANY RESTAURANTS.
            Never name a venue, address, phone number, price or opening time. You have no such
            knowledge and anything you produce will be invented. When a turn should show places,
            put a short search phrase in "search" and the app fetches real ones from its own map
            data and shows them under your reply. Then write "say" as an introduction to results
            you have not seen yet — say what you looked for, not what you found.''',
    '''            THE ONLY RESTAURANTS THAT EXIST ARE THE ONES IN THE NEARBY LIST BELOW.
            You have no knowledge of any venue anywhere on earth. If a place is not in that list
            you do not know it exists, and inventing one is the worst thing you can do here.
            There are exactly two ways to talk about places and no third:
            - It is in the NEARBY list: name it exactly as written and put its number in "places",
              and the app renders its real card under your reply.
            - You want something that is not in that list: put a short search phrase in "search"
              and the app fetches real places from its own map data. Write "say" as an
              introduction to results you have not seen — what you looked for, not what you found.
            Never state an address, phone number, price or opening time for anything, even for a
            place in the list. The app has those and puts them on the card; you would be guessing.''')

sub('''        appendLine("- Budget: ${"$".repeat(profile.priceComfort.coerceIn(1, 4))}")
        cityLabel?.let { appendLine("- Around: $it") }
        appendLine()''',
    '''        appendLine("- Budget: ${"$".repeat(profile.priceComfort.coerceIn(1, 4))}")
        cityLabel?.let { appendLine("- Around: $it") }
        if (nearby.isNotEmpty()) {
            appendLine()
            appendLine("NEARBY — real places the app is showing this person right now, best match first:")
            nearby.take(GROUND_LIMIT).forEachIndexed { i, r -> appendLine("${i + 1}. ${groundLine(r)}") }
        }
        appendLine()''')

sub('''            Reply with ONE JSON object and nothing else. No markdown, no code fences, no commentary.
            {"say":"","search":"","profile":null}''',
    '''            Reply with ONE JSON object and nothing else. No markdown, no code fences, no commentary.
            {"say":"","search":"","places":[],"profile":null}''')

sub('''            - search: a short phrase to search for, ONLY on turns that should show places
              (e.g. "quiet vegetarian dinner"). Empty string on every other turn.''',
    '''            - search: a short phrase to search for, ONLY on turns that should show places that
              are not already in the NEARBY list (e.g. "quiet vegetarian dinner"). Empty string on
              every other turn, and empty when the NEARBY list already answers the question.
            - places: the numbers from the NEARBY list you actually talked about, e.g. [2,5].
              Empty on every turn that named none. Never an id, never a name — only the number.''')

# ------------------------------------------------------------- streaming transport
sub('''    /** Talks to NIM and returns the JSON object from the reply. No state, no backoff, no logging. */''',
    '''    /**
     * [chat] with the reply arriving in pieces. Same bookkeeping — breaker, [lastFailure], model
     * demotion — because a stream that dies is exactly as much of a failure as a call that does.
     */
    private suspend fun chatStream(
        messages: List<Msg>,
        maxTokens: Int,
        model: String = activeModel,
        connectTimeoutMs: Int = CONNECT_TIMEOUT_MS,
        readTimeoutMs: Int = RANK_TIMEOUT_MS,
        temperature: Double = 0.2,
        backoffKey: String = Backoff.CHAT,
        onPartial: (String) -> Unit,
    ): String {
        if (!isConfigured) throw NimException("NIM_API_KEY missing from local.properties")
        val startedAt = System.currentTimeMillis()
        try {
            val text = rawChatStream(messages, maxTokens, model, connectTimeoutMs, readTimeoutMs, temperature, onPartial)
            if (text.isBlank()) throw NimException("Model streamed an empty reply")
            Backoff.clear(backoffKey)
            lastFailure = null
            Log.i(TAG, "$backoffKey OK streamed ($model in ${System.currentTimeMillis() - startedAt}ms)")
            return text
        } catch (e: Exception) {
            val elapsed = System.currentTimeMillis() - startedAt
            val code = (e as? HttpException)?.code
            if (e is java.net.SocketTimeoutException || code == 404) demoteActiveModel()
            Backoff.trip(
                backoffKey,
                if (code != null && code in CONFIG_CODES) CONFIG_BACKOFF_MS else FAILURE_BACKOFF_MS,
            )
            fail(describe(e, code, elapsed))
            throw e
        }
    }

    /**
     * Reads the SSE body and hands the caller everything received so far after each delta.
     *
     * A malformed chunk is skipped rather than thrown: one unreadable frame in the middle of a
     * hundred good ones must not lose the reply that is otherwise arriving perfectly.
     */
    private suspend fun rawChatStream(
        messages: List<Msg>,
        maxTokens: Int,
        model: String,
        connectTimeoutMs: Int,
        readTimeoutMs: Int,
        temperature: Double,
        onPartial: (String) -> Unit,
    ): String = withContext(Dispatchers.IO) {
        val body = AppJson.encodeToString(
            ChatRequest.serializer(),
            ChatRequest(
                model = model,
                messages = messages,
                maxTokens = maxTokens,
                temperature = temperature,
                stream = true,
            ),
        )
        val text = StringBuilder()
        httpPostStream(
            url = "${BuildConfig.NIM_BASE_URL}/chat/completions",
            body = body,
            contentType = "application/json",
            headers = mapOf("Authorization" to "Bearer ${BuildConfig.NIM_API_KEY}"),
            readTimeoutMs = readTimeoutMs,
            connectTimeoutMs = connectTimeoutMs,
        ) { line ->
            if (line.startsWith("data:")) {
                val payload = line.removePrefix("data:").trim()
                if (payload.isNotEmpty() && payload != "[DONE]") {
                    val delta = runCatching {
                        AppJson.decodeFromString(StreamChunk.serializer(), payload)
                            .choices.firstOrNull()?.delta?.content.orEmpty()
                    }.getOrDefault("")
                    if (delta.isNotEmpty()) {
                        text.append(delta)
                        onPartial(text.toString())
                    }
                }
            }
        }
        text.toString().trim()
    }

    /** Talks to NIM and returns the JSON object from the reply. No state, no backoff, no logging. */''')

sub('''    @Serializable
    private data class ChatResponse(val choices: List<Choice> = emptyList()) {''',
    '''    /** One SSE frame. Every field defaults, because a keepalive frame carries almost nothing. */
    @Serializable
    private data class StreamDelta(val content: String = "")

    @Serializable
    private data class StreamChoice(val delta: StreamDelta = StreamDelta())

    @Serializable
    private data class StreamChunk(val choices: List<StreamChoice> = emptyList())

    @Serializable
    private data class ChatResponse(val choices: List<Choice> = emptyList()) {''')

if failures:
    print("FAILED:")
    for f in failures:
        print("  -", f)
    sys.exit(1)

open(PATH, "w", encoding="utf-8").write(src)
print("NimClient patched")
