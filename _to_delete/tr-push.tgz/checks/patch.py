#!/usr/bin/env python3
"""Targeted edits to the files that are mostly unchanged. Every replacement must apply exactly
once; anything that does not match is reported rather than silently skipped."""
import os
import sys

ROOT = os.path.expanduser("~/mnt/TasteRoute/app/src/main/java/space/gexemy/tasteroute")
failures = []
applied = 0


def patch(rel, old, new, count=1):
    global applied
    path = os.path.join(ROOT, rel)
    with open(path, encoding="utf-8") as fh:
        src = fh.read()
    found = src.count(old)
    if found != count:
        failures.append(f"{rel}: expected {count} match(es), found {found} :: {old.strip().splitlines()[0][:70]}")
        return
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(src.replace(old, new))
    applied += 1


# ---------------------------------------------------------------- Http.kt
patch("data/Http.kt", '''private fun send(
    method: String,''', '''/**
 * Server-sent events, delivered line by line on the calling thread.
 *
 * A chat reply arrives as a hundred small chunks over several seconds. Buffering all of them and
 * printing the finished paragraph wastes the one part of the wait that could have been interesting
 * to watch, so this hands each line straight to the caller. Blocking, like everything else here —
 * call it inside Dispatchers.IO.
 */
internal fun httpPostStream(
    url: String,
    body: String,
    contentType: String,
    headers: Map<String, String> = emptyMap(),
    readTimeoutMs: Int = READ_TIMEOUT_MS,
    connectTimeoutMs: Int = CONNECT_TIMEOUT_MS,
    onLine: (String) -> Unit,
) {
    val conn = (URL(url).openConnection() as HttpURLConnection).apply {
        requestMethod = "POST"
        connectTimeout = connectTimeoutMs
        readTimeout = readTimeoutMs
        setRequestProperty("Accept", "text/event-stream")
        setRequestProperty("User-Agent", USER_AGENT)
        setRequestProperty("Content-Type", contentType)
        headers.forEach { (k, v) -> setRequestProperty(k, v) }
        doOutput = true
    }
    try {
        conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        if (code !in 200..299) {
            val text = conn.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            throw HttpException(code, "HTTP $code: ${text.take(200)}")
        }
        conn.inputStream.bufferedReader(Charsets.UTF_8).use { reader -> reader.forEachLine(onLine) }
    } finally {
        conn.disconnect()
    }
}

private fun send(
    method: String,''')

# ---------------------------------------------------------------- Schema.kt
patch("data/Schema.kt", '''    /** Full gallery, newest first. [imageUrl] is whatever should lead. */
    val photos: List<String> = emptyList(),''', '''    /** Full gallery, newest first. [imageUrl] is whatever should lead. */
    val photos: List<String> = emptyList(),
    /**
     * Dishes a source actually harvested from this venue's own menu. Empty for almost everything,
     * and that is the point: when this is empty the app suggests a dish and says it is a
     * suggestion. A guessed dish presented as the house special is a lie about a restaurant.
     */
    @SerialName("menu_highlights") val menuHighlights: List<String> = emptyList(),''')

patch("data/Schema.kt", '''    fun corridorMeters(tier: Tier) = if (tier == Tier.PRO) 1_500 else 800
}''', '''    fun corridorMeters(tier: Tier) = if (tier == Tier.PRO) 1_500 else 800
}

/**
 * What the tiers cost, in one place, because the number appears on the paywall, in the upsells and
 * eventually in Play Billing and they must not drift apart.
 *
 * Priced low on purpose. TasteRoute's actual asset is first-party supply — the photos, waits,
 * reviews and allergen reports diners contribute — and supply scales with installed base, not with
 * revenue per user. At three times the price you do not get three times the money, you get roughly
 * the same money from a third of the people and a third of the contributions, which starves the
 * thing that makes the app worth paying for at all.
 */
object Plans {
    const val PLUS_MONTHLY = "$2.99"
    const val PRO_MONTHLY = "$5.99"
}''')

# ---------------------------------------------------------------- AppState.kt
patch("data/AppState.kt", '''    /** Called once from Application.onCreate, before any composition reads this state. */
    fun restore() {''', '''    /**
     * The scalars the first composition reads, and nothing else.
     *
     * Every line here is a SharedPreferences hit on the main thread before the first frame can be
     * drawn, so anything that costs a JSON decode belongs in [restoreRest] instead.
     */
    fun restoreCritical() {''')

patch("data/AppState.kt", '''        Prefs.getString(Prefs.PROFILE).takeIf { it.isNotBlank() }?.let { json ->
            runCatching { AppJson.decodeFromString(TasteProfile.serializer(), json) }.onSuccess { profile = it }
        }
        restoreWarm()
        restoreChat()
        Session.restore()
        NimClient.restore()
    }''', '''    }

    /**
     * Everything with a JSON document behind it, run off the main thread once the UI is already up.
     *
     * None of it is needed to draw the first screen: the profile only matters when a search runs,
     * and both the warm list and the chat log land long before anyone has finished reading a
     * header. Deserializing them in Application.onCreate was most of the cold-start wait.
     */
    fun restoreRest() {
        Prefs.getString(Prefs.PROFILE).takeIf { it.isNotBlank() }?.let { json ->
            runCatching { AppJson.decodeFromString(TasteProfile.serializer(), json) }.onSuccess { profile = it }
        }
        restoreWarm()
        restoreChat()
        Session.restore()
        NimClient.restore()
    }''')

patch("data/AppState.kt", '''        val keep = results.take(WARM_LIMIT)''',
      '''        val keep = results.take(WARM_LIMIT).map { it.slimForWarm() }''')

patch("data/AppState.kt", '''/** App-wide observable state. Anything worth surviving process death is mirrored into [Prefs]. */''',
      '''/**
 * What a result keeps when it is written to disk for the next cold start.
 *
 * Sources, facts, galleries and allergen reports are all re-fetched within a second of the app
 * opening — and they are also almost all of the bytes. Storing them meant the warm list took
 * longer to parse at startup than the network took to replace it, which is the opposite of the
 * point of having one.
 */
private fun RestaurantResult.slimForWarm() = copy(
    photos = emptyList(),
    allergens = emptyList(),
    sources = emptyList(),
    facts = null,
    yelp = null,
)

/** App-wide observable state. Anything worth surviving process death is mirrored into [Prefs]. */''')

# ---------------------------------------------------------------- CrowdRepository.kt
patch("data/CrowdRepository.kt", '''                                // OSM never carries a photo for most places, so a diner's upload
                                // leads whenever one exists.
                                imageUrl = covers[r.id] ?: r.imageUrl,''',
      '''                                // A diner's own upload leads whenever one exists, then whatever
                                // an outside source had. OSM carries a photo for almost nothing, so
                                // without the fallbacks the feed is a column of grey squares and the
                                // food is invisible until you tap something.
                                imageUrl = covers[r.id] ?: r.imageUrl ?: yelpById[r.id]?.imageUrl
                                    ?: sourcesById[r.id]?.firstNotNullOfOrNull { s -> s.photos.firstOrNull()?.url },''')

# ---------------------------------------------------------------- Theme.kt
patch("ui/theme/Theme.kt", '''val LocalBrandTones = staticCompositionLocalOf { LightTones }''',
      '''val LocalBrandTones = staticCompositionLocalOf { LightTones }

/**
 * Whether the app is currently dark, for the one surface Material has no colour slot for: the map.
 * Raster tiles are baked images, so following the theme means choosing a different tile set rather
 * than tinting a colour — and a screen cannot read [AppState.themeMode] directly and still respect
 * "System".
 */
val LocalIsDark = staticCompositionLocalOf { false }''')

patch("ui/theme/Theme.kt", '''    androidx.compose.runtime.CompositionLocalProvider(
        LocalBrandTones provides if (dark) DarkTones else LightTones,
    ) {''', '''    androidx.compose.runtime.CompositionLocalProvider(
        LocalBrandTones provides if (dark) DarkTones else LightTones,
        LocalIsDark provides dark,
    ) {''')

# ---------------------------------------------------------------- SettingsScreen.kt
patch("ui/settings/SettingsScreen.kt", '''import space.gexemy.tasteroute.data.Perf''',
      '''import space.gexemy.tasteroute.data.Perf
import space.gexemy.tasteroute.data.Plans''')

patch("ui/settings/SettingsScreen.kt",
      '''    PlanSpec(Tier.PLUS, "Plus · $6/mo", "Unlimited AI search · on-my-way search · wider radius · full result list"),
    PlanSpec(Tier.PRO, "Pro · $12/mo", "Everything in Plus · live wait times in minutes · wider route corridor"),''',
      '''    PlanSpec(Tier.PLUS, "Plus · ${Plans.PLUS_MONTHLY}/mo", "Unlimited AI search · on-my-way search · wider radius · full result list"),
    PlanSpec(Tier.PRO, "Pro · ${Plans.PRO_MONTHLY}/mo", "Everything in Plus · live wait times in minutes · wider route corridor"),''')

# ---------------------------------------------------------------- NavigationScreen.kt
patch("ui/map/NavigationScreen.kt", '''import space.gexemy.tasteroute.ui.theme.LocalBrandTones''',
      '''import space.gexemy.tasteroute.ui.theme.LocalBrandTones
import space.gexemy.tasteroute.ui.theme.LocalIsDark''')

patch("ui/map/NavigationScreen.kt", '''    val behindColor = tones.muted.copy(alpha = 0.75f).toArgb()

    val mapView = remember {
        MapView(context).apply {
            setTileSource(BASEMAP)''',
      '''    val behindColor = tones.muted.copy(alpha = 0.75f).toArgb()
    // Guidance at night on a white map is the worst offender of the lot — see TileSources.
    val dark = LocalIsDark.current

    val mapView = remember {
        ensureOsmdroid(context)
        MapView(context).apply {
            setTileSource(basemapFor(dark))''')

# ---------------------------------------------------------------- HomeScreen.kt
patch("ui/home/HomeScreen.kt", '''import androidx.compose.material.icons.filled.Group''',
      '''import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Lock''')

patch("ui/home/HomeScreen.kt", '''import androidx.compose.ui.text.style.TextAlign''',
      '''import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow''')

patch("ui/home/HomeScreen.kt", '''import kotlinx.coroutines.delay''',
      '''import java.util.Locale
import kotlinx.coroutines.delay''')

patch("ui/home/HomeScreen.kt",
      '''    val origin = if (mode == SearchMode.ANYWHERE) AppState.searchArea else AppState.origin
''',
      '''    val origin = if (mode == SearchMode.ANYWHERE) AppState.searchArea else AppState.origin
    // GPS publishes a new fix every few metres and Coordinates is a data class, so each one used to
    // restart the whole stream — cancelling an AI re-rank that was seconds from landing and paying
    // for the places call again. Rounded to the precision the Recommender's own cache key uses,
    // below which the request it would build is byte-for-byte the same request.
    val originKey = origin?.let { String.format(Locale.US, "%.3f,%.3f", it.lat, it.lng) }
''')

patch("ui/home/HomeScreen.kt",
      '''    LaunchedEffect(query, filters, allergens, profile, tier, origin, mode, destination) {''',
      '''    LaunchedEffect(query, filters, allergens, profile, tier, originKey, mode, destination) {''')

patch("ui/home/HomeScreen.kt",
      '''        delay(if (query.isBlank()) 120 else 500) // debounce typing before hitting the network''',
      '''        // Only typing needs debouncing. The old 120ms applied to the very first search too, and
        // a delay before the first request of a cold start is latency with no keystroke to absorb.
        if (query.isNotBlank()) delay(400)''')

patch("ui/home/HomeScreen.kt", '''        SegmentedButton(
            selected = mode == SearchMode.NEARBY,
            onClick = { onMode(SearchMode.NEARBY) },
            shape = SegmentedButtonDefaults.itemShape(0, 3),
        ) { Text("Near me") }
        SegmentedButton(
            selected = mode == SearchMode.ON_THE_WAY,
            onClick = { onMode(SearchMode.ON_THE_WAY) },
            shape = SegmentedButtonDefaults.itemShape(1, 3),
        ) {
            Text(if (Entitlements.canSearchCorridor(tier)) "On my way" else "On my way · Plus")
        }
        SegmentedButton(
            selected = mode == SearchMode.ANYWHERE,
            onClick = { onMode(SearchMode.ANYWHERE) },
            shape = SegmentedButtonDefaults.itemShape(2, 3),
        ) { Text("Anywhere") }
    }
}''', '''        // icon = {} on all three. The default icon slot draws a checkmark on whichever segment is
        // selected, so selecting one widens it and shoves the other two sideways — the row visibly
        // reflows every time you touch it. And the locked state is an icon, not a longer label:
        // appending " · Plus" is exactly what made this segment wrap to two lines and grow taller
        // than the row it lives in.
        SegmentedButton(
            selected = mode == SearchMode.NEARBY,
            onClick = { onMode(SearchMode.NEARBY) },
            shape = SegmentedButtonDefaults.itemShape(0, 3),
            icon = {},
        ) { SegmentLabel("Near me") }
        SegmentedButton(
            selected = mode == SearchMode.ON_THE_WAY,
            onClick = { onMode(SearchMode.ON_THE_WAY) },
            shape = SegmentedButtonDefaults.itemShape(1, 3),
            icon = {},
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (!Entitlements.canSearchCorridor(tier)) {
                    Icon(Icons.Filled.Lock, null, Modifier.size(12.dp))
                    Spacer(Modifier.width(4.dp))
                }
                SegmentLabel("On my way")
            }
        }
        SegmentedButton(
            selected = mode == SearchMode.ANYWHERE,
            onClick = { onMode(SearchMode.ANYWHERE) },
            shape = SegmentedButtonDefaults.itemShape(2, 3),
            icon = {},
        ) { SegmentLabel("Anywhere") }
    }
}

/** One line, ellipsised, never wrapped. A segment that grows to fit its text is not a segment. */
@Composable
private fun SegmentLabel(text: String) {
    Text(text, maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis)
}''')

# ---------------------------------------------------------------- MainActivity.kt
patch("MainActivity.kt", '''import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.runtime.Composable''', '''import androidx.compose.runtime.Composable''')

patch("MainActivity.kt", '''import space.gexemy.tasteroute.data.USER_AGENT
''', '''''')

patch("MainActivity.kt", '''import android.content.Context
import android.os.Bundle''', '''import android.os.Bundle''')

patch("MainActivity.kt", '''import space.gexemy.tasteroute.ui.theme.Genie
import space.gexemy.tasteroute.ui.theme.GenieContainer
import space.gexemy.tasteroute.ui.theme.TasteRouteTheme
import space.gexemy.tasteroute.ui.theme.genieEnter
import space.gexemy.tasteroute.ui.theme.genieExit
import java.io.File
import kotlinx.coroutines.launch
import org.osmdroid.config.Configuration''', '''import space.gexemy.tasteroute.ui.theme.TasteRouteTheme
import space.gexemy.tasteroute.ui.theme.popEnter
import space.gexemy.tasteroute.ui.theme.popExit
import space.gexemy.tasteroute.ui.theme.pushEnter
import space.gexemy.tasteroute.ui.theme.pushExit
import space.gexemy.tasteroute.ui.theme.tabEnter
import space.gexemy.tasteroute.ui.theme.tabExit
import kotlinx.coroutines.launch''')

patch("MainActivity.kt", '''        configureOsmdroid(this)
        enableEdgeToEdge()''', '''        enableEdgeToEdge()''')

patch("MainActivity.kt", '''/** Cache under the app's own dir so no storage permission is needed; tile servers require a real UA. */
private fun configureOsmdroid(context: Context) {
    val cache = File(context.cacheDir, "osmdroid")
    Configuration.getInstance().apply {
        load(context, context.getSharedPreferences("osmdroid", Context.MODE_PRIVATE))
        userAgentValue = USER_AGENT
        osmdroidBasePath = cache
        osmdroidTileCache = File(cache, "tiles")
    }
}

''', '''''')

patch("MainActivity.kt", '''private const val TAB_FADE_MS = 90

''', '''''')

patch("MainActivity.kt", '''                // Tabs cross-fade instantly; only pushed screens get the genie, which is what makes
                // it read as "this card opened" instead of a generic page animation.
                // Tabs cross-fade in 90ms. Only pushed screens run the genie, and only they hold
                // two screens in composition at once — a tab switch used to pay for both.
                NavHost(
                    navController = nav,
                    startDestination = DISCOVER,
                    modifier = Modifier.padding(padding),
                    enterTransition = { fadeIn(tween(TAB_FADE_MS)) },
                    exitTransition = { fadeOut(tween(TAB_FADE_MS)) },
                    popEnterTransition = { fadeIn(tween(TAB_FADE_MS)) },
                    popExitTransition = { fadeOut(tween(TAB_FADE_MS)) },
                ) {''', '''                // Tabs fade through one another, pushes travel along a shared X axis. Two
                // different relationships between two screens, so two different transitions —
                // and only a push holds both screens in composition at once. See Motion.kt.
                NavHost(
                    navController = nav,
                    startDestination = DISCOVER,
                    modifier = Modifier.padding(padding),
                    enterTransition = { tabEnter() },
                    exitTransition = { tabExit() },
                    popEnterTransition = { tabEnter() },
                    popExitTransition = { tabExit() },
                ) {''')

patch("MainActivity.kt", "genieScreen(", "pushScreen(", count=9)

patch("MainActivity.kt", '''                    // Deliberately not a genieScreen: the genie holds both screens in composition
                    // for its whole duration, and these two are the heaviest in the app.''',
      '''                    // Deliberately not a pushScreen: a transition holds both screens in
                    // composition for its whole duration, and these two are the heaviest here.''')

patch("MainActivity.kt", '''                    pushScreen(ROUTE) {
                        MapRouteScreen(
                            onBack = { nav.popBackStack() },
                            onNavigate = { nav.navigate(NAVIGATE) },
                        )
                    }''', '''                    pushScreen(ROUTE) {
                        MapRouteScreen(
                            onBack = { nav.popBackStack() },
                            onNavigate = { nav.navigate(NAVIGATE) },
                            onOpenPlace = { nav.navigate(DETAIL) },
                            onUpgrade = { nav.switchTab(PROFILE) },
                        )
                    }''')

patch("MainActivity.kt", '''/** A pushed destination wrapped in the genie warp. */
private fun NavGraphBuilder.pushScreen(
    route: String,
    content: @Composable () -> Unit,
) = composable(
    route = route,
    enterTransition = { genieEnter },
    exitTransition = { genieExit },
    popEnterTransition = { genieEnter },
    popExitTransition = { genieExit },
) { GenieContainer { content() } }''', '''/** A pushed destination: in along the shared axis, back out the way it came. */
private fun NavGraphBuilder.pushScreen(
    route: String,
    content: @Composable () -> Unit,
) = composable(
    route = route,
    enterTransition = { pushEnter() },
    exitTransition = { pushExit() },
    popEnterTransition = { popEnter() },
    popExitTransition = { popExit() },
) { content() }''')

patch("MainActivity.kt", '''private fun NavHostController.switchTab(route: String) {
    Genie.anchorToCenter()
    navigate(route) {''', '''private fun NavHostController.switchTab(route: String) {
    navigate(route) {''')

patch("MainActivity.kt", '''/** A push with no card behind it — the genie comes from the middle rather than a stale anchor. */
private fun NavHostController.push(route: String) {
    Genie.anchorToCenter()
    navigate(route)
}''', '''/** Everything that is not a tab is a push, so Back always means something. */
private fun NavHostController.push(route: String) {
    navigate(route)
}''')

print(f"applied {applied} patch(es)")
if failures:
    print("FAILED:")
    for f in failures:
        print("  -", f)
    sys.exit(1)
print("all patches applied")
