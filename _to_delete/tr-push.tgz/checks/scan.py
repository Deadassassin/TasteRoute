#!/usr/bin/env python3
"""Kotlin-aware structural check: bracket balance with full string / raw-string / char / comment /
string-template awareness. No gradle build can run from a Cowork session, so this catches the one
class of mistake an edit can actually introduce — an unbalanced file.

The template handling is the part that matters: `"${"$".repeat(n)}"` is a string containing code
containing another string, and a scanner that does not model that reports a healthy file as broken.
"""
import os
import sys

ROOT = os.path.expanduser("~/mnt/TasteRoute/app/src/main/java/space/gexemy/tasteroute")
OPEN, CLOSE = "([{", ")]}"


def scan(path):
    s = open(path, encoding="utf-8").read()
    n = len(s)
    i = 0
    line = 1
    errors = []
    # Each frame is ("code", brackets) or ("str", quote_len). A ${ inside a string pushes a code
    # frame; the } that empties its bracket list pops back into the string.
    frames = [["code", []]]

    def top():
        return frames[-1]

    while i < n:
        c = s[i]
        if c == "\n":
            line += 1
            i += 1
            continue
        kind = top()[0]

        if kind == "code":
            if s.startswith("//", i):
                j = s.find("\n", i)
                i = n if j < 0 else j
                continue
            if s.startswith("/*", i):
                depth, i = 1, i + 2
                while i < n and depth:
                    if s[i] == "\n":
                        line += 1
                    if s.startswith("/*", i):
                        depth, i = depth + 1, i + 2
                        continue
                    if s.startswith("*/", i):
                        depth, i = depth - 1, i + 2
                        continue
                    i += 1
                continue
            if s.startswith('"""', i):
                frames.append(["str", 3])
                i += 3
                continue
            if c == '"':
                frames.append(["str", 1])
                i += 1
                continue
            if c == "'":
                i += 1
                while i < n and s[i] != "'":
                    i += 2 if s[i] == "\\" else 1
                i += 1
                continue
            if c in OPEN:
                top()[1].append((c, line))
                i += 1
                continue
            if c in CLOSE:
                brackets = top()[1]
                if not brackets:
                    if len(frames) > 1:
                        # The } that closes a ${ template: back into the string it lives in.
                        frames.pop()
                        i += 1
                        continue
                    errors.append(f"{path}:{line}: stray '{c}'")
                    return errors
                open_c, open_line = brackets.pop()
                if OPEN.index(open_c) != CLOSE.index(c):
                    errors.append(f"{path}:{line}: '{c}' closes '{open_c}' from line {open_line}")
                    return errors
                i += 1
                continue
            i += 1
            continue

        # Inside a string literal.
        qlen = top()[1]
        if qlen == 1 and c == "\\":
            i += 2
            continue
        if s.startswith("${", i):
            frames.append(["code", []])
            i += 2
            continue
        if qlen == 3 and s.startswith('"""', i):
            # Kotlin closes a raw string at the LAST quote of a run, so """" ends with a quote.
            j = i
            while s.startswith('""""', j):
                j += 1
            frames.pop()
            i = j + 3
            continue
        if qlen == 1 and c == '"':
            frames.pop()
            i += 1
            continue
        if qlen == 1 and c == "\n":
            errors.append(f"{path}:{line}: newline inside a single-quoted string")
            return errors
        i += 1
        continue

    if len(frames) > 1:
        errors.append(f"{path}: file ends inside a string or template")
    for open_c, open_line in frames[0][1]:
        errors.append(f"{path}:{open_line}: '{open_c}' never closed")
    return errors


bad, files = 0, 0
for dirpath, _, names in os.walk(ROOT):
    for name in sorted(names):
        if not name.endswith(".kt"):
            continue
        p = os.path.join(dirpath, name)
        files += 1
        for e in scan(p):
            bad += 1
            print(e.replace(ROOT + os.sep, ""))
print(f"scanned {files} files, {bad} problem(s)")
sys.exit(1 if bad else 0)
