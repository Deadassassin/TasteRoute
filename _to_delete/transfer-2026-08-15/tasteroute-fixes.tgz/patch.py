#!/usr/bin/env python3
"""Exact-string patches. Every replacement asserts its match count, so a stale tree fails loudly
instead of half-applying."""
import io, os, sys

ROOT = os.environ.get("TR_ROOT") or os.path.expanduser("~/mnt/TasteRoute/app/src/main/java/space/gexemy/tasteroute")
edits = []


def sub(path, old, new, count=1):
    edits.append((path, old, new, count))


# ---------------------------------------------------------------- Backoff: a key for the map
sub("data/Backoff.kt", '''    const val SOURCES = "sources"
''', '''    const val SOURCES = "sources"

    /**
     * The map itself, dialled straight from the detail screen for the tags a search response does
     * not carry. Separate from PLACES because that key means "our own host is sick", and Overpass
     * rate-limiting us says nothing at all about our own host.
     */
    const val OSM = "osm"
''')

# ---------------------------------------------------------------- Overpass: one element's tags
sub("data/OverpassClient.kt", '''        val raw = withContext(Dispatchers.IO) {
            var last: Exception? = null
            for (endpoint in ENDPOINTS) {
                try {
                    // Deliberately no Accept: application/json — overpass-api.de answers that with 406.
                    return@withContext httpPost(
                        url = endpoint,
                        body = body,
                        contentType = "application/x-www-form-urlencoded",
                        readTimeoutMs = 14_000,
                    )
                } catch (e: Exception) {
                    last = e
                }
            }
            throw last ?: HttpException(0, "No Overpass endpoint reachable")
        }
        return AppJson.decodeFromString(Response.serializer(), raw).elements.mapNotNull { it.toRecord() }
    }
''', '''        val raw = post(body)
        return AppJson.decodeFromString(Response.serializer(), raw).elements.mapNotNull { it.toRecord() }
    }

    /**
     * Every tag on ONE element.
     *
     * A search response carries a trimmed record — name, coordinates, cuisine — because a list does
     * not need the rest and the payload is paid for on every card. This is the detail screen asking
     * the map what else it knows about the place somebody actually opened: hours, a phone number,
     * the venue's own website. Null for an id that did not come from OSM, or if the element is gone.
     */
    suspend fun tagsFor(placeId: String): Map<String, String>? {
        val match = OSM_ID.matchEntire(placeId) ?: return null
        val ql = "[out:json][timeout:15];${match.groupValues[1]}(${match.groupValues[2]});out tags center 1;"
        val raw = post("data=" + URLEncoder.encode(ql, "UTF-8"))
        return AppJson.decodeFromString(Response.serializer(), raw).elements.firstOrNull()?.tags
    }

    private val OSM_ID = Regex("^osm-(node|way|relation)-(\\\\d+)$")

    private suspend fun post(body: String): String = withContext(Dispatchers.IO) {
        var last: Exception? = null
        for (endpoint in ENDPOINTS) {
            try {
                // Deliberately no Accept: application/json — overpass-api.de answers that with 406.
                return@withContext httpPost(
                    url = endpoint,
                    body = body,
                    contentType = "application/x-www-form-urlencoded",
                    readTimeoutMs = 14_000,
                )
            } catch (e: Exception) {
                last = e
            }
        }
        throw last ?: HttpException(0, "No Overpass endpoint reachable")
    }

    /**
     * OSM sometimes carries a photo: a direct `image` URL, or a Commons filename that
     * Special:FilePath resolves to one. Coverage is thin, but this is the only source of restaurant
     * photos when the Gexemy API is unreachable — without it that path shows no images at all.
     */
    fun photoFromTags(tags: Map<String, String>): String? {
        tags["image"]?.takeIf { it.startsWith("http") }?.let { return it }
        val commons = tags["wikimedia_commons"]?.removePrefix("File:")?.trim().orEmpty()
        if (commons.isBlank() || commons == tags["wikimedia_commons"]) return null
        return "https://commons.wikimedia.org/wiki/Special:FilePath/" +
            URLEncoder.encode(commons, "UTF-8").replace("+", "%20") + "?width=800"
    }
''')

sub("data/OverpassClient.kt", '''        /**
         * OSM sometimes carries a photo: a direct `image` URL, or a Commons filename that
         * Special:FilePath resolves to one. Coverage is thin, but this is the only source of
         * restaurant photos when the Gexemy API is unreachable — without it the fallback path
         * shows no images at all, which is exactly how it looked before.
         */
        private fun photo(): String? {
            tags["image"]?.takeIf { it.startsWith("http") }?.let { return it }
            val commons = tags["wikimedia_commons"]?.removePrefix("File:")?.trim().orEmpty()
            if (commons.isBlank() || commons == tags["wikimedia_commons"]) return null
            return "https://commons.wikimedia.org/wiki/Special:FilePath/" +
                URLEncoder.encode(commons, "UTF-8").replace("+", "%20") + "?width=800"
        }
''', '''        private fun photo(): String? = photoFromTags(tags)
''')

# ---------------------------------------------------------------- PlaceFacts: merge + real hours
sub("data/Schema.kt", '''    val hasAnything: Boolean
        get() = phone != null || website != null || menu != null || summary != null ||
            menuItems.isNotEmpty() ||
            hoursText.isNotEmpty() || cuisines.isNotEmpty() || socials.isNotEmpty() ||
            listOf(service, amenities, diet, meals, drinks, payment).any { g -> g.values.any { it != null } }
}
''', '''    val hasAnything: Boolean
        get() = phone != null || website != null || menu != null || summary != null ||
            menuItems.isNotEmpty() ||
            hoursLines.isNotEmpty() || cuisines.isNotEmpty() || socials.isNotEmpty() ||
            listOf(service, amenities, diet, meals, drinks, payment).any { g -> g.values.any { it != null } }

    /**
     * The hours worth printing. `opens` and `closes` both at midnight is a CMS template nobody
     * filled in, never a venue open from midnight to midnight: the server stopped emitting it in
     * 1.4.0, but its harvest cache is 14 days deep, so rows written before that are still out there
     * claiming every restaurant in town opens and closes at 00:00.
     */
    val hoursLines: List<String> get() = hoursText.filterNot { PLACEHOLDER_HOURS.containsMatchIn(it) }

    /**
     * Keeps every answer this one has and takes [other]'s only where this one is silent.
     *
     * Order of trust, and it only goes one way: a fact harvested from the venue's own site beats a
     * map tag somebody typed in 2019. But a map tag beats nothing at all, and nothing at all is
     * what a place had on its screen whenever the harvest found it uninteresting or the server was
     * not reachable — which is most small venues, most of the time.
     */
    fun fillFrom(other: PlaceFacts): PlaceFacts = copy(
        phone = phone ?: other.phone,
        website = website ?: other.website,
        menu = menu ?: other.menu,
        menuItems = menuItems.ifEmpty { other.menuItems },
        email = email ?: other.email,
        address = address ?: other.address,
        mapsUrl = mapsUrl ?: other.mapsUrl,
        summary = summary ?: other.summary,
        status = status ?: other.status,
        hoursText = hoursLines.ifEmpty { other.hoursLines },
        openNow = openNow ?: other.openNow,
        priceRange = priceRange ?: other.priceRange,
        cuisines = cuisines.ifEmpty { other.cuisines },
        ranking = ranking ?: other.ranking,
        awards = awards.ifEmpty { other.awards },
        // Mine second, so a key answered by both keeps my answer.
        service = other.service + service,
        amenities = other.amenities + amenities,
        diet = other.diet + diet,
        meals = other.meals + meals,
        drinks = other.drinks + drinks,
        payment = other.payment + payment,
        socials = other.socials + socials,
    )
}

private val PLACEHOLDER_HOURS = Regex("00:00\\\\s*[-\\\\u2013]\\\\s*00:00")
''')

# ---------------------------------------------------------------- Engine: honour the model's order
sub("data/RecommendationEngine.kt", '''        aiOverlay: Map<String, AiOverlay> = emptyMap(),
    ): RecommendationResponse {''', '''        aiOverlay: Map<String, AiOverlay> = emptyMap(),
        /**
         * Ids in the model's order, applied as the last sort. Its picks lead; everything it never
         * looked at keeps its own honest score and stays on the list underneath rather than being
         * deleted for not having been mentioned.
         */
        priority: List<String> = emptyList(),
    ): RecommendationResponse {''')

sub("data/RecommendationEngine.kt", '''        when {
            onTheWay -> ranked.sortBy { it.detourMeters }
            "nearby" in filters -> ranked.sortBy { it.distanceMeters }
        }
''', '''        when {
            onTheWay -> ranked.sortBy { it.detourMeters }
            "nearby" in filters -> ranked.sortBy { it.distanceMeters }
            // Stable, so the tail the model never scored keeps the order the local scorer gave it.
            priority.isNotEmpty() -> {
                val order = priority.withIndex().associate { (i, id) -> id to i }
                ranked.sortBy { order[it.id] ?: Int.MAX_VALUE }
            }
        }
''')

# ---------------------------------------------------------------- Recommender: stop deleting the tail
sub("data/Recommender.kt", '''            val byId = candidates.associateBy { it.record.id }
            val ordered = picks.mapNotNull { byId[it.id]?.record }
            val overlay = picks.associate { it.id to AiOverlay(it.score, it.reasoning) }
            RecommendationOutcome(
                results = RecommendationEngine.recommend(request, ordered, overlay).results,''',
    '''            val byId = candidates.associateBy { it.record.id }
            val ordered = picks.mapNotNull { byId[it.id]?.record }
            // The model SCORES a pool, it does not choose the list. It is shown sixteen of up to
            // sixty candidates and returns at most twelve of those — often fewer, because the
            // prompt tells it fewer is fine — so publishing only what it named deleted everything
            // it never looked at. That is why the list quietly shrank a second after it painted,
            // and why the same neighbourhood offered more places under "On my way" than under
            // "Nearby". Its picks lead; the rest stay underneath, in the local scorer's order.
            val chosen = ordered.mapTo(mutableSetOf()) { it.id }
            val rest = candidates.map { it.record }.filterNot { it.id in chosen }
            val overlay = picks.associate { it.id to AiOverlay(it.score, it.reasoning) }
            RecommendationOutcome(
                results = RecommendationEngine.recommend(
                    request,
                    ordered + rest,
                    overlay,
                    priority = ordered.map { it.id },
                ).results,''')

# ---------------------------------------------------------------- NimClient: the envelope
sub("data/NimClient.kt", '''        val opener = SAY_OPEN.find(text)
            // No envelope yet. An open brace means it is coming; anything else means the model
            // ignored the format and is just talking, which is a perfectly good reply.
            ?: return if (text.trimStart().startsWith("{")) "" else text.trim()''',
    '''        val opener = SAY_OPEN.find(text)
            // No envelope yet. Whatever sits before the first brace is the model talking, and that
            // is a perfectly good reply; from the brace onwards it is the envelope, and no part of
            // an envelope may ever reach the screen — not even for the one frame before it closes.
            ?: return text.substringBefore('{').trim()''')

sub("data/NimClient.kt", '''    internal fun parseTurn(raw: String): AssistantTurn {
        val json = raw.replace(FENCE, "").trim()
        // No envelope at all: the model just talked. That is a valid turn with no search in it.
        if (!json.startsWith("{")) return AssistantTurn(say = cleanReply(json))
        val decoded = runCatching { AppJson.decodeFromString(AssistantTurn.serializer(), json) }.getOrNull()
        val turn = decoded ?: AssistantTurn(say = SAY_FIELD.find(json)?.groupValues?.get(1)?.let(::unescape).orEmpty())
        val say = cleanReply(turn.say).ifBlank { cleanReply(strippedProse(json)) }
        return turn.copy(say = say, search = turn.search.trim().take(120))
    }
''', '''    internal fun parseTurn(raw: String): AssistantTurn {
        val text = raw.replace(FENCE, "").trim()
        // Take the envelope wherever it sits, and repair it if the generation stopped early.
        // Requiring the reply to BEGIN with a brace is the bug people actually saw: a model that
        // writes "Sure, here you go:" before its JSON — and they all do, eventually — failed that
        // test, and the entire envelope, braces and keys and all, was printed into the bubble as
        // if it were the reply. No envelope anywhere means the model simply talked, which is a
        // valid turn with no search in it.
        val json = extractJsonObject(text)?.let(::escapeControlChars)
            ?: return AssistantTurn(say = cleanReply(text))
        val decoded = runCatching { AppJson.decodeFromString(AssistantTurn.serializer(), json) }.getOrNull()
        // A strict decode fails for reasons that have nothing to do with the fields we act on: one
        // wrong type ("places":["1"]), a key we have never heard of, a literal newline inside the
        // prose, a generation cut off mid-object. Every one of those used to keep the sentence and
        // silently drop the search and the cited places — so the model answered with restaurants
        // and the app showed none, which is exactly what "it isn't handling the JSON" looks like.
        val turn = decoded ?: salvage(json)
        val say = cleanReply(turn.say).ifBlank { cleanReply(strippedProse(json)) }
        return turn.copy(
            say = say,
            search = turn.search.trim().take(120),
            places = turn.places.filter { it > 0 }.distinct().take(6),
        )
    }

    /** Reads the fields we act on straight out of an object the strict decode refused. */
    private fun salvage(json: String) = AssistantTurn(
        say = SAY_FIELD.find(json)?.groupValues?.get(1)?.let(::unescape)
        // No closing quote: the generation stopped inside the sentence. What follows the opening
        // quote is still the sentence, and half a reply beats an error message.
            ?: SAY_OPEN.find(json)?.let { unescape(json.substring(it.range.last + 1)) }.orEmpty(),
        search = SEARCH_FIELD.find(json)?.groupValues?.get(1)?.let(::unescape).orEmpty(),
        places = PLACES_FIELD.find(json)?.groupValues?.get(1)
            ?.let { list -> NUMBER.findAll(list).mapNotNull { it.value.toIntOrNull() }.toList() }
            .orEmpty(),
    )
''')

sub("data/NimClient.kt", '''    /** Just the opening of that field, for reading a reply that has not finished arriving. */
    private val SAY_OPEN = Regex("\\"say\\"\\\\s*:\\\\s*\\"")
''', '''    /** Just the opening of that field, for reading a reply that has not finished arriving. */
    private val SAY_OPEN = Regex("\\"say\\"\\\\s*:\\\\s*\\"")

    /** The other two fields, for the same hand salvage. `places` is read as digits, not as JSON,
     *  because the shape the decode choked on is usually the shape of that very array. */
    private val SEARCH_FIELD = Regex("\\"search\\"\\\\s*:\\\\s*\\"((?:\\\\\\\\.|[^\\"\\\\\\\\])*)\\"")
    private val PLACES_FIELD = Regex("\\"places\\"\\\\s*:\\\\s*\\\\[([^\\\\]]*)\\\\]")
    private val NUMBER = Regex("\\\\d+")
''')

sub("data/NimClient.kt", '''            Reply with ONE JSON object and nothing else. No markdown, no code fences, no commentary.
            {"say":"","search":"","places":[],"profile":null}
''', '''            Reply with ONE JSON object and nothing else. No markdown, no code fences, no commentary.
            {"say":"","search":"","places":[],"profile":null}

            A good reply looks exactly like this, with nothing before it and nothing after it:
            {"say":"Number 2 is the one — proper charcoal yakitori, and it's four minutes' walk from you.","search":"","places":[2],"profile":null}
''')

# ---------------------------------------------------------------- Detail screen
sub("ui/detail/PlaceDetailScreen.kt", '''import kotlinx.coroutines.launch
''', '''import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.launch
''')

sub("ui/detail/PlaceDetailScreen.kt", '''import space.gexemy.tasteroute.data.FactLabels
''', '''import space.gexemy.tasteroute.data.FactLabels
import space.gexemy.tasteroute.data.Hours
import space.gexemy.tasteroute.data.OsmDetails
''')

sub("ui/detail/PlaceDetailScreen.kt", '''    var facts by remember(place.id) { mutableStateOf(place.facts ?: PlaceFacts()) }
''', '''    var facts by remember(place.id) { mutableStateOf(place.facts ?: PlaceFacts()) }
    // Kept apart from [facts] rather than merged on arrival, because these two land in either
    // order and a merge that depends on which won is a merge that is wrong half the time.
    var osmFacts by remember(place.id) { mutableStateOf(PlaceFacts()) }
''')

sub("ui/detail/PlaceDetailScreen.kt", '''    LaunchedEffect(place.id) {
        if (!GexemyClient.isConfigured) return@LaunchedEffect
        runCatching { GexemyClient.pulseDetail(place.id) }.onSuccess {
            pulse = it.pulse ?: pulse
            byHour = it.byHour
        }
        runCatching { CrowdRepository.refresh(listOf(place.id)) }
        signals = CrowdRepository.snapshotAllergens(place.id).ifEmpty { signals }
        runCatching { GexemyClient.photosFor(place.id) }.onSuccess { list ->
            if (list.isNotEmpty()) photos = list.map { it.url }
        }
        runCatching { GexemyClient.reviewsFor(place.id, place.coordinates) }.onSuccess { reviews = it }
        runCatching { GexemyClient.yelpFor(place.id, place.coordinates, place.name) }.onSuccess { info ->
            if (info != null) {
                yelp = info
                CrowdRepository.noteYelp(place.id, info)
            }
        }
        // The only place the expensive connectors are allowed to spend a call. Tripadvisor bills
        // four per place and Google's reviews sit in its priciest tier, so this route exists so
        // that opening a place pays for depth and scrolling a feed never does.
        runCatching {
            GexemyClient.sourcesFor(place.id, place.coordinates, place.name, place.webUrl)
        }.onSuccess { (found, merged) ->
            if (found.isNotEmpty()) {
                sources = found
                CrowdRepository.noteSources(place.id, found)
            }
            facts = merged
            // A photo from the venue's own site is usually the best one there is, and OSM carries
            // none for most places — so it leads only when we have nothing of our own.
            if (photos.isEmpty()) {
                photos = found.flatMap { source -> source.photos.map { it.url } }.distinct().take(8)
            }
        }
    }
''', '''    // NOTHING HERE WAITS ON ANYTHING ELSE. These six fetches are independent and used to run in a
    // line — pulse, crowd, photos, reviews, Yelp, and only then sources, the one that carries the
    // hours, the phone number and most of the photographs. Each of the five ahead of it can spend
    // a ten-second read timeout before failing, so a place could sit there with no details at all
    // while the request that would have filled them in had not been sent yet. It was never missing
    // data; it was data nobody had asked for.
    LaunchedEffect(place.id) {
        // Runs whether or not our own API is configured or reachable: OSM answers for most venues,
        // needs no key, and is the difference between a detail screen and a name with a map pin.
        val fromMap = async { OsmDetails.forPlace(place.id) }

        val fetches: List<Job> = if (!GexemyClient.isConfigured) emptyList() else listOf(
            launch {
                runCatching { GexemyClient.pulseDetail(place.id) }.onSuccess {
                    pulse = it.pulse ?: pulse
                    byHour = it.byHour
                }
            },
            launch {
                runCatching { CrowdRepository.refresh(listOf(place.id)) }
                signals = CrowdRepository.snapshotAllergens(place.id).ifEmpty { signals }
            },
            launch {
                runCatching { GexemyClient.photosFor(place.id) }.onSuccess { list ->
                    // Ours lead, they do not replace: the card's own photo is a real photograph of
                    // this place and throwing it away left galleries with one image in them.
                    if (list.isNotEmpty()) photos = (list.map { it.url } + photos).distinct().take(12)
                }
            },
            launch {
                runCatching { GexemyClient.reviewsFor(place.id, place.coordinates) }.onSuccess { reviews = it }
            },
            launch {
                runCatching { GexemyClient.yelpFor(place.id, place.coordinates, place.name) }.onSuccess { info ->
                    if (info != null) {
                        yelp = info
                        CrowdRepository.noteYelp(place.id, info)
                    }
                }
            },
            // The only place the expensive connectors are allowed to spend a call. Tripadvisor bills
            // four per place and Google's reviews sit in its priciest tier, so this route exists so
            // that opening a place pays for depth and scrolling a feed never does.
            launch {
                runCatching {
                    GexemyClient.sourcesFor(place.id, place.coordinates, place.name, place.webUrl)
                }.onSuccess { (found, merged) ->
                    if (found.isNotEmpty()) {
                        sources = found
                        CrowdRepository.noteSources(place.id, found)
                    }
                    facts = merged
                    // A photo from the venue's own site is usually the best one there is, and OSM
                    // carries none for most places — so these go after whatever we already have
                    // rather than only appearing when we have nothing.
                    val harvested = found.flatMap { source -> source.photos.map { it.url } }
                    if (harvested.isNotEmpty()) photos = (photos + harvested).distinct().take(12)
                }
            },
        )

        runCatching { fromMap.await() }.getOrNull()?.let { detail ->
            osmFacts = detail.facts
            detail.photo?.let { photos = (photos + it).distinct().take(12) }
        }
        fetches.joinAll()
    }
''')

sub("ui/detail/PlaceDetailScreen.kt", '''                place.openingHours?.let {
                    Section("Hours") {
                        Text(it, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
''', '''                HoursSection(place.openingHours, facts.fillFrom(osmFacts))
''')

sub("ui/detail/PlaceDetailScreen.kt", '''                DetailsSection(facts) { openUrl(context, it) }
''', '''                DetailsSection(facts.fillFrom(osmFacts)) { openUrl(context, it) }
''')

sub("ui/detail/PlaceDetailScreen.kt", '''            val hours = facts.hoursText.filterNot { PLACEHOLDER_HOURS.containsMatchIn(it) }
''', '''            val hours = facts.hoursLines
''')

sub("ui/detail/PlaceDetailScreen.kt", '''/**
 * `opens` and `closes` both at midnight is a CMS template nobody filled in, never a venue that is
 * open from midnight to midnight. Printing it produced a week of `Monday 00:00-00:00` on almost
 * every place with structured hours.
 */
private val PLACEHOLDER_HOURS = Regex("00:00\\\\s*[-\\\\u2013]\\\\s*00:00")
''', '''/**
 * The map's own `opening_hours`, for the wait between opening a place and the harvested schedule
 * arriving — or forever, for the many venues no source has anything to say about.
 *
 * The tag is a machine syntax and was being printed verbatim at people. [Hours] turns it into day
 * lines and into the only part anyone reads, which is whether the place is open right now; when it
 * uses a corner of the specification we do not parse, the original string is shown unchanged,
 * because a cryptic truth beats a confident wrong answer about somewhere being closed.
 */
@Composable
private fun HoursSection(raw: String?, facts: PlaceFacts) {
    // The harvested schedule is better and Details already renders it. Two hour lists on one
    // screen, disagreeing, is worse than either of them alone.
    if (facts.hoursLines.isNotEmpty()) return
    val text = raw?.takeIf { it.isNotBlank() } ?: return
    val schedule = remember(text) { Hours.parse(text) }
    Section("Hours") {
        if (schedule == null) {
            Text(text, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            return@Section
        }
        Column {
            Text(
                if (schedule.openNow) "Open now" else "Closed now",
                style = MaterialTheme.typography.labelLarge,
                color = if (schedule.openNow) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
            )
            Spacer(Modifier.height(4.dp))
            schedule.lines.forEach {
                Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
''')

failures = []
for path, old, new, count in edits:
    full = os.path.join(ROOT, path)
    with io.open(full, encoding="utf-8", newline="") as f:
        text = f.read()
    found = text.count(old)
    if found != count:
        failures.append("%s: expected %d match(es), found %d -> %s" % (path, count, found, old.strip().splitlines()[0][:70]))
        continue
    with io.open(full, "w", encoding="utf-8", newline="") as f:
        f.write(text.replace(old, new))
    print("ok   %-34s %s" % (path, old.strip().splitlines()[0][:60]))

if failures:
    print("\nFAILED:")
    for f in failures:
        print(" ", f)
    sys.exit(1)
print("\nall %d edits applied" % len(edits))
