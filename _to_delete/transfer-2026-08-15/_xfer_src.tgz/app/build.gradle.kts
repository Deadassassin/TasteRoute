import java.util.Properties

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.kotlin.serialization)
}

// Keys live in local.properties (gitignored). gradle.properties / -P overrides also work.
val secrets = Properties().apply {
    rootProject.file("local.properties").takeIf { it.exists() }?.reader(Charsets.UTF_8)?.use { load(it) }
}

fun secret(name: String, default: String = ""): String =
    (secrets.getProperty(name) ?: project.findProperty(name) as? String)?.trim().orEmpty().ifBlank { default }

android {
    namespace = "space.gexemy.tasteroute"
    compileSdk = 37

    defaultConfig {
        // Reverse-DNS of tasteroute.gexemy.space, the host already serving this app's API.
        // Google Play hard-rejects anything under com.example, so this can never go back.
        applicationId = "space.gexemy.tasteroute"
        minSdk = 23
        targetSdk = 37
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables { useSupportLibrary = true }

        buildConfigField("String", "GEXEMY_BASE_URL", "\"${secret("GEXEMY_BASE_URL")}\"")
        buildConfigField("String", "NIM_API_KEY", "\"${secret("NIM_API_KEY")}\"")
        buildConfigField("String", "NIM_BASE_URL", "\"${secret("NIM_BASE_URL", "https://integrate.api.nvidia.com/v1")}\"")
        // NIM_MODEL pins one model and skips probing. Leave it empty and NIM_MODELS is raced.
        buildConfigField("String", "NIM_MODEL", "\"${secret("NIM_MODEL")}\"")
        buildConfigField(
            "String",
            "NIM_MODELS",
            "\"${secret("NIM_MODELS", "meta/llama-3.1-8b-instruct,qwen/qwen-2.5-7b-instruct,mistralai/mistral-7b-instruct-v0.3,meta/llama-3.3-70b-instruct")}\"",
        )
    }

    buildTypes {
        release {
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            // material-icons-extended and osmdroid both ship far more than this app uses; without
            // shrinking, the release APK is roughly double what a low-end phone needs to download.
            optimization {
                enable = true
            }
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    packaging {
        resources {
            excludes += setOf(
                "/META-INF/{AL2.0,LGPL2.1}",
                "/META-INF/DEPENDENCIES",
                "/META-INF/*.version",
                "DebugProbesKt.bin",
                "kotlin-tooling-metadata.json",
            )
        }
    }
}

dependencies {
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.material3.adaptive.navigation.suite)
    implementation(libs.androidx.compose.material.icons.core)
    implementation(libs.androidx.compose.material.icons.extended)
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.ui.text.google.fonts)
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.navigation.compose)
    implementation(libs.kotlinx.serialization.json)
    implementation(libs.osmdroid.android)
    implementation(libs.play.services.location)
    implementation(libs.coil.compose)
    testImplementation(libs.junit)
    androidTestImplementation(platform(libs.androidx.compose.bom))
    androidTestImplementation(libs.androidx.compose.ui.test.junit4)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(libs.androidx.junit)
    debugImplementation(libs.androidx.compose.ui.test.manifest)
    debugImplementation(libs.androidx.compose.ui.tooling)
}
