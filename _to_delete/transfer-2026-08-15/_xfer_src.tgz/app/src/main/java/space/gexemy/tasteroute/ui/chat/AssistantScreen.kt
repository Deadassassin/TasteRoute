package space.gexemy.tasteroute.ui.chat

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.AssistChip
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import space.gexemy.tasteroute.data.AppState
import space.gexemy.tasteroute.data.ChatMessage
import space.gexemy.tasteroute.data.ChatTurn
import space.gexemy.tasteroute.data.Entitlements
import space.gexemy.tasteroute.data.NimClient
import space.gexemy.tasteroute.data.Openers
import space.gexemy.tasteroute.data.RecommendationRequest
import space.gexemy.tasteroute.data.Recommender
import space.gexemy.tasteroute.data.RestaurantResult
import space.gexemy.tasteroute.data.ResultSource
import space.gexemy.tasteroute.data.TasteAi
import space.gexemy.tasteroute.data.Tier
import space.gexemy.tasteroute.ui.components.LocationBanner
import space.gexemy.tasteroute.ui.components.RestaurantCard
import space.gexemy.tasteroute.ui.components.ThinkingDots
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** How many of the places already on screen the model is allowed to see and talk about. */
private const val GROUNDING_LIMIT = 12

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AssistantScreen(onOpenPlace: () -> Unit) {
    val tier = AppState.tier
    val messages = AppState.chatMessages
    val listState = rememberLazyListState()
    var input by remember { mutableStateOf("") }

    val scope = rememberCoroutineScope()
    var thinking by remember { mutableStateOf(false) }

    // The reply as it is being written. Kept out of the persisted message list on purpose: a
    // half-finished sentence has no business in the chat log if the process dies mid-stream.
    var streaming by remember { mutableStateOf<String?>(null) }

    // Rebuilt every time the screen is entered, from this person's taste and the time of day.
    // A fixed four-item list was the same four questions forever, which taught people the
    // assistant had exactly four things to say.
    val suggestions = remember(AppState.profile) { Openers.forProfile(AppState.profile) }

    fun say(text: String) = AppState.addChat(ChatMessage(fromUser = false, text = text))

    /**
     * Runs the place lookup the model asked for and folds the results into the reply it already
     * wrote. Separate from the conversation turn on purpose: the prose is on screen the moment the
     * model finishes writing it, and the restaurants slide in underneath a second or two later
     * rather than holding the whole reply hostage to a places call.
     */
    suspend fun attachPlaces(index: Int, query: String, keep: List<RestaurantResult>) {
        val reply = messages.getOrNull(index) ?: return
        val origin = AppState.origin
        if (origin == null) {
            AppState.replaceChat(
                index,
                reply.copy(
                    searching = false,
                    text = reply.text + "\n\nI need your location before I can pull up actual places — " +
                        "tap Allow on the banner above and ask me again.",
                ),
            )
            return
        }
        val cap = Entitlements.aiQueriesPerDay(tier)
        if (AppState.aiQueriesUsedToday >= cap) {
            AppState.replaceChat(
                index,
                reply.copy(
                    searching = false,
                    text = reply.text + "\n\nThat's your $cap free place searches for today, though — " +
                        "Plus lifts the cap. We can keep talking either way.",
                ),
            )
            return
        }
        AppState.aiQueriesUsedToday++

        val outcome = Recommender.recommend(
            RecommendationRequest(
                origin = origin,
                profile = AppState.profile,
                query = query,
                source = ResultSource.AI_CHAT,
                tier = tier,
                allergens = AppState.allergens.toList(),
            ),
            cityLabel = AppState.cityLabel,
        )
        // Places it named from what was already on screen lead, because it actually meant those.
        val merged = (keep + outcome.results).distinctBy { it.id }
        AppState.replaceChat(
            index,
            reply.copy(
                searching = false,
                results = merged,
                text = if (merged.isEmpty()) {
                    reply.text + "\n\nNothing nearby matched that" +
                        (outcome.error?.let { " ($it)" } ?: "") + " — want me to widen it?"
                } else {
                    reply.text
                },
            ),
        )
    }

    fun send(text: String) {
        val prompt = text.trim()
        if (prompt.isBlank() || thinking) return
        AppState.addChat(ChatMessage(fromUser = true, text = prompt))
        input = ""

        if (!NimClient.chatReady) {
            say(
                if (NimClient.isConfigured) {
                    "I can't reach my language model right now (${NimClient.lastFailure ?: "no connection"}). " +
                        "Discover still works — it ranks places on the phone without me."
                } else {
                    "I'm not switched on yet — NIM_API_KEY is missing. Everything else in the app works without me."
                }
            )
            return
        }

        thinking = true
        streaming = ""
        // What the app already knows is around this person. Without it the model was answering
        // "what's good near me" from nothing while a screenful of real, ranked places sat one tab
        // away — and its only honest move was to refuse.
        val nearby = AppState.lastResults.ifEmpty { AppState.warmResults }.take(GROUNDING_LIMIT)

        scope.launch {
            val turn = runCatching {
                NimClient.converse(
                    history = messages.map { ChatTurn(it.fromUser, it.text) },
                    profile = AppState.profile,
                    allergens = AppState.allergens.toList(),
                    cityLabel = AppState.cityLabel,
                    nearby = nearby,
                    onDelta = { partial -> streaming = partial },
                )
            }.getOrElse {
                thinking = false
                streaming = null
                say("I lost that one — ${NimClient.lastFailure ?: it.message ?: "no reply"}. Ask me again?")
                return@launch
            }

            // A stated, lasting preference updates the profile the whole app scores on. One meal's
            // craving must not: "I fancy Thai tonight" is not "I am now a Thai person".
            turn.profile?.let { hint ->
                val next = TasteAi.merge(hint, AppState.profile)
                if (next != AppState.profile) AppState.applyProfile(next)
            }

            // Indices into the list it was shown, resolved back to the real objects. The model
            // never produces a name, an address or a rating — only a number.
            val cited = turn.places.mapNotNull { nearby.getOrNull(it - 1) }.distinctBy { it.id }
            val wantsPlaces = turn.search.isNotBlank()
            val index = messages.size
            AppState.addChat(
                ChatMessage(
                    fromUser = false,
                    // Two different blanks. If it asked for places but wrote no introduction, the
                    // cards ARE the answer and "tell me more" sitting above them reads as a
                    // non-sequitur; if it wrote nothing at all, there is genuinely nothing to show.
                    text = turn.say.ifBlank {
                        if (wantsPlaces || cited.isNotEmpty()) "Here's what I found for that:"
                        else "Tell me a bit more and I'll take a proper run at it."
                    },
                    results = cited,
                    searching = wantsPlaces,
                )
            )
            thinking = false
            streaming = null
            if (wantsPlaces) runCatching { attachPlaces(index, turn.search, cited) }
        }
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
    }

    LaunchedEffect(streaming != null) {
        while (streaming != null) {
            listState.scrollToItem((listState.layoutInfo.totalItemsCount - 1).coerceAtLeast(0))
            delay(140)
        }
    }

    Column(Modifier.fillMaxSize().imePadding().padding(horizontal = 16.dp)) {
        Row(
            Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text("Assistant", style = MaterialTheme.typography.headlineSmall, maxLines = 1)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        if (thinking) "Thinking" else "Ask me anything about food",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                    )
                    if (thinking && streaming.isNullOrEmpty()) {
                        Spacer(Modifier.width(6.dp))
                        ThinkingDots()
                    }
                }
            }
            if (messages.isNotEmpty()) {
                TextButton(onClick = { AppState.clearChat() }) { Text("New chat", maxLines = 1) }
            }
        }

        LocationBanner(Modifier.padding(bottom = 8.dp))

        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (messages.isEmpty()) {
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        AssistantSurface {
                            Text(
                                "Hey. I can talk food, work around a diet, or go find you somewhere to eat — " +
                                    "whichever you're after.",
                                Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                style = MaterialTheme.typography.bodyLarge,
                            )
                        }
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp),
                        ) {
                            suggestions.forEach { s ->
                                AssistChip(onClick = { send(s) }, label = { Text(s, maxLines = 2) })
                            }
                        }
                    }
                }
            }
            itemsIndexed(messages) { index, msg ->
                if (msg.fromUser) UserBubble(msg.text) else AssistantBubble(msg, tier, onOpenPlace)
                if (index == messages.lastIndex && msg.searching) SearchingRow()
            }
            streaming?.takeIf { it.isNotEmpty() }?.let { partial ->
                item("streaming") {
                    AssistantSurface {
                        TypingText(
                            partial,
                            MaterialTheme.typography.bodyLarge,
                            Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        )
                    }
                }
            }
        }

        if (tier == Tier.FREE) {
            val cap = Entitlements.aiQueriesPerDay(Tier.FREE)
            Text(
                // Talking is free; only a real places lookup is metered, because that is the part
                // with a cost attached. A conversation that runs out after five messages is not a
                // conversation, it is a trial.
                "Chat is unlimited · ${(cap - AppState.aiQueriesUsedToday).coerceAtLeast(0)} of $cap " +
                    "place searches left today",
                Modifier.align(Alignment.CenterHorizontally).padding(vertical = 4.dp),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        Row(Modifier.padding(bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Ask, or just say what you're after…", maxLines = 1) },
                shape = RoundedCornerShape(24.dp),
                maxLines = 4,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { send(input) }),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                ),
            )
            Spacer(Modifier.width(8.dp))
            FilledIconButton(onClick = { send(input) }, enabled = !thinking) {
                Icon(Icons.AutoMirrored.Filled.Send, "Send")
            }
        }
    }
}

/**
 * Reveals text at a readable rate instead of pasting it.
 *
 * Even a real token stream arrives in lumps — a network buffer flushes and forty characters land
 * on one frame, which looks like stuttering rather than writing. This drains whatever has arrived
 * at a steady pace, so a fast reply and a slow one both read as someone typing. It never falls
 * behind: the step scales with how much is waiting, so it always catches up within a few frames.
 */
@Composable
private fun TypingText(full: String, style: TextStyle, modifier: Modifier = Modifier) {
    var shown by remember { mutableStateOf(0) }
    LaunchedEffect(full) {
        while (shown < full.length) {
            shown += ((full.length - shown) / 6).coerceIn(1, 5)
            delay(16)
        }
    }
    Text(full.take(shown.coerceAtMost(full.length)), modifier, style = style)
}

@Composable
private fun SearchingRow() {
    Row(Modifier.padding(start = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(
            "Finding places",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
        )
        Spacer(Modifier.width(6.dp))
        ThinkingDots()
    }
}

@Composable
private fun AssistantSurface(content: @Composable () -> Unit) {
    Surface(
        shape = RoundedCornerShape(20.dp, 20.dp, 20.dp, 6.dp),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 1.dp,
        content = content,
    )
}

@Composable
private fun UserBubble(text: String) {
    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterEnd) {
        Surface(shape = RoundedCornerShape(20.dp, 20.dp, 6.dp, 20.dp), color = MaterialTheme.colorScheme.primary) {
            Text(
                text,
                Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                color = MaterialTheme.colorScheme.onPrimary,
                style = MaterialTheme.typography.bodyLarge,
            )
        }
    }
}

@Composable
private fun AssistantBubble(msg: ChatMessage, tier: Tier, onOpenPlace: () -> Unit) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        AssistantSurface {
            Text(
                msg.text,
                Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                style = MaterialTheme.typography.bodyLarge,
            )
        }
        msg.results.forEach { r ->
            RestaurantCard(
                result = r,
                userTier = tier,
                isFavorite = r.id in AppState.favorites,
                onToggleFavorite = { AppState.toggleFavorite(r.id) },
                onClick = {
                    AppState.selectedRestaurant = r
                    onOpenPlace()
                },
                showReasoning = true,
            )
        }
    }
}
