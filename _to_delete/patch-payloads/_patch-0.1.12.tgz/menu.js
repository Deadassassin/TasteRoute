/**
 * Dishes, from the restaurant's own schema.org markup and from nowhere else.
 *
 * THE RULE THIS FILE EXISTS TO ENFORCE: a dish name we show as being on a menu must be a dish the
 * venue itself published as a `MenuItem`. No heuristics over page text, no "biggest <h3> in a div
 * whose class contains 'menu'", no guessing from the cuisine tag. The app already has a perfectly
 * good way to suggest a dish it is not sure about — it labels it as a suggestion (see DishPicks on
 * the client). Anything harvested here is presented as fact, so it has to be one.
 *
 * That is also why yield will be low and must be allowed to stay low. Most restaurant sites render
 * their menu as a PDF, an image, or a third-party ordering widget, and none of those produce
 * structured data. An empty list is the correct answer for those, forever.
 *
 * 1.6.0 keeps every one of those rules and stops throwing away the rest of what the same markup
 * already contained. The walk used to collect twelve bare names because a card has room for one;
 * the app now has a menu screen, so it also keeps the SECTIONS the venue grouped its dishes into,
 * their descriptions, their prices and their published `suitableForDiet` claims. Same nodes, same
 * filters, same refusal to infer — a wider slice of the same truth.
 */

const NAME_MIN = 2;
const NAME_MAX = 90;
const SECTION_NAME_MAX = 80;
const DESC_MAX = 240;
/** What a card can show. `menu_items` stays exactly what it was so old clients see no change. */
const HIGHLIGHT_LIMIT = 12;
const SECTION_LIMIT = 24;
const SECTION_ITEM_LIMIT = 60;
const TOTAL_ITEM_LIMIT = 240;
const DEPTH_LIMIT = 10;

const asArray = (v) => (v == null ? [] : Array.isArray(v) ? v : [v]);
const typeOf = (node) => [].concat(node?.['@type'] ?? []).join(' ');

/**
 * Section headings and CMS filler that arrive typed as menu content.
 *
 * Sites mark up their sections as MenuItem constantly, so without this the "dish" surfaced for
 * half of them is the word "Desserts" — which reads, on a card, as the restaurant's signature
 * offering being a category name.
 *
 * It is applied to ITEMS ONLY. "Desserts" is a perfectly good section name, and a node carrying
 * children is treated as a section whatever it calls itself, so a site that types its headings as
 * MenuItem now gets a correctly grouped menu instead of having its headings thrown away.
 */
const NOT_A_DISH = new RegExp(
  '^(menus?|drinks?|beverages?|food|dishes|starters?|appetiz(er|ers)|small plates|mains?|entr[ée]es?|' +
  'sides?|desserts?|specials?|lunch|dinner|brunch|breakfast|kids|children|extras?|add[- ]?ons?|' +
  'sauces?|toppings?|sets?|combos?|platters?|available|see (more|menu)|view menu|order( online)?|' +
  'coming soon|tbd|n/?a|item|items|new|popular|featured|all)$',
  'i',
);

/** A name that is mostly digits and punctuation is a price row or an SKU, not a dish. */
const MOSTLY_NOISE = /^[^a-z]*$/i;

/** "Menu", "Our Full Menu" — true but useless as a heading above the only list on the screen. */
const GENERIC_SECTION = /^(the\s+)?(full\s+|main\s+|our\s+|restaurant\s+)*menus?$/i;

/** A node describing the business itself; its name is the restaurant, never a course. */
const BUSINESS = /restaurant|foodestablishment|localbusiness|cafe|bar|bakery|store|organization|webpage|website/i;

function clean(raw) {
  if (typeof raw !== 'string') return null;
  const name = raw.replace(/\s+/g, ' ').trim();
  if (name.length < NAME_MIN || name.length > NAME_MAX) return null;
  if (NOT_A_DISH.test(name)) return null;
  if (MOSTLY_NOISE.test(name)) return null;
  // A dish name with a sentence in it is a description that was put in the wrong field.
  if ((name.match(/[.!?]/g) ?? []).length > 1) return null;
  return name;
}

function sectionName(raw) {
  if (typeof raw !== 'string') return null;
  const name = raw.replace(/\s+/g, ' ').trim();
  if (!name || name.length > SECTION_NAME_MAX) return null;
  if (GENERIC_SECTION.test(name)) return null;
  return name;
}

function description(raw) {
  if (typeof raw !== 'string') return null;
  // Descriptions arrive with markup in them more often than they should.
  const text = raw.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
  if (text.length < 3) return null;
  return text.length > DESC_MAX ? `${text.slice(0, DESC_MAX - 1).trimEnd()}…` : text;
}

const SYMBOLS = { USD: '$', CAD: '$', AUD: '$', NZD: '$', EUR: '€', GBP: '£', JPY: '¥', CNY: '¥', INR: '₹' };

/**
 * A price string safe to print next to a dish.
 *
 * A bare `12` means nothing without its currency, and `priceCurrency` is a separate field that
 * plenty of sites omit — so a number with no currency anywhere is printed as the number and left
 * to the reader, never decorated with a guessed symbol.
 */
function formatPrice(raw, currency) {
  if (raw == null) return null;
  const text = String(raw).replace(/\s+/g, ' ').trim();
  if (!text || text.length > 24) return null;
  // Already carries its own currency mark or a range ("12–18"). Print it as published.
  if (/[^\d.,\s]/.test(text)) return /[a-z]{4,}/i.test(text) ? null : text;
  const value = Number(text.replace(/,/g, ''));
  if (!Number.isFinite(value) || value <= 0 || value > 100_000) return null;
  const code = String(currency ?? '').trim().toUpperCase();
  const amount = Number.isInteger(value) ? String(value) : value.toFixed(2);
  if (SYMBOLS[code]) return `${SYMBOLS[code]}${amount}`;
  return /^[A-Z]{3}$/.test(code) ? `${amount} ${code}` : amount;
}

function priceOf(node) {
  for (const offer of asArray(node.offers)) {
    if (!offer) continue;
    if (typeof offer !== 'object') {
      const flat = formatPrice(offer, node.priceCurrency);
      if (flat) return flat;
      continue;
    }
    const spec = offer.priceSpecification && typeof offer.priceSpecification === 'object'
      ? offer.priceSpecification
      : {};
    const found = formatPrice(
      offer.price ?? spec.price,
      offer.priceCurrency ?? spec.priceCurrency ?? node.priceCurrency,
    );
    if (found) return found;
  }
  return formatPrice(node.price, node.priceCurrency);
}

const DIETS = {
  vegan: 'Vegan',
  vegetarian: 'Vegetarian',
  glutenfree: 'Gluten-free',
  halal: 'Halal',
  kosher: 'Kosher',
  diabetic: 'Diabetic',
  lowlactose: 'Low lactose',
  lowcalorie: 'Low calorie',
  lowfat: 'Low fat',
  lowsalt: 'Low salt',
};

/** `suitableForDiet` is the venue's own published claim about its own dish, so it is quotable. */
function dietsOf(node) {
  const out = [];
  for (const raw of asArray(node.suitableForDiet)) {
    const text = typeof raw === 'object' ? (raw?.['@id'] ?? raw?.name ?? '') : raw;
    const key = String(text ?? '').split(/[/#]/).pop().replace(/diet$/i, '').replace(/[\s_-]/g, '')
      .toLowerCase();
    const label = DIETS[key];
    if (label && !out.includes(label)) out.push(label);
  }
  return out;
}

/**
 * The whole menu reachable from a set of already-flattened JSON-LD nodes.
 *
 * Returns `{ sections, items, total, truncated }`: `sections` is what the menu screen renders,
 * `items` is the flat, capped highlight list the cards have always used.
 *
 * `itemListElement` is followed ONLY once we are inside a menu. It is also how breadcrumbs, site
 * navigation and product carousels are marked up, and pulling those in would put "Contact Us" on a
 * restaurant card as its recommended dish.
 */
export function menuFrom(nodes) {
  const sections = [];
  let total = 0;
  let truncated = false;

  const sectionFor = (name) => {
    const key = (name ?? '').toLowerCase();
    const found = sections.find((s) => s.key === key);
    if (found) return found;
    if (sections.length >= SECTION_LIMIT) {
      truncated = true;
      return null;
    }
    const made = { key, name: name ?? '', items: [], seen: new Set() };
    sections.push(made);
    return made;
  };

  const addDish = (node, label) => {
    if (total >= TOTAL_ITEM_LIMIT) {
      truncated = true;
      return;
    }
    const isObject = node && typeof node === 'object';
    const name = clean(isObject ? node.name : node);
    if (!name) return;
    const section = sectionFor(label);
    if (!section) return;
    const key = name.toLowerCase();
    // Deduped WITHIN a section, not across the menu: a kitchen that lists the same plate under
    // Lunch and under Dinner has published it twice on purpose.
    if (section.seen.has(key)) return;
    if (section.items.length >= SECTION_ITEM_LIMIT) {
      truncated = true;
      return;
    }
    section.seen.add(key);
    total += 1;
    const dish = { name };
    if (isObject) {
      const text = description(node.description);
      const price = priceOf(node);
      const diet = dietsOf(node);
      if (text) dish.description = text;
      if (price) dish.price = price;
      if (diet.length) dish.diet = diet;
    }
    section.items.push(dish);
  };

  const walk = (node, depth, inMenu, label) => {
    if (!node || typeof node !== 'object' || depth > DEPTH_LIMIT || total >= TOTAL_ITEM_LIMIT) return;
    const type = typeOf(node);
    const here = inMenu || /\bmenu\b|menusection|menuitem/i.test(type);

    const children = [...asArray(node.hasMenuItem)];
    if (here) {
      for (const child of asArray(node.itemListElement)) {
        if (child && typeof child === 'object') {
          children.push(/listitem/i.test(typeOf(child)) && child.item ? child.item : child);
        } else if (child) {
          children.push(child);
        }
      }
    }

    // A MenuItem with nothing under it is a dish. A node WITH menu children is a section, whatever
    // its @type says — which is how a site that types its headings as MenuItem still groups right.
    if (/menuitem/i.test(type) && !children.length) {
      addDish(node, label);
      return;
    }

    const mine = here && !BUSINESS.test(type) ? (sectionName(node.name) ?? label) : label;

    for (const key of ['hasMenu', 'menu', 'hasMenuSection']) {
      for (const child of asArray(node[key])) {
        // `hasMenu` is frequently just a URL to the menu page — that is handled by the caller,
        // which may fetch it; there is nothing to walk here.
        if (child && typeof child === 'object') walk(child, depth + 1, true, mine);
      }
    }
    for (const child of children) {
      if (child && typeof child === 'object') walk(child, depth + 1, true, mine);
      else addDish(child, mine);
    }
  };

  for (const node of nodes) walk(node, 0, false, '');

  const items = [];
  const seen = new Set();
  for (const section of sections) {
    for (const dish of section.items) {
      const key = dish.name.toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);
      items.push(dish.name);
    }
  }

  return {
    sections: sections
      .filter((s) => s.items.length)
      .map((s) => ({ name: s.name, items: s.items })),
    items: items.slice(0, HIGHLIGHT_LIMIT),
    total: items.length,
    truncated,
  };
}

/** The flat highlight list on its own, unchanged since 1.3.0 and still what a card renders. */
export function menuItemsFrom(nodes) {
  return menuFrom(nodes).items;
}

/**
 * The URL a venue points at for its menu, if it is worth fetching.
 *
 * Restricted to the venue's own domain on purpose. Most sites link their menu out to an ordering
 * platform — Toast, Square, ChowNow — and those pages are client-rendered, usually disallow bots,
 * and are somebody else's property rather than the restaurant's own publication. Following them
 * would be scraping a third party, which is the line this project has already drawn and kept.
 */
export function sameSiteMenuUrl(rawMenu, pageUrl) {
  if (typeof rawMenu !== 'string' || !rawMenu) return null;
  // `hasMenu` is a free-text field in practice — "Our menu changes daily" is a real value people
  // put there. Resolved against the page it becomes a plausible-looking relative path, so require
  // it to actually look like a URL before treating it as one.
  if (!/^(https?:)?\/\/|^\.{0,2}\//i.test(rawMenu)) return null;
  let url;
  try {
    url = new URL(rawMenu, pageUrl);
  } catch {
    return null;
  }
  if (url.protocol !== 'https:' && url.protocol !== 'http:') return null;
  const host = url.hostname.replace(/^www\./i, '').toLowerCase();
  const base = pageUrl.hostname.replace(/^www\./i, '').toLowerCase();
  if (host !== base && !host.endsWith(`.${base}`)) return null;
  // Already read it.
  if (url.toString() === pageUrl.toString()) return null;
  // A PDF or an image menu has nothing machine-readable in it, and fetching it wastes the budget.
  if (/\.(pdf|jpe?g|png|webp|gif|docx?)$/i.test(url.pathname)) return null;
  return url;
}
