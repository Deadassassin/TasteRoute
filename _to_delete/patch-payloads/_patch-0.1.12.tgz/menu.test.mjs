import { menuFrom, menuItemsFrom, sameSiteMenuUrl } from './menu.js';

let pass = 0, fail = 0;
const eq = (label, got, want) => {
  const a = JSON.stringify(got), b = JSON.stringify(want);
  if (a === b) { pass++; return; }
  fail++;
  console.log(`FAIL ${label}\n  got  ${a}\n  want ${b}`);
};

// 1. Sections with prices, descriptions and diet.
eq('sections', menuFrom([{
  '@type': 'Restaurant',
  name: 'Somewhere',
  hasMenu: {
    '@type': 'Menu',
    name: 'Our Full Menu',
    hasMenuSection: [
      {
        '@type': 'MenuSection',
        name: 'Starters',
        hasMenuItem: [
          { '@type': 'MenuItem', name: 'Padrón peppers', description: 'Blistered, sea salt.', offers: { '@type': 'Offer', price: '8.50', priceCurrency: 'USD' }, suitableForDiet: 'https://schema.org/VeganDiet' },
          { '@type': 'MenuItem', name: 'Croquetas', offers: [{ price: 9, priceCurrency: 'EUR' }] },
        ],
      },
      {
        '@type': 'MenuSection',
        name: 'Mains',
        hasMenuItem: [{ '@type': 'MenuItem', name: 'Ribeye', offers: { price: '42' } }],
      },
    ],
  },
}]).sections, [
  { name: 'Starters', items: [
    { name: 'Padrón peppers', description: 'Blistered, sea salt.', price: '$8.50', diet: ['Vegan'] },
    { name: 'Croquetas', price: '€9' },
  ] },
  { name: 'Mains', items: [{ name: 'Ribeye', price: '42' }] },
]);

// 2. Generic menu name is not a section heading; items land unnamed.
eq('generic-name', menuFrom([{
  '@type': 'Menu', name: 'Menu',
  hasMenuItem: [{ '@type': 'MenuItem', name: 'Pad Thai' }],
}]).sections, [{ name: '', items: [{ name: 'Pad Thai' }] }]);

// 3. Headings typed as MenuItem become sections because they carry children.
eq('heading-as-item', menuFrom([{
  '@type': 'Menu',
  hasMenuItem: [{
    '@type': 'MenuItem', name: 'Desserts',
    hasMenuItem: [{ '@type': 'MenuItem', name: 'Basque cheesecake' }],
  }],
}]).sections, [{ name: 'Desserts', items: [{ name: 'Basque cheesecake' }] }]);

// 4. A bare heading with no children is still dropped.
eq('heading-alone', menuFrom([{
  '@type': 'Menu',
  hasMenuItem: [{ '@type': 'MenuItem', name: 'Desserts' }, { '@type': 'MenuItem', name: 'Tiramisu' }],
}]).items, ['Tiramisu']);

// 5. Breadcrumbs must not be followed: itemListElement outside a menu is ignored.
eq('breadcrumbs', menuFrom([{
  '@type': 'BreadcrumbList',
  itemListElement: [{ '@type': 'ListItem', item: { '@type': 'MenuItem', name: 'Contact Us' } }],
}]).items, []);

// 6. itemListElement INSIDE a menu is followed, ListItem unwrapped.
eq('itemlist-in-menu', menuFrom([{
  '@type': 'Menu', name: 'Brunch',
  itemListElement: [{ '@type': 'ListItem', item: { '@type': 'MenuItem', name: 'Shakshuka', offers: { price: '14', priceCurrency: 'GBP' } } }],
}]).sections, [{ name: 'Brunch', items: [{ name: 'Shakshuka', price: '£14' }] }]);

// 7. Bare strings under hasMenuItem.
eq('bare-strings', menuFrom([{ '@type': 'Menu', hasMenuItem: ['Pho tai', 'Banh mi', 'Drinks'] }]).items,
  ['Pho tai', 'Banh mi']);

// 8. Dedupe within a section, kept across sections.
const dup = menuFrom([{
  '@type': 'Menu',
  hasMenuSection: [
    { '@type': 'MenuSection', name: 'Lunch', hasMenuItem: [{ name: 'Katsu curry', '@type': 'MenuItem' }, { name: 'katsu CURRY', '@type': 'MenuItem' }] },
    { '@type': 'MenuSection', name: 'Dinner', hasMenuItem: [{ name: 'Katsu curry', '@type': 'MenuItem' }] },
  ],
}]);
eq('dedupe-section', dup.sections.map((s) => s.items.length), [1, 1]);
eq('dedupe-flat', dup.items, ['Katsu curry']);

// 9. Restaurant name never becomes a section label.
eq('business-name', menuFrom([{
  '@type': 'Restaurant', name: "Katz's Delicatessen",
  hasMenu: { '@type': 'Menu', hasMenuItem: [{ '@type': 'MenuItem', name: 'Pastrami on rye' }] },
}]).sections, [{ name: '', items: [{ name: 'Pastrami on rye' }] }]);

// 10. Highlight list stays capped at 12; total counts the rest.
const many = menuFrom([{
  '@type': 'Menu',
  hasMenuItem: Array.from({ length: 30 }, (_, i) => ({ '@type': 'MenuItem', name: `Dish number ${i}` })),
}]);
eq('cap-highlights', many.items.length, 12);
eq('cap-total', many.total, 30);

// 11. Descriptions with markup and over-length are cleaned.
const long = 'x'.repeat(400);
const d = menuFrom([{ '@type': 'Menu', hasMenuItem: [{ '@type': 'MenuItem', name: 'Thing', description: `<b>a</b>  b ${long}` }] }]);
eq('desc-clean', d.sections[0].items[0].description.startsWith('a b xxx'), true);
eq('desc-cap', d.sections[0].items[0].description.length, 240);

// 12. Junk prices are dropped, published strings kept.
const p = (offers) => menuFrom([{ '@type': 'Menu', hasMenuItem: [{ '@type': 'MenuItem', name: 'Thing', offers }] }]).sections[0].items[0].price;
eq('price-zero', p({ price: '0' }), undefined);
eq('price-text', p({ price: 'Please call for pricing today' }), undefined);
eq('price-range', p({ price: '12–18' }), '12–18');
eq('price-symbol', p({ price: '$15' }), '$15');
eq('price-code', p({ price: '15', priceCurrency: 'SEK' }), '15 SEK');
eq('price-comma', p({ price: '1,250', priceCurrency: 'JPY' }), '¥1250');

// 13. A description in the name field is still rejected.
eq('name-sentence', menuFrom([{ '@type': 'Menu', hasMenuItem: [{ '@type': 'MenuItem', name: 'Great. Really good. Try it.' }] }]).items, []);

// 14. menuItemsFrom is unchanged behaviour.
eq('compat', menuItemsFrom([{ '@type': 'Menu', hasMenuItem: [{ '@type': 'MenuItem', name: 'Gyoza' }] }]), ['Gyoza']);

// 15. Empty in, empty out — and no crash on garbage.
eq('empty', menuFrom([]).sections, []);
eq('garbage', menuFrom([null, 'x', 42, { '@type': 'Menu', hasMenuItem: null }]).items, []);

// 16. Deeply nested sections keep the innermost heading.
eq('nested', menuFrom([{
  '@type': 'Menu',
  hasMenuSection: [{
    '@type': 'MenuSection', name: 'Drinks list',
    hasMenuSection: [{ '@type': 'MenuSection', name: 'Cocktails', hasMenuItem: [{ '@type': 'MenuItem', name: 'Negroni' }] }],
  }],
}]).sections, [{ name: 'Cocktails', items: [{ name: 'Negroni' }] }]);

// 17. sameSiteMenuUrl — unchanged rules.
const page = new URL('https://example.com/');
eq('url-free-text', sameSiteMenuUrl('Our menu changes daily', page), null);
eq('url-offsite', sameSiteMenuUrl('https://toasttab.com/x', page), null);
eq('url-pdf', sameSiteMenuUrl('/menu.pdf', page), null);
eq('url-ok', String(sameSiteMenuUrl('/menu', page)), 'https://example.com/menu');
eq('url-sub', String(sameSiteMenuUrl('https://order.example.com/menu', page)), 'https://order.example.com/menu');

console.log(`${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
