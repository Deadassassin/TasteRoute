#!/usr/bin/env python3
"""TasteRoute 0.1.12 — version, in-app menu, on-the-way gating, nav bar spacing.

Two-phase on purpose: every edit is validated into memory first and nothing is written until all
of them pass. A tree that is 11/14 patched compiles, which is worse than one that is untouched.
"""
import os
import sys

ANDROID = sys.argv[1] if len(sys.argv) > 1 else os.path.expanduser("~/mnt/TasteRoute")
API = sys.argv[2] if len(sys.argv) > 2 else os.path.expanduser("~/apisrc/accounts-api")
HERE = os.path.dirname(os.path.abspath(__file__))
KT = os.path.join(ANDROID, "app/src/main/java/space/gexemy/tasteroute")

edits = []  # (path, old, new)


def edit(path, old, new):
    edits.append((path, old, new))


def kt(rel):
    return os.path.join(KT, rel)


# ---------------------------------------------------------------- build.gradle.kts
edit(
    os.path.join(ANDROID, "app/build.gradle.kts"),
    """        versionCode = 1
        versionName = "1.0.0"
""",
    """        // 0.1.x until the first store build. Nothing has shipped, and a versionName of 1.0.0
        // on a tree that is still landing patches is a claim about maturity, not a number.
        versionCode = 12
        versionName = "0.1.12"
""",
)

# ---------------------------------------------------------------- MainActivity.kt
edit(
    kt("MainActivity.kt"),
    "import androidx.compose.foundation.layout.padding\n",
    "import androidx.compose.foundation.layout.offset\nimport androidx.compose.foundation.layout.padding\n",
)
edit(
    kt("MainActivity.kt"),
    "import androidx.compose.ui.platform.LocalContext\n",
    "import androidx.compose.ui.platform.LocalContext\nimport androidx.compose.ui.unit.dp\n",
)
edit(
    kt("MainActivity.kt"),
    "import space.gexemy.tasteroute.ui.detail.PlaceDetailScreen\n",
    "import space.gexemy.tasteroute.ui.detail.MenuScreen\nimport space.gexemy.tasteroute.ui.detail.PlaceDetailScreen\n",
)
edit(
    kt("MainActivity.kt"),
    'private const val REVIEW = "review"\n',
    'private const val REVIEW = "review"\nprivate const val MENU = "menu"\n',
)
edit(
    kt("MainActivity.kt"),
    "                                    label = { Text(tab.label) },\n",
    """                                    // Material leaves the label a full indicator's worth of
                                    // air below a 24dp icon, which reads as two unrelated controls
                                    // stacked. Nudged up rather than restyled: the item keeps its
                                    // own metrics and its touch target.
                                    label = { Text(tab.label, Modifier.offset(y = (-3).dp)) },
""",
)
edit(
    kt("MainActivity.kt"),
    """                        PlaceDetailScreen(
                            onBack = { nav.popBackStack() },
                            onRoute = { nav.navigate(ROUTE) },
""",
    """                        PlaceDetailScreen(
                            onBack = { nav.popBackStack() },
                            onRoute = { nav.navigate(ROUTE) },
                            onMenu = { nav.push(MENU) },
""",
)
edit(
    kt("MainActivity.kt"),
    """                    pushScreen(ROUTE) {
                        MapRouteScreen(
                            onBack = { nav.popBackStack() },
                            onNavigate = { nav.navigate(NAVIGATE) },
                            onOpenPlace = { nav.navigate(DETAIL) },
                            onUpgrade = { nav.push(SETTINGS) },
                        )
                    }
""",
    """                    pushScreen(MENU) {
                        MenuScreen(onBack = { nav.popBackStack() })
                    }
                    pushScreen(ROUTE) {
                        MapRouteScreen(
                            onBack = { nav.popBackStack() },
                            onNavigate = { nav.navigate(NAVIGATE) },
                            onOpenPlace = { nav.navigate(DETAIL) },
                        )
                    }
""",
)

# ---------------------------------------------------------------- HomeScreen.kt
edit(kt("ui/home/HomeScreen.kt"), "import androidx.compose.material.icons.filled.Lock\n", "")
edit(kt("ui/home/HomeScreen.kt"), "import space.gexemy.tasteroute.data.Entitlements\n", "")
edit(
    kt("ui/home/HomeScreen.kt"),
    "        if (origin == null || (mode == SearchMode.ON_THE_WAY && destination == null)) {\n",
    "        if (origin == null) {\n",
)
edit(
    kt("ui/home/HomeScreen.kt"),
    """        SearchModeRow(
            mode = mode,
            tier = tier,
            onMode = { next ->
                if (next == SearchMode.ON_THE_WAY && !Entitlements.canSearchCorridor(tier)) onUpgrade()
                else AppState.searchMode = next
            },
        )

        when (mode) {
            SearchMode.ON_THE_WAY -> PlaceField(
                label = AppState.destinationLabel,
                placeholder = "Where are you heading?",
                onLabel = { AppState.destinationLabel = it },
                onResolve = {
                    scope.launch {
                        val hit = LocationRepository.geocode(context, AppState.destinationLabel)
                        if (hit == null) {
                            AppState.destination = null
                            emptyMessage = "Couldn't find that address."
                        } else {
                            AppState.destination = hit.first
                            AppState.destinationLabel = hit.second
                        }
                    }
                },
            )

            SearchMode.ANYWHERE -> PlaceField(
""",
    """        SearchModeRow(mode = mode, onMode = { AppState.searchMode = it })

        when (mode) {
            SearchMode.ANYWHERE -> PlaceField(
""",
)
edit(
    kt("ui/home/HomeScreen.kt"),
    """            SearchMode.NEARBY -> Unit
        }
""",
    """            // Searching a corridor is not a way of browsing, it is something you do once you
            // have picked somewhere to go — so it lives on the route screen now. See MapRouteScreen.
            SearchMode.NEARBY, SearchMode.ON_THE_WAY -> Unit
        }
""",
)
edit(
    kt("ui/home/HomeScreen.kt"),
    """                            emptyMessage ?: when {
                                mode == SearchMode.ON_THE_WAY && destination == null ->
                                    "Add where you're heading and I'll find stops along the way."
                                mode == SearchMode.ANYWHERE && AppState.searchArea == null ->
""",
    """                            emptyMessage ?: when {
                                mode == SearchMode.ANYWHERE && AppState.searchArea == null ->
""",
)
edit(
    kt("ui/home/HomeScreen.kt"),
    """@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SearchModeRow(mode: SearchMode, tier: space.gexemy.tasteroute.data.Tier, onMode: (SearchMode) -> Unit) {
    SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
        // icon = {} on all three. The default icon slot draws a checkmark on whichever segment is
        // selected, so selecting one widens it and shoves the other two sideways — the row visibly
        // reflows every time you touch it. And the locked state is an icon, not a longer label:
        // appending " · Plus" is exactly what made this segment wrap to two lines and grow taller
        // than the row it lives in.
        SegmentedButton(
            selected = mode == SearchMode.NEARBY,
            onClick = { onMode(SearchMode.NEARBY) },
            shape = SegmentedButtonDefaults.itemShape(0, 3),
            icon = {},
        ) { SegmentLabel("Near me") }
        SegmentedButton(
            selected = mode == SearchMode.ON_THE_WAY,
            onClick = { onMode(SearchMode.ON_THE_WAY) },
            shape = SegmentedButtonDefaults.itemShape(1, 3),
            icon = {},
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (!Entitlements.canSearchCorridor(tier)) {
                    Icon(Icons.Filled.Lock, null, Modifier.size(12.dp))
                    Spacer(Modifier.width(4.dp))
                }
                SegmentLabel("On my way")
            }
        }
        SegmentedButton(
            selected = mode == SearchMode.ANYWHERE,
            onClick = { onMode(SearchMode.ANYWHERE) },
            shape = SegmentedButtonDefaults.itemShape(2, 3),
            icon = {},
        ) { SegmentLabel("Anywhere") }
    }
}
""",
    """/**
 * Two segments, not three. "On my way" was a search mode here, which put a corridor search in
 * front of someone who had not yet said where they were going — and, on the free tier, a locked
 * control that could do nothing but sell. It now lives where the question actually comes up: the
 * route screen, once a destination exists, and only for the tiers that have it.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SearchModeRow(mode: SearchMode, onMode: (SearchMode) -> Unit) {
    SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
        // icon = {} on both. The default icon slot draws a checkmark on whichever segment is
        // selected, so selecting one widens it and shoves the other sideways — the row visibly
        // reflows every time you touch it.
        SegmentedButton(
            selected = mode == SearchMode.NEARBY,
            onClick = { onMode(SearchMode.NEARBY) },
            shape = SegmentedButtonDefaults.itemShape(0, 2),
            icon = {},
        ) { SegmentLabel("Near me") }
        SegmentedButton(
            selected = mode == SearchMode.ANYWHERE,
            onClick = { onMode(SearchMode.ANYWHERE) },
            shape = SegmentedButtonDefaults.itemShape(1, 2),
            icon = {},
        ) { SegmentLabel("Anywhere") }
    }
}
""",
)

# ---------------------------------------------------------------- MapRouteScreen.kt
edit(
    kt("ui/map/MapRouteScreen.kt"),
    """fun MapRouteScreen(
    onBack: () -> Unit,
    onNavigate: () -> Unit,
    onOpenPlace: () -> Unit = {},
    onUpgrade: () -> Unit = {},
) {
    val context = LocalContext.current
    val requestLocation = LocalRequestLocation.current
    val tier = AppState.tier
""",
    """fun MapRouteScreen(
    onBack: () -> Unit,
    onNavigate: () -> Unit,
    onOpenPlace: () -> Unit = {},
) {
    val context = LocalContext.current
    val requestLocation = LocalRequestLocation.current
    val tier = AppState.tier
    // The whole on-the-way feature, not a trimmed version of it. A free tier that gets two stops
    // and a card selling the rest is an advert wearing a feature's clothes; either the corridor is
    // yours or the screen does not mention it.
    val corridorAllowed = Entitlements.canSearchCorridor(tier)
""",
)
edit(
    kt("ui/map/MapRouteScreen.kt"),
    """    LaunchedEffect(target.id, origin, tier) {
        stopsLoading = true
        val found = runCatching {
""",
    """    LaunchedEffect(target.id, origin, tier) {
        if (!corridorAllowed) {
            stops = emptyList()
            stopsLoading = false
            return@LaunchedEffect
        }
        stopsLoading = true
        val found = runCatching {
""",
)
edit(
    kt("ui/map/MapRouteScreen.kt"),
    """    val visibleStops = remember(stops, tier) {
        if (Entitlements.canSearchCorridor(tier)) stops.take(8) else stops.take(2)
    }
""",
    """    val visibleStops = remember(stops, corridorAllowed) { if (corridorAllowed) stops.take(8) else emptyList() }
""",
)
edit(
    kt("ui/map/MapRouteScreen.kt"),
    """        LazyColumn(
            Modifier.weight(1f).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item("head") {
                Row(
                    Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        "Worth a stop on the way",
                        Modifier.weight(1f),
                        style = MaterialTheme.typography.titleSmall,
                        maxLines = 1,
                    )
""",
    """        if (!corridorAllowed) {
            Spacer(Modifier.weight(1f))
            return@Column
        }

        LazyColumn(
            Modifier.weight(1f).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item("head") {
                Row(
                    Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        "On my way",
                        Modifier.weight(1f),
                        style = MaterialTheme.typography.titleSmall,
                        maxLines = 1,
                    )
""",
)
edit(
    kt("ui/map/MapRouteScreen.kt"),
    """            if (!Entitlements.canSearchCorridor(tier) && stops.size > visibleStops.size) {
                item("upsell") {
                    Surface(
                        Modifier.fillMaxWidth().clickable(onClick = onUpgrade).padding(bottom = 12.dp),
                        shape = MaterialTheme.shapes.medium,
                        color = MaterialTheme.colorScheme.primaryContainer,
                    ) {
                        Text(
                            "${stops.size - visibleStops.size} more stops along this route with Plus",
                            Modifier.padding(14.dp),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                        )
                    }
                }
            }
        }
""",
    """        }
""",
)

# ---------------------------------------------------------------- PlaceDetailScreen.kt
edit(
    kt("ui/detail/PlaceDetailScreen.kt"),
    "import androidx.compose.material.icons.filled.PlayArrow\n",
    "import androidx.compose.material.icons.filled.PlayArrow\nimport androidx.compose.material.icons.filled.RestaurantMenu\n",
)
edit(
    kt("ui/detail/PlaceDetailScreen.kt"),
    """fun PlaceDetailScreen(
    onBack: () -> Unit,
    onRoute: () -> Unit,
""",
    """fun PlaceDetailScreen(
    onBack: () -> Unit,
    onRoute: () -> Unit,
    onMenu: () -> Unit,
""",
)
edit(
    kt("ui/detail/PlaceDetailScreen.kt"),
    """                notice?.let {
                    Text(it, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.error)
                }
""",
    """                MenuCard(facts.fillFrom(osmFacts), place.webUrl, onMenu)

                notice?.let {
                    Text(it, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.error)
                }
""",
)
edit(
    kt("ui/detail/PlaceDetailScreen.kt"),
    """/**
 * The replacement for the invented wait estimate. When nobody has reported, it says so and asks —
""",
    """/**
 * The way into the menu, and deliberately the loudest control above the fold.
 *
 * The dish line on a card falls back to [space.gexemy.tasteroute.data.DishPicks] when nothing was
 * harvested, and however carefully that is labelled "Your pick", people read a dish printed on a
 * restaurant as a dish that restaurant serves. The fix is the real menu, one tap away. The
 * subtitle says which of the two you are about to get BEFORE the tap, because for a lot of venues
 * the honest answer is still "they only publish a PDF" — and a button that opens a shrug is worse
 * than one that admits what it has.
 */
@Composable
private fun MenuCard(facts: PlaceFacts, fallbackUrl: String?, onOpen: () -> Unit) {
    val dishes = facts.menuSections.sumOf { it.items.size }.takeIf { it > 0 } ?: facts.menuItems.size
    val link = facts.menu ?: facts.menuSource ?: facts.website ?: fallbackUrl
    if (dishes == 0 && link == null) return
    Surface(
        Modifier.fillMaxWidth().clickable(onClick = onOpen),
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.secondaryContainer,
        contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.RestaurantMenu, null, Modifier.size(22.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Menu", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(
                    if (dishes > 0) {
                        "$dishes dish${if (dishes == 1) "" else "es"} the venue publishes itself"
                    } else {
                        "No readable menu published — open theirs instead"
                    },
                    style = MaterialTheme.typography.labelMedium,
                )
            }
        }
    }
}

/**
 * The replacement for the invented wait estimate. When nobody has reported, it says so and asks —
""",
)

# ---------------------------------------------------------------- Schema.kt
edit(
    kt("data/Schema.kt"),
    """@Serializable
data class PlaceFacts(
    val phone: String? = null,
""",
    """/**
 * One dish exactly as the venue published it: its name, and whatever else it chose to say.
 *
 * Everything here is optional because everything here is optional in the markup. A price the
 * restaurant did not publish is absent, never a zero — the same distinction [FactGroup] draws
 * between "no" and "nobody said".
 */
@Serializable
data class MenuDish(
    val name: String,
    val description: String? = null,
    /** Formatted server-side, currency included, because a bare 12 means nothing. */
    val price: String? = null,
    /** schema.org `suitableForDiet`: the venue's own claim about its own dish. */
    val diet: List<String> = emptyList(),
)

/** A course, as the venue grouped it. [name] is blank when the menu has no sections. */
@Serializable
data class MenuSection(
    val name: String = "",
    val items: List<MenuDish> = emptyList(),
)

@Serializable
data class PlaceFacts(
    val phone: String? = null,
""",
)
edit(
    kt("data/Schema.kt"),
    """    @SerialName("menu_items") val menuItems: List<String> = emptyList(),
""",
    """    @SerialName("menu_items") val menuItems: List<String> = emptyList(),
    /**
     * The same harvest kept whole — the sections the venue grouped its dishes into, with prices and
     * descriptions (server >= 1.6.0, capability `menu-sections`). This is what MenuScreen renders;
     * [menuItems] stays the short highlight list a card has room for, and an older server that
     * sends only that still fills the menu screen with something real.
     */
    @SerialName("menu_sections") val menuSections: List<MenuSection> = emptyList(),
    /** The page the dishes were read from — often the venue's menu page, not its home page. */
    @SerialName("menu_source") val menuSource: String? = null,
""",
)
edit(
    kt("data/Schema.kt"),
    """            menuItems.isNotEmpty() ||
""",
    """            menuItems.isNotEmpty() || menuSections.isNotEmpty() ||
""",
)
edit(
    kt("data/Schema.kt"),
    """        menuItems = menuItems.ifEmpty { other.menuItems },
""",
    """        menuItems = menuItems.ifEmpty { other.menuItems },
        menuSections = menuSections.ifEmpty { other.menuSections },
        menuSource = menuSource ?: other.menuSource,
""",
)

# ---------------------------------------------------------------- API: website.js
edit(
    os.path.join(API, "src/sources/website.js"),
    "import { menuItemsFrom, sameSiteMenuUrl } from './menu.js';\n",
    "import { menuFrom, sameSiteMenuUrl } from './menu.js';\n",
)
edit(
    os.path.join(API, "src/sources/website.js"),
    """    const menu = node.hasMenu ?? node.menu;
    const menuUrl = typeof menu === 'string' ? menu : menu?.url ?? null;
    const address = node.address;
    const selfRating = node.aggregateRating?.ratingValue;

    // Dishes the venue itself published. See menu.js for why nothing else counts as one.
    let dishes = menuItemsFrom(nodes);
""",
    """    const menuLink = node.hasMenu ?? node.menu;
    const rawMenuUrl = typeof menuLink === 'string' ? menuLink : menuLink?.url ?? null;
    // `hasMenu` is free text as often as it is a link — "Our menu changes daily" is a real value
    // people put there, and the app renders this field as a tappable chip. Absolute or nothing.
    const menuUrl = (() => {
      if (typeof rawMenuUrl !== 'string' || !/^(https?:)?\\/\\/|^\\.{0,2}\\//i.test(rawMenuUrl)) return null;
      try { return new URL(rawMenuUrl, url).toString(); } catch { return null; }
    })();
    const address = node.address;
    const selfRating = node.aggregateRating?.ratingValue;

    // Dishes the venue itself published. See menu.js for why nothing else counts as one.
    let dishes = menuFrom(nodes);
    let dishSource = dishes.items.length ? url.toString() : null;
""",
)
edit(
    os.path.join(API, "src/sources/website.js"),
    """    if (!dishes.length && detail && config.websiteMenuFollow) {
      const target = sameSiteMenuUrl(menuUrl, url);
      if (target && (await allowedByRobots(target))) {
        const menuHtml = await fetchText(target, {
          timeoutMs: config.websiteMenuTimeoutMs,
          maxBytes: config.websiteMenuMaxBytes,
        });
        if (menuHtml) dishes = menuItemsFrom(jsonLdNodes(menuHtml));
      }
    }
""",
    """    if (!dishes.items.length && detail && config.websiteMenuFollow) {
      const target = sameSiteMenuUrl(rawMenuUrl, url);
      if (target && (await allowedByRobots(target))) {
        const menuHtml = await fetchText(target, {
          timeoutMs: config.websiteMenuTimeoutMs,
          maxBytes: config.websiteMenuMaxBytes,
        });
        if (menuHtml) {
          const followed = menuFrom(jsonLdNodes(menuHtml));
          // Only if it actually found something: a menu page that parsed to nothing must not
          // overwrite dishes the home page had, and must not claim to be their source.
          if (followed.items.length) {
            dishes = followed;
            dishSource = target.toString();
          }
        }
      }
    }
""",
)
edit(
    os.path.join(API, "src/sources/website.js"),
    """        menu_items: dishes.length ? dishes : null,
""",
    """        menu_items: dishes.items.length ? dishes.items : null,
        // The same harvest kept whole — sections, prices, descriptions, published diet claims —
        // for the app's menu screen. Null, not [], so mergeFacts skips it like every other absent
        // field rather than locking an empty answer in ahead of a source that has one.
        menu_sections: dishes.sections.length ? dishes.sections : null,
        menu_source: dishSource,
""",
)

# ---------------------------------------------------------------- API: capabilities + version
edit(
    os.path.join(API, "src/index.js"),
    """  'menus',
""",
    """  'menus',
  // facts.menu_sections: the same harvest kept whole — sections, prices, descriptions and the
  // venue's own suitableForDiet claims. The app's menu screen renders this; menu_items is
  // unchanged, so a client older than this capability sees exactly what it saw before.
  'menu-sections',
""",
)
edit(
    os.path.join(API, "package.json"),
    '"version": "1.5.1"',
    '"version": "1.6.0"',
)

# ---------------------------------------------------------------- whole files
COPIES = [
    ("MenuScreen.kt", kt("ui/detail/MenuScreen.kt")),
    ("menu.js", os.path.join(API, "src/sources/menu.js")),
]

# ================================================================= phase 1: validate
staged = {}
problems = []

for path, old, new in edits:
    if path not in staged:
        if not os.path.isfile(path):
            problems.append(f"missing file: {path}")
            staged[path] = None
            continue
        with open(path, encoding="utf-8") as fh:
            staged[path] = fh.read()
    body = staged[path]
    if body is None:
        continue
    count = body.count(old)
    if count != 1:
        problems.append(f"{os.path.relpath(path)}: {count} matches (want 1) for {old.strip()[:72]!r}")
        continue
    staged[path] = body.replace(old, new, 1)

for src, dest in COPIES:
    if not os.path.isfile(os.path.join(HERE, src)):
        problems.append(f"missing payload: {src}")

if problems:
    print("NOTHING WRITTEN. Validation failed:")
    for p in problems:
        print(f"  x  {p}")
    sys.exit(1)

# ================================================================= phase 2: write
for path, body in staged.items():
    with open(path, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(body)
    print(f"   patched {os.path.relpath(path)}")

for src, dest in COPIES:
    with open(os.path.join(HERE, src), encoding="utf-8") as fh:
        body = fh.read()
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    with open(dest, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(body)
    print(f"   wrote   {os.path.relpath(dest)}")

print(f"\nok — {len(edits)} edits across {len(staged)} files, {len(COPIES)} whole files")
