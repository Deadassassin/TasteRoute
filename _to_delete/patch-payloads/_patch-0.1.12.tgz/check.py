#!/usr/bin/env python3
"""Kotlin bracket balance via a mode stack, plus the assertions for this change.

Run it against the UNPATCHED tree first. A checker that reports five broken files before you have
touched anything is a broken checker, and that has happened twice on this project.

Modes: code / string / raw string / template-inside-string. The three traps, all real:
  (a) a `}` ends a string template only when it is THAT template's own brace, so the bracket depth
      at `${` is recorded — checking the mode alone closes the template on the first `}` of
      `${list.joinToString { }}` and unravels every quote after it.
  (b) a raw string may legitimately END in a quote, so a run of 4+ quotes is content-then-terminator.
  (c) `"${"$".repeat(n)}"` is a string containing code containing a string.

Usage: check.py <android-root> [--post]
"""
import os
import re
import sys

CLOSERS = {')': '(', ']': '[', '}': '{'}


def scan(src):
    """Every unbalanced bracket in one Kotlin file, as (line, message)."""
    problems = []
    stack = []           # (char, line)
    modes = []           # (mode_to_restore, bracket_depth_or_None)
    mode = 'code'
    i, n, line = 0, len(src), 1

    while i < n:
        c = src[i]

        if mode == 'code':
            if c == '\n':
                line += 1
                i += 1
            elif src.startswith('//', i):
                j = src.find('\n', i)
                i = n if j < 0 else j
            elif src.startswith('/*', i):
                depth, i = 1, i + 2
                while i < n and depth:
                    if src.startswith('/*', i):
                        depth += 1
                        i += 2
                    elif src.startswith('*/', i):
                        depth -= 1
                        i += 2
                    else:
                        if src[i] == '\n':
                            line += 1
                        i += 1
            elif src.startswith('"""', i):
                modes.append(('code', None))
                mode = 'raw'
                i += 3
            elif c == '"':
                modes.append(('code', None))
                mode = 'str'
                i += 1
            elif c == "'":
                i += 1
                while i < n and src[i] != "'":
                    if src[i] == '\\':
                        i += 1
                    i += 1
                i += 1
            elif c in '([{':
                stack.append((c, line))
                i += 1
            elif c in CLOSERS:
                if not stack:
                    problems.append((line, f'stray {c}'))
                elif stack[-1][0] != CLOSERS[c]:
                    problems.append((line, f'{c} closes {stack[-1][0]} from line {stack[-1][1]}'))
                    stack.pop()
                else:
                    stack.pop()
                # Trap (a): this closes a template only if it is that template's own brace.
                if c == '}' and modes and modes[-1][1] is not None and len(stack) == modes[-1][1]:
                    mode = modes.pop()[0]
                i += 1
            else:
                i += 1
            continue

        if mode == 'str':
            if c == '\\':
                if i + 1 < n and src[i + 1] == '\n':
                    line += 1
                i += 2
            elif src.startswith('${', i):
                modes.append(('str', len(stack)))
                stack.append(('{', line))
                mode = 'code'
                i += 2
            elif c == '"':
                mode = modes.pop()[0]
                i += 1
            elif c == '\n':
                # An unescaped newline inside a "..." is not legal Kotlin; report and recover.
                problems.append((line, 'newline inside a single-quoted string'))
                mode = modes.pop()[0]
                line += 1
                i += 1
            else:
                i += 1
            continue

        # raw string
        if src.startswith('${', i):
            modes.append(('raw', len(stack)))
            stack.append(('{', line))
            mode = 'code'
            i += 2
        elif c == '"':
            j = i
            while j < n and src[j] == '"':
                j += 1
            if j - i < 3:
                i = j                      # one or two quotes are content
            else:
                mode = modes.pop()[0]      # trap (b): the last three terminate it
                i = j
        else:
            if c == '\n':
                line += 1
            i += 1

    for char, at in stack:
        problems.append((at, f'{char} never closed'))
    if mode != 'code':
        problems.append((line, f'file ends inside a {mode}'))
    return problems


ASSERTS = [
    # (file, must_contain, must_not_contain)
    ('app/build.gradle.kts', ['versionName = "0.1.12"', 'versionCode = 12'], ['versionName = "1.0.0"']),
    ('MainActivity.kt', ['MenuScreen(onBack', 'private const val MENU', 'onMenu = { nav.push(MENU) }',
                         'Modifier.offset(y = (-3).dp)', 'import androidx.compose.foundation.layout.offset'],
     ['onUpgrade = { nav.push(SETTINGS) },\n                        )']),
    ('ui/home/HomeScreen.kt', ['itemShape(0, 2)', 'itemShape(1, 2)'],
     ['Entitlements', 'Icons.Filled.Lock', 'itemShape(2, 3)', '"On my way"']),
    ('ui/map/MapRouteScreen.kt', ['val corridorAllowed', '"On my way"', 'return@Column'],
     ['onUpgrade', 'more stops along this route with Plus', '"Worth a stop on the way"']),
    ('ui/detail/PlaceDetailScreen.kt', ['onMenu: () -> Unit', 'private fun MenuCard(',
                                        'MenuCard(facts.fillFrom(osmFacts), place.webUrl, onMenu)',
                                        'Icons.Filled.RestaurantMenu'], []),
    ('ui/detail/MenuScreen.kt', ['fun MenuScreen(onBack: () -> Unit)', 'facts.menuSections'], []),
    ('data/Schema.kt', ['data class MenuDish', 'data class MenuSection',
                        '@SerialName("menu_sections")', '@SerialName("menu_source")',
                        'menuSections = menuSections.ifEmpty { other.menuSections }'], []),
]


def main():
    root = sys.argv[1]
    post = '--post' in sys.argv
    kt_root = os.path.join(root, 'app/src/main/java/space/gexemy/tasteroute')

    bad = 0
    files = 0
    for base, dirs, names in os.walk(kt_root):
        dirs[:] = [d for d in dirs if d != '_to_delete']
        for name in sorted(names):
            if not name.endswith('.kt'):
                continue
            path = os.path.join(base, name)
            with open(path, encoding='utf-8') as fh:
                src = fh.read()
            files += 1
            for at, msg in scan(src):
                bad += 1
                print(f'  x  {os.path.relpath(path, root)}:{at}  {msg}')
    print(f'brackets: {files} files, {bad} problem(s)')

    stale = 0
    for base, dirs, names in os.walk(kt_root):
        dirs[:] = [d for d in dirs if d != '_to_delete']
        for name in names:
            if not name.endswith('.kt'):
                continue
            with open(os.path.join(base, name), encoding='utf-8') as fh:
                if re.search(r'com\.example\.tasteroute', fh.read()):
                    stale += 1
                    print(f'  x  {name}: still references com.example.tasteroute')
    print(f'package: {stale} stale reference(s)')

    if not post:
        return 0 if bad == 0 and stale == 0 else 1

    missed = 0
    for rel, need, forbid in ASSERTS:
        path = os.path.join(root, rel) if rel.startswith('app/') else os.path.join(kt_root, rel)
        if not os.path.isfile(path):
            print(f'  x  {rel}: missing')
            missed += 1
            continue
        with open(path, encoding='utf-8') as fh:
            body = fh.read()
        for text in need:
            if text not in body:
                print(f'  x  {rel}: expected {text!r}')
                missed += 1
        for text in forbid:
            if text in body:
                print(f'  x  {rel}: still contains {text!r}')
                missed += 1
    print(f'assertions: {missed} failure(s)')
    return 0 if bad == 0 and stale == 0 and missed == 0 else 1


if __name__ == '__main__':
    sys.exit(main())
