#!/usr/bin/env python3
"""Assertions for the sign-in-on-relaunch fix. Run after check.py's bracket scan."""
import os
import re
import sys

ROOT = sys.argv[1]
KT = os.path.join(ROOT, 'app/src/main/java/space/gexemy/tasteroute')


def read(rel):
    path = os.path.join(ROOT, rel) if rel.startswith('app/') else os.path.join(KT, rel)
    with open(path, encoding='utf-8') as fh:
        return fh.read()


fails = []


def want(rel, text, why):
    if text not in read(rel):
        fails.append(f'{rel}: {why} — expected {text!r}')


def reject(rel, pattern, why):
    if re.search(pattern, read(rel)):
        fails.append(f'{rel}: {why} — still matches /{pattern}/')


# The bug itself: an authed call with no access token must try a refresh before giving up.
want('data/GexemyClient.kt',
     'var token = if (authed) Session.accessToken ?: Session.refreshAccess() else null',
     'cold-start authed calls still throw 401 without refreshing')

# signedIn must invalidate composition when restore lands.
want('data/Session.kt', 'private var refreshToken by mutableStateOf<String?>(null)',
     'signedIn is still a plain field')
reject('data/Session.kt', r'@Volatile\s*\n\s*private var refreshToken',
       '@Volatile cannot decorate a delegated property')

# Rotations collapse instead of stampeding, and the write is durable.
want('data/Session.kt', 'if (refreshToken != spent) return@withLock accessToken',
     'concurrent refreshes still each rotate')
want('data/Session.kt', 'Prefs.putNow(Prefs.REFRESH, result.refresh)',
     'a rotated token is still written with apply()')
reject('data/Session.kt', r'Prefs\.put\(Prefs\.REFRESH, result\.refresh\)\s*\n\s*result\.access',
       'the rotation path still uses the async write')
want('data/Prefs.kt', 'fun putNow(key: String, value: String)', 'putNow missing')
want('data/Prefs.kt', '.commit()', 'putNow is not actually synchronous')

# The token is known before the first composition.
want('data/AppState.kt', 'Session.restoreToken()', 'restoreCritical does not read the token')
want('data/Session.kt', 'fun restoreToken()', 'restoreToken missing')
want('data/Session.kt', 'if (refreshToken == null) restoreToken()',
     'restore() re-reads Prefs and can clobber a newer token')

# Sign-out still has to work: the one legitimate 401 path.
want('data/Session.kt', 'if (e.code == 401) {', 'the dead-token branch went missing')
want('data/Session.kt', 'import kotlinx.coroutines.withContext', 'withContext not imported')

want('app/build.gradle.kts', 'versionName = "0.1.13"', 'version not bumped')

for f in fails:
    print(f'  x  {f}')
print(f'sign-in assertions: {len(fails)} failure(s)')
sys.exit(1 if fails else 0)
