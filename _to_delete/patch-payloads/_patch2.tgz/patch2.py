#!/usr/bin/env python3
"""TasteRoute 0.1.13 — "it says to sign in again even though I'm already signed in".

Two-phase: every edit is validated into memory first and nothing is written until all pass.
"""
import os
import sys

ANDROID = sys.argv[1] if len(sys.argv) > 1 else os.path.expanduser("~/mnt/TasteRoute")
KT = os.path.join(ANDROID, "app/src/main/java/space/gexemy/tasteroute")

edits = []


def edit(rel, old, new):
    edits.append((os.path.join(KT, rel) if not rel.startswith("app/") else os.path.join(ANDROID, rel), old, new))


# ---------------------------------------------------------------- THE BUG
# GexemyClient.raw threw its "no token" 401 BEFORE the try block, so the refresh inside the catch
# was unreachable. The access token is memory-only, therefore always null after a relaunch.
edit(
    "data/GexemyClient.kt",
    """        var token = if (authed) Session.accessToken else null
        if (authed && !optionalAuth && token == null) throw HttpException(401, "Sign in to use this")
""",
    """        // THE ACCESS TOKEN IS NEVER PERSISTED, so it is always null on a cold start. Minting one
        // here instead of waiting for a 401 is not an optimisation, it is the fix: the guard on the
        // next line threw BEFORE the try below, which made the refresh in the catch unreachable. So
        // every authed call after a relaunch failed with a 401 this client manufactured itself
        // without a packet leaving the phone — and Social renders a 401 as "Sign in again to keep
        // using friends." Signed out this costs nothing: refreshAccess returns null on the spot
        // when there is no refresh token.
        var token = if (authed) Session.accessToken ?: Session.refreshAccess() else null
        if (authed && !optionalAuth && token == null) throw HttpException(401, "Sign in to use this")
""",
)

# ---------------------------------------------------------------- signedIn must be observable
edit(
    "data/Session.kt",
    """    @Volatile
    private var refreshToken: String? = null

    val signedIn: Boolean get() = refreshToken != null
""",
    """    /**
     * Snapshot state, not a plain field, and that is load-bearing.
     *
     * [signedIn] is read from composition — the sign-in prompts on the place screen, the Profile
     * tab, Table Sync — and it is written from Dispatchers.IO by [restore]. A plain field written
     * off the main thread invalidates nothing, so every one of those screens kept rendering its
     * signed-out branch after the token had already loaded. Snapshot state writes are safe from
     * any thread; that is what makes the background restore legal in the first place.
     */
    private var refreshToken by mutableStateOf<String?>(null)

    val signedIn: Boolean get() = refreshToken != null
""",
)

# ---------------------------------------------------------------- restore the token early
edit(
    "data/Session.kt",
    """    fun restore() {
        refreshToken = Prefs.getString(Prefs.REFRESH).takeIf { it.isNotBlank() }
        Prefs.getString(Prefs.ACCOUNT).takeIf { it.isNotBlank() }?.let { json ->
""",
    """    /**
     * The token and nothing else. One string, no JSON decode, so it is cheap enough for
     * [AppState.restoreCritical] — and it has to run there, because a first composition that reads
     * `signedIn == false` puts "Sign in to review" on screen before the real answer arrives.
     */
    fun restoreToken() {
        refreshToken = Prefs.getString(Prefs.REFRESH).takeIf { it.isNotBlank() }
    }

    fun restore() {
        // Already read in restoreCritical; re-reading would only risk clobbering a token that
        // rotated in between with the older one still on disk.
        if (refreshToken == null) restoreToken()
        Prefs.getString(Prefs.ACCOUNT).takeIf { it.isNotBlank() }?.let { json ->
""",
)

# ---------------------------------------------------------------- one rotation, not six
edit(
    "data/Session.kt",
    """    /** Returns a fresh access token, or null if the device has to sign in again. */
    suspend fun refreshAccess(): String? = refreshLock.withLock {
        val token = refreshToken ?: return null
        try {
            val result = GexemyClient.refresh(token)
            accessToken = result.access
            refreshToken = result.refresh
            Prefs.put(Prefs.REFRESH, result.refresh)
            result.access
        } catch (e: HttpException) {
            // 401 here means the refresh token is dead — revoked, replayed or expired. Anything
            // else (offline, 5xx) is transient and must not throw the user out of their account.
            if (e.code == 401) signOut() else syncError = friendly(e)
            null
        } catch (e: Exception) {
            syncError = friendly(e)
            null
        }
    }
""",
    """    /**
     * A fresh access token, or null if the device really does have to sign in again.
     *
     * Concurrent callers COLLAPSE. Opening the app fires several authed calls at once and each of
     * them needs the first access token of the session; whoever takes the lock rotates, and
     * everybody queued behind them takes the token that rotation produced instead of rotating
     * again. Six rotations in a second are six chances for a write to be lost, and a lost rotation
     * write is indistinguishable from a replayed token the next time the app starts.
     */
    suspend fun refreshAccess(): String? = withContext(Dispatchers.IO) {
        val spent = refreshToken ?: return@withContext null
        refreshLock.withLock {
            // Somebody else rotated while we were queued. Theirs is the live token; take it.
            if (refreshToken != spent) return@withLock accessToken
            try {
                val result = GexemyClient.refresh(spent)
                accessToken = result.access
                refreshToken = result.refresh
                // commit(), not apply(). If the process dies between the server rotating and this
                // write reaching disk, the next launch presents a token the server has already
                // marked used — which is a replay, and a replay revokes the whole family. That is
                // a permanent, silent sign-out caused by a write nobody waited for. This is the
                // one value in the app where losing a write costs the account.
                Prefs.putNow(Prefs.REFRESH, result.refresh)
                result.access
            } catch (e: HttpException) {
                // 401 here means the refresh token is dead — revoked, replayed or expired. Anything
                // else (offline, 5xx) is transient and must not throw the user out of their account.
                if (e.code == 401) {
                    signOut()
                } else {
                    syncError = friendly(e)
                    // Backoff ignores 401s, so this only ever trips on the transient classes — and
                    // it is what makes the reachable(ACCOUNT) guards elsewhere mean anything when
                    // the server is down at launch.
                    Backoff.record(Backoff.ACCOUNT, e)
                }
                null
            } catch (e: Exception) {
                syncError = friendly(e)
                Backoff.record(Backoff.ACCOUNT, e)
                null
            }
        }
    }
""",
)

edit(
    "data/Session.kt",
    "import kotlinx.coroutines.sync.withLock\n",
    "import kotlinx.coroutines.sync.withLock\nimport kotlinx.coroutines.withContext\n",
)

# ---------------------------------------------------------------- a durable write for one key
edit(
    "data/Prefs.kt",
    """    fun put(key: String, value: Boolean) {
""",
    """    /**
     * A blocking write, for the one value where losing the write costs the account: a rotated
     * refresh token. Presenting a token the server has already retired reads as a replay and
     * revokes the whole session family. apply() stays right for everything else here — a theme
     * choice that does not survive a kill is a shrug.
     */
    fun putNow(key: String, value: String) {
        if (ready) store.edit().putString(key, value).commit()
    }

    fun put(key: String, value: Boolean) {
""",
)

# ---------------------------------------------------------------- read it before the first frame
edit(
    "data/AppState.kt",
    """        allergens.addAll(Prefs.getStringSet(Prefs.ALLERGENS))
        favorites.addAll(Prefs.getStringSet(Prefs.FAVORITES))
    }
""",
    """        allergens.addAll(Prefs.getStringSet(Prefs.ALLERGENS))
        favorites.addAll(Prefs.getStringSet(Prefs.FAVORITES))
        // One string, no JSON, and the first composition asks for it: every screen that gates on
        // Session.signedIn would otherwise paint its signed-out branch before restoreRest lands.
        Session.restoreToken()
    }
""",
)

# ---------------------------------------------------------------- version
edit(
    "app/build.gradle.kts",
    """        versionCode = 12
        versionName = "0.1.12"
""",
    """        versionCode = 13
        versionName = "0.1.13"
""",
)

# ================================================================= phase 1: validate
staged = {}
problems = []
for path, old, new in edits:
    if path not in staged:
        if not os.path.isfile(path):
            problems.append(f"missing file: {path}")
            staged[path] = None
            continue
        with open(path, encoding="utf-8") as fh:
            staged[path] = fh.read()
    if staged[path] is None:
        continue
    count = staged[path].count(old)
    if count != 1:
        problems.append(f"{os.path.basename(path)}: {count} matches (want 1) for {old.strip()[:70]!r}")
        continue
    staged[path] = staged[path].replace(old, new, 1)

if problems:
    print("NOTHING WRITTEN. Validation failed:")
    for p in problems:
        print(f"  x  {p}")
    sys.exit(1)

# ================================================================= phase 2: write
for path, body in staged.items():
    with open(path, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(body)
    print(f"   patched {os.path.basename(path)}")
print(f"\nok — {len(edits)} edits across {len(staged)} files")
