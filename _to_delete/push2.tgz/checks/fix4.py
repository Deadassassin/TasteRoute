#!/usr/bin/env python3
"""Profile becomes a profile, settings move behind the overflow, the match score stops reading as
"ehh", and opening hours stop claiming midnight."""
import os
import re
import sys

ROOT = os.path.expanduser("~/mnt/TasteRoute/app/src/main/java/space/gexemy/tasteroute")
fails = []


def patch(rel, old, new, count=1):
    p = os.path.join(ROOT, rel)
    s = open(p, encoding="utf-8").read()
    if s.count(old) != count:
        fails.append(f"{rel}: found {s.count(old)} :: {old.strip().splitlines()[0][:60]}")
        return
    open(p, "w", encoding="utf-8").write(s.replace(old, new))


def cut(rel, start_marker, end_marker, replacement):
    """Replace everything from start_marker up to (not including) end_marker."""
    p = os.path.join(ROOT, rel)
    s = open(p, encoding="utf-8").read()
    a = s.find(start_marker)
    b = s.find(end_marker, a + 1)
    if a < 0 or b < 0:
        fails.append(f"{rel}: markers not found ({a}, {b})")
        return
    open(p, "w", encoding="utf-8").write(s[:a] + replacement + s[b:])


# ============================================================ GexemyClient: social wire + calls
patch("data/GexemyClient.kt", """    @Serializable
    data class Favorite(@SerialName("place_id") val placeId: String, val name: String = "")""",
      """    @Serializable
    data class Favorite(@SerialName("place_id") val placeId: String, val name: String = "")

    /** What one person is allowed to see about another. Deliberately short — see routes/social.js. */
    @Serializable
    data class Person(
        val id: Long = 0,
        val handle: String? = null,
        @SerialName("display_name") val displayName: String = "",
        val bio: String = "",
    ) {
        val label: String get() = displayName.ifBlank { handle?.let { "@$it" } ?: "Someone" }
    }

    @Serializable
    data class FriendLink(
        @SerialName("link_id") val linkId: Long = 0,
        val user: Person = Person(),
        val since: String? = null,
    )

    @Serializable
    data class Friends(
        val friends: List<FriendLink> = emptyList(),
        /** Waiting on YOU. Kept apart from [outgoing] because they need different buttons. */
        val incoming: List<FriendLink> = emptyList(),
        val outgoing: List<FriendLink> = emptyList(),
    )

    @Serializable
    data class OverlapLists(
        val cuisines: List<String> = emptyList(),
        val vibes: List<String> = emptyList(),
        val diets: List<String> = emptyList(),
    )

    /** Null from the server when neither side has set enough to compare — not a zero. */
    @Serializable
    data class TasteOverlap(
        val score: Int = 0,
        val shared: OverlapLists = OverlapLists(),
        @SerialName("only_theirs") val onlyTheirs: OverlapLists = OverlapLists(),
        @SerialName("only_mine") val onlyMine: OverlapLists = OverlapLists(),
    )

    /**
     * One logged visit. [visibility] is the whole privacy contract: 'private' unless its owner
     * chose otherwise when they logged it, and the server has no third value.
     */
    @Serializable
    data class Visit(
        val id: Long = 0,
        @SerialName("place_id") val placeId: String = "",
        val name: String = "",
        val rating: Int? = null,
        val note: String? = null,
        val visibility: String = "private",
        @SerialName("visited_at") val visitedAt: String? = null,
        /** Only set on the friends feed; your own visits do not need your own name on them. */
        val by: Person? = null,
    ) {
        val shared: Boolean get() = visibility == "friends"
    }

    @Serializable
    data class FriendDetail(
        val user: Person = Person(),
        val overlap: TasteOverlap? = null,
        val visits: List<Visit> = emptyList(),
    )

    @Serializable
    private data class VisitFeed(val visits: List<Visit> = emptyList())

    @Serializable
    private data class Journal(val entries: List<Visit> = emptyList())

    @Serializable
    data class ProfileStats(
        val visits: Int = 0,
        val shared: Int = 0,
        val reviews: Int = 0,
        val photos: Int = 0,
        val checkins: Int = 0,
        val friends: Int = 0,
        @SerialName("friend_requests") val friendRequests: Int = 0,
    )

    /** Blank clears the handle, which unlists you: nobody can search for you again afterwards. */
    suspend fun setHandle(handle: String?, bio: String) {
        send("PUT", "/v1/me/handle", buildJsonObject {
            put("handle", handle.orEmpty())
            put("bio", bio)
        }, null, authed = true)
    }

    suspend fun friends(): Friends = send("GET", "/v1/friends", null, Friends.serializer(), authed = true)

    suspend fun addFriend(handle: String) {
        post("/v1/friends", buildJsonObject { put("handle", handle) }, null, authed = true)
    }

    suspend fun respondFriend(linkId: Long, accept: Boolean) {
        post("/v1/friends/${'$'}linkId/respond", buildJsonObject { put("accept", accept) }, null, authed = true)
    }

    suspend fun removeFriend(linkId: Long) {
        send("DELETE", "/v1/friends/${'$'}linkId", null, null, authed = true)
    }

    suspend fun friend(userId: Long): FriendDetail =
        send("GET", "/v1/friends/${'$'}userId", null, FriendDetail.serializer(), authed = true)

    suspend fun friendVisits(): List<Visit> =
        send("GET", "/v1/friends/visits", null, VisitFeed.serializer(), authed = true).visits

    suspend fun myVisits(): List<Visit> =
        send("GET", "/v1/me/journal", null, Journal.serializer(), authed = true).entries

    /**
     * [share] decides visibility for THIS visit only. There is deliberately no call anywhere that
     * changes the visibility of visits already logged: "share this one" and "share everywhere I
     * have ever eaten" are not the same consent, and only the first one was ever given.
     */
    suspend fun logVisit(placeId: String, name: String, share: Boolean, note: String = "", rating: Int? = null): Visit =
        post("/v1/me/journal", buildJsonObject {
            put("place_id", placeId)
            put("name", name)
            put("note", note)
            rating?.let { put("rating", it) }
            put("visibility", if (share) "friends" else "private")
        }, Visit.serializer(), authed = true)""")

patch("data/GexemyClient.kt", """        @SerialName("taste_text") val tasteText: String = "",
        val favorites: List<Favorite> = emptyList(),
    )""",
      """        @SerialName("taste_text") val tasteText: String = "",
        val favorites: List<Favorite> = emptyList(),
        /** Null until the person claims one. Without it nobody can find them, which is the point. */
        val handle: String? = null,
        val bio: String = "",
        val stats: ProfileStats = ProfileStats(),
    )""")

# ============================================================ Session: sign-out clears social
patch("data/Session.kt", """        account = null
        Prefs.remove(Prefs.REFRESH, Prefs.ACCOUNT)""",
      """        account = null
        // Friends, their visits and yours are all account-scoped. Leaving them in memory after a
        // sign-out means the next person to open the app sees the last person's friends.
        Social.clear()
        Prefs.remove(Prefs.REFRESH, Prefs.ACCOUNT)""")

# ============================================================ Match score
patch("data/RecommendationEngine.kt", """        val raw = (0.24 * cuisine + 0.20 * relevance + 0.16 * proximity + 0.14 * quality +
            0.10 * diet + 0.08 * vibe + 0.08 * price + past).coerceIn(0.0, 1.0)""",
      """        /*
         * A FACTOR NOBODY ANSWERED IS NOT A BAD SCORE, IT IS NO SCORE.
         *
         * The old average fed a neutral 0.5 into every unknown — no rating in OSM, no price tier,
         * no query typed, no vibes set — and seven of those pinned almost every card to somewhere
         * near 50%. Reported as "I see a 50% match and I'm like, ehh, do I really want it", which
         * is exactly right: 50% reads as "probably not" for a place that might be perfect and the
         * app simply had nothing to say about four of its columns.
         *
         * So unknowns drop out and the weights renormalise over what is actually known. Proximity
         * is the only one always present, which is why it can carry the average alone.
         */
        val factors = buildList {
            if (profile.preferredCuisines.isNotEmpty()) add(0.26 to cuisine)
            if (tokens.isNotEmpty()) add(0.22 to relevance)
            add(0.18 to proximity)
            if (r.rating > 0.0) add(0.14 to quality)
            if (profile.dietaryRestrictions.isNotEmpty()) add(0.10 to diet)
            if (profile.vibeTags.isNotEmpty()) add(0.08 to vibe)
            if (r.priceTier > 0) add(0.08 to price)
        }
        val weight = factors.sumOf { it.first }
        val base = if (weight <= 0.0) 0.6 else factors.sumOf { it.first * it.second } / weight
        // Then eased, not inflated. The curve is monotonic so it cannot reorder anything — it only
        // stops a genuinely good fit from landing in the band people scroll past.
        val raw = (base + past).coerceIn(0.0, 1.0).pow(0.62)""")

# ============================================================ The pill leads with a word
patch("ui/components/RestaurantCard.kt", """@Composable
fun MatchPill(score: Int) {
    Surface(
        shape = CircleShape,
        color = MaterialTheme.colorScheme.primaryContainer,
        contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
    ) {
        Text(
            "${'$'}score% match",
            Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
        )
    }
}""",
      """/**
 * A number on its own is a judgement nobody asked for: "50% match" reads as a verdict against the
 * restaurant when it mostly means the app had four blank columns. The word leads and the number
 * follows it in a quieter size — the score still orders the list and is still shown, it just stops
 * being the loudest thing on a card about a place somebody might love.
 */
@Composable
fun MatchPill(score: Int) {
    val label = when {
        score >= 85 -> "Great match"
        score >= 70 -> "Strong match"
        score >= 55 -> "Good match"
        else -> "Worth a look"
    }
    val container =
        if (score >= 55) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
    val ink =
        if (score >= 55) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
    Surface(shape = CircleShape, color = container, contentColor = ink) {
        Row(
            Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(label, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Spacer(Modifier.width(5.dp))
            Text(
                "${'$'}score%",
                style = MaterialTheme.typography.labelSmall,
                color = ink.copy(alpha = 0.72f),
                maxLines = 1,
            )
        }
    }
}""")

# ============================================================ Hours: never print a placeholder
patch("ui/detail/PlaceDetailScreen.kt", """            if (facts.hoursText.isNotEmpty()) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Opening hours", style = MaterialTheme.typography.labelLarge)""",
      """            // The server stopped emitting `00:00-00:00` in 1.4.0, but its harvest cache is 14 days
            // deep, so rows written before that are still out there claiming every venue opens and
            // closes at midnight. Filtering here clears them the moment the app updates.
            val hours = facts.hoursText.filterNot { PLACEHOLDER_HOURS.containsMatchIn(it) }
            if (hours.isNotEmpty()) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Opening hours", style = MaterialTheme.typography.labelLarge)""")

patch("ui/detail/PlaceDetailScreen.kt", """                    facts.hoursText.take(7).forEach {""", """                    hours.take(7).forEach {""")

patch("ui/detail/PlaceDetailScreen.kt", """                LivePulseSection(pulse, byHour, tier, onCheckIn, onSignIn)""",
      """                LivePulseSection(pulse, byHour, tier, onCheckIn, onSignIn)
                VisitSection(place, onSignIn)""")

patch("ui/detail/PlaceDetailScreen.kt", """@Composable
private fun Section(title: String, content: @Composable () -> Unit) {""",
      """/**
 * `opens` and `closes` both at midnight is a CMS template nobody filled in, never a venue that is
 * open from midnight to midnight. Printing it produced a week of `Monday 00:00-00:00` on almost
 * every place with structured hours.
 */
private val PLACEHOLDER_HOURS = Regex("00:00\\\\s*[-\\\\u2013]\\\\s*00:00")

/**
 * Logging a visit is an action somebody takes, never something the app does for them.
 *
 * There is no background location history here and there never will be — this button is the only
 * way a place ends up in a visit log, and the second button is the only way one is ever visible to
 * anybody else. Two explicit buttons rather than a switch with a default, because the difference
 * between them is the entire privacy question and it should be read, not toggled past.
 */
@Composable
private fun VisitSection(place: RestaurantResult, onSignIn: () -> Unit) {
    val scope = rememberCoroutineScope()
    var note by remember(place.id) { mutableStateOf<String?>(null) }
    Section("Been here?") {
        Column {
            Text(
                "TasteRoute never logs where you go on its own. A visit exists because you added it, " +
                    "and it stays private unless you choose the second button.",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    if (!Session.signedIn) onSignIn()
                    else scope.launch { note = Social.logVisit(place, share = false) ?: "Saved, just for you." }
                }) { Text("I ate here", maxLines = 1) }
                OutlinedButton(onClick = {
                    if (!Session.signedIn) onSignIn()
                    else scope.launch { note = Social.logVisit(place, share = true) ?: "Saved and shared with friends." }
                }) { Text("Share with friends", maxLines = 1) }
            }
            note?.let {
                Spacer(Modifier.height(6.dp))
                Text(it, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {""")

patch("ui/detail/PlaceDetailScreen.kt", """import space.gexemy.tasteroute.data.Session""",
      """import space.gexemy.tasteroute.data.Session
import space.gexemy.tasteroute.data.Social""")

# ============================================================ Settings: pushed, and much less of it
patch("ui/settings/SettingsScreen.kt", """fun SettingsScreen(onRetune: () -> Unit, onAccount: () -> Unit, onAbout: () -> Unit = {}) {""",
      """fun SettingsScreen(
    onRetune: () -> Unit,
    onAccount: () -> Unit,
    onAbout: () -> Unit = {},
    onBack: () -> Unit = {},
) {""")

patch("ui/settings/SettingsScreen.kt", """        Text("Profile", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(top = 16.dp))""",
      """        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            BackChip(onBack, Modifier.padding(start = 0.dp))
            Text("Settings", Modifier.weight(1f), style = MaterialTheme.typography.headlineSmall, maxLines = 1)
        }""")

patch("ui/settings/SettingsScreen.kt", """import space.gexemy.tasteroute.ui.components.LocalRequestLocation""",
      """import space.gexemy.tasteroute.ui.components.BackChip
import space.gexemy.tasteroute.ui.components.LocalRequestLocation""")

cut("ui/settings/SettingsScreen.kt",
    "@Composable\nprivate fun ServiceSettings() {",
    "/**\n * Voice settings need the engine attached",
    '''/**
 * One button and one line of answer.
 *
 * This used to be a diagnostics console — every capability the build knows about, every model
 * candidate with its milliseconds, the last failure string. All of it was real and all of it was
 * for whoever was building the app, not for whoever was using it, and it sat on the screen that
 * should have been about the person. What survives is the one question a user can actually act on:
 * is the service answering. [NimClient.lastProbe] and the full capability diff are still printed to
 * Logcat under `TasteRouteRanker`, which is where that detail belongs.
 */
@Composable
private fun ServiceSettings() {
    val scope = rememberCoroutineScope()
    var status by remember { mutableStateOf<String?>(null) }
    var healthy by remember { mutableStateOf(false) }
    var checking by remember { mutableStateOf(false) }

    SectionCard("Service") {
        Text(
            GexemyClient.baseUrl.ifBlank { "GEXEMY_BASE_URL is not set in local.properties" },
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        OutlinedButton(
            enabled = !checking && GexemyClient.isConfigured,
            onClick = {
                checking = true
                scope.launch {
                    runCatching { GexemyClient.health() }.fold(
                        onSuccess = { health ->
                            healthy = health.ok
                            val missing = missingCapabilities(health)
                            status = when {
                                !health.ok -> "Answered, but reported a problem."
                                missing != null -> "Connected — running an older build (${missing})."
                                else -> "Connected. Everything this app needs is switched on."
                            }
                        },
                        onFailure = { error ->
                            healthy = false
                            status = when ((error as? HttpException)?.code) {
                                404, 501 -> "Reached a server, but it is not this API — check GEXEMY_BASE_URL."
                                in 500..599 -> "The server is having a problem. Nothing to do on this end."
                                else -> error.message?.take(120) ?: "Couldn't reach it."
                            }
                        },
                    )
                    checking = false
                }
            },
        ) {
            Text(if (checking) "Checking…" else "Test connection", maxLines = 1)
        }
        status?.let {
            Text(
                it,
                style = MaterialTheme.typography.labelMedium,
                color = if (healthy) LocalBrandTones.current.live else MaterialTheme.colorScheme.error,
            )
        }
        Text(
            "The AI picks its own model by racing them on first run, and falls back to ranking on " +
                "the phone when none answer. Details go to Logcat, tag TasteRouteRanker.",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

''')

# ============================================================ MainActivity: the new graph
patch("MainActivity.kt", """import space.gexemy.tasteroute.ui.onboarding.TasteSetupScreen""",
      """import space.gexemy.tasteroute.ui.onboarding.TasteSetupScreen
import space.gexemy.tasteroute.ui.profile.FriendProfileScreen
import space.gexemy.tasteroute.ui.profile.FriendsScreen
import space.gexemy.tasteroute.ui.profile.ProfileScreen""")

patch("MainActivity.kt", """import space.gexemy.tasteroute.data.Recommender""",
      """import space.gexemy.tasteroute.data.Recommender
import space.gexemy.tasteroute.data.Social""")

patch("MainActivity.kt", """private const val ABOUT = "about\"""",
      """private const val ABOUT = "about"
private const val SETTINGS = "settings"
private const val FRIENDS = "friends"
private const val FRIEND = "friend\"""")

patch("MainActivity.kt", """                    composable(PROFILE) {
                        SettingsScreen(
                            onRetune = { nav.push(TASTE) },
                            onAccount = { nav.push(ACCOUNT) },
                            onAbout = { nav.push(ABOUT) },
                        )
                    }""",
      """                    composable(PROFILE) {
                        ProfileScreen(
                            onSettings = { nav.push(SETTINGS) },
                            onAccount = { nav.push(ACCOUNT) },
                            onRetune = { nav.push(TASTE) },
                            onFriends = { nav.push(FRIENDS) },
                            onOpenFriend = { id ->
                                Social.openFriendId = id
                                nav.push(FRIEND)
                            },
                        )
                    }""")

patch("MainActivity.kt", """                    pushScreen(ABOUT) {""",
      """                    pushScreen(SETTINGS) {
                        SettingsScreen(
                            onRetune = { nav.push(TASTE) },
                            onAccount = { nav.push(ACCOUNT) },
                            onAbout = { nav.push(ABOUT) },
                            onBack = { nav.popBackStack() },
                        )
                    }
                    pushScreen(FRIENDS) {
                        FriendsScreen(
                            onBack = { nav.popBackStack() },
                            onOpenFriend = { id ->
                                Social.openFriendId = id
                                nav.push(FRIEND)
                            },
                        )
                    }
                    pushScreen(FRIEND) {
                        FriendProfileScreen(Social.openFriendId, onBack = { nav.popBackStack() })
                    }
                    pushScreen(ABOUT) {""")

# Upgrade and allergen shortcuts pointed at the tab that is no longer a settings screen.
patch("MainActivity.kt", """                            onUpgrade = { nav.switchTab(PROFILE) },
                            onRetune = { nav.push(TASTE) },
                            onTableSync = { nav.push(TABLE_SYNC) },
                            onEditAllergens = { nav.switchTab(PROFILE) },""",
      """                            onUpgrade = { nav.push(SETTINGS) },
                            onRetune = { nav.push(TASTE) },
                            onTableSync = { nav.push(TABLE_SYNC) },
                            onEditAllergens = { nav.push(SETTINGS) },""")

# The route screen's upsell pointed at the same tab.
patch("MainActivity.kt", """                            onOpenPlace = { nav.navigate(DETAIL) },
                            onUpgrade = { nav.switchTab(PROFILE) },""",
      """                            onOpenPlace = { nav.navigate(DETAIL) },
                            onUpgrade = { nav.push(SETTINGS) },""")

if fails:
    print("FAILED")
    for f in fails:
        print("  -", f)
    sys.exit(1)
print("profile, settings, match score and hours all patched")
