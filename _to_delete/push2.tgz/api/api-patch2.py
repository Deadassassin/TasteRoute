#!/usr/bin/env python3
"""1.3.0 -> 1.4.0: social routes, the journal's visibility column, and the version bump.
Runs on top of api-patch.py, so package.json is at 1.3.0 when this starts."""
import os
import sys

ROOT = os.path.expanduser("~/apisrc/accounts-api")
fails = []


def patch(rel, old, new, count=1):
    p = os.path.join(ROOT, rel)
    s = open(p, encoding="utf-8").read()
    if s.count(old) != count:
        fails.append(f"{rel}: found {s.count(old)} :: {old.strip().splitlines()[0][:60]}")
        return
    open(p, "w", encoding="utf-8").write(s.replace(old, new))


patch("package.json", '"version": "1.3.0"', '"version": "1.4.0"')

# ---------------------------------------------------------------- index.js
patch("src/index.js", """import * as sourceRoutes from './routes/sources.js';""",
      """import * as social from './routes/social.js';
import * as sourceRoutes from './routes/sources.js';""")

patch("src/index.js", """  // Real dish names, harvested from a venue's own schema.org MenuItem markup, in facts.menu_items.
  // The app checks for this before it decides whether a dish line may say "On the menu".
  'menus',
];""",
      """  // Real dish names, harvested from a venue's own schema.org MenuItem markup, in facts.menu_items.
  // The app checks for this before it decides whether a dish line may say "On the menu".
  'menus',
  // Handles, mutual friend links, taste comparison, and the friends-only visit feed.
  'social',
];""")

patch("src/index.js", """  ['GET', '/v1/attributions', 'none', sourceRoutes.getAttributions],""",
      """  ['GET', '/v1/attributions', 'none', sourceRoutes.getAttributions],

  ['PUT', '/v1/me/handle', 'required', social.putHandle],
  ['GET', '/v1/friends', 'required', social.listFriends],
  ['POST', '/v1/friends', 'required', social.requestFriend],
  ['POST', '/v1/friends/:id/respond', 'required', social.respondFriend],
  ['DELETE', '/v1/friends/:id', 'required', social.removeFriend],
  ['GET', '/v1/friends/visits', 'required', social.friendFeed],
  ['GET', '/v1/friends/:userId', 'required', social.getFriend],""")

# ---------------------------------------------------------------- me.js
patch("src/routes/me.js", """export async function getMe(req, body, user) {
  const profile = await one('SELECT * FROM profiles WHERE user_id = $1', [user.id]);
  const favorites = await all('SELECT place_id, name FROM favorites WHERE user_id = $1 ORDER BY created_at DESC', [user.id]);
  return {
    id: user.id,
    email: user.email,
    display_name: user.display_name,""",
      """export async function getMe(req, body, user) {
  const profile = await one('SELECT * FROM profiles WHERE user_id = $1', [user.id]);
  const favorites = await all('SELECT place_id, name FROM favorites WHERE user_id = $1 ORDER BY created_at DESC', [user.id]);
  // The counts a profile screen puts under someone's name. Cheap enough to compute inline and
  // wrong enough to notice if they lag, so they are not cached anywhere.
  const stats = await one(
    `SELECT
       (SELECT count(*) FROM journal   WHERE user_id = $1)                       AS visits,
       (SELECT count(*) FROM journal   WHERE user_id = $1 AND visibility = 'friends') AS shared,
       (SELECT count(*) FROM reviews   WHERE user_id = $1)                       AS reviews,
       (SELECT count(*) FROM photos    WHERE user_id = $1)                       AS photos,
       (SELECT count(*) FROM checkins  WHERE user_id = $1)                       AS checkins,
       (SELECT count(*) FROM friend_links
         WHERE status = 'accepted' AND (requester_id = $1 OR addressee_id = $1))  AS friends,
       (SELECT count(*) FROM friend_links
         WHERE status = 'pending' AND addressee_id = $1)                          AS friend_requests`,
    [user.id],
  );
  const self = await one('SELECT handle, bio FROM users WHERE id = $1', [user.id]);
  return {
    id: user.id,
    email: user.email,
    display_name: user.display_name,
    handle: self?.handle ?? null,
    bio: self?.bio ?? '',
    stats: {
      visits: Number(stats?.visits ?? 0),
      shared: Number(stats?.shared ?? 0),
      reviews: Number(stats?.reviews ?? 0),
      photos: Number(stats?.photos ?? 0),
      checkins: Number(stats?.checkins ?? 0),
      friends: Number(stats?.friends ?? 0),
      friend_requests: Number(stats?.friend_requests ?? 0),
    },""")

patch("src/routes/me.js", """  const row = await one(
    `INSERT INTO journal (user_id, place_id, name, rating, note)
     VALUES ($1, $2, $3, $4, $5) RETURNING id, place_id, name, rating, note, visited_at`,
    [user.id, placeId, str(body.name, 200), body.rating == null ? null : int(body.rating, 1, 5, 5), str(body.note, 1000)],
  );
  return row;""",
      """  // 'friends' only when this one visit was explicitly marked shareable. Anything unrecognised —
  // including a client that predates this field — lands on 'private', which is the only default a
  // location log is allowed to have.
  const visibility = body.visibility === 'friends' ? 'friends' : 'private';
  const row = await one(
    `INSERT INTO journal (user_id, place_id, name, rating, note, visibility)
     VALUES ($1, $2, $3, $4, $5, $6)
     RETURNING id, place_id, name, rating, note, visibility, visited_at`,
    [
      user.id, placeId, str(body.name, 200),
      body.rating == null ? null : int(body.rating, 1, 5, 5),
      str(body.note, 1000), visibility,
    ],
  );
  return row;""")

patch("src/routes/me.js", """  return { entries: await all(
    'SELECT id, place_id, name, rating, note, visited_at FROM journal WHERE user_id = $1 ORDER BY visited_at DESC LIMIT 200',
    [user.id],
  ) };""",
      """  return { entries: await all(
    `SELECT id, place_id, name, rating, note, visibility, visited_at
     FROM journal WHERE user_id = $1 ORDER BY visited_at DESC LIMIT 200`,
    [user.id],
  ) };""")

if fails:
    print("FAILED")
    for f in fails:
        print("  -", f)
    sys.exit(1)
print("api patched to 1.4.0")
