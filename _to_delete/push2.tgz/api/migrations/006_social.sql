-- Social. Three additions and no new concepts: a handle so people can be found without handing out
-- an email address, a link table for friendships, and one column on the journal table that has
-- existed since 001 and was never used.

ALTER TABLE users ADD COLUMN IF NOT EXISTS handle TEXT;
ALTER TABLE users ADD COLUMN IF NOT EXISTS bio    TEXT NOT NULL DEFAULT '';
-- Case-insensitive and unique, but only over people who have actually claimed one: a partial index
-- lets every existing account keep a NULL handle without colliding with every other NULL.
CREATE UNIQUE INDEX IF NOT EXISTS users_handle_key ON users (lower(handle)) WHERE handle IS NOT NULL;

CREATE TABLE IF NOT EXISTS friend_links (
  id           BIGSERIAL PRIMARY KEY,
  requester_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  addressee_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status       TEXT NOT NULL DEFAULT 'pending',
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  responded_at TIMESTAMPTZ,
  CHECK (requester_id <> addressee_id),
  CHECK (status IN ('pending', 'accepted'))
);

-- One link per PAIR, whichever way round it was created. Without this, two people who each send
-- the other a request end up with two rows that disagree about who is waiting on whom, and both
-- see a pending request that accepting does not clear.
CREATE UNIQUE INDEX IF NOT EXISTS friend_links_pair
  ON friend_links (LEAST(requester_id, addressee_id), GREATEST(requester_id, addressee_id));
CREATE INDEX IF NOT EXISTS friend_links_addressee_idx ON friend_links (addressee_id, status);
CREATE INDEX IF NOT EXISTS friend_links_requester_idx ON friend_links (requester_id, status);

-- PRIVATE BY DEFAULT, and that default is the entire privacy design.
--
-- A visit is visible to someone else only if its owner chose 'friends' at the moment they logged
-- it. There is no bulk retroactive share, and deliberately no 'public' value: where a person eats
-- is not public information, and an app that quietly builds a movement history out of it has taken
-- something it was not given. Everything already logged stays private because the column defaults
-- that way — an existing journal cannot be exposed by shipping this migration.
ALTER TABLE journal ADD COLUMN IF NOT EXISTS visibility TEXT NOT NULL DEFAULT 'private';
CREATE INDEX IF NOT EXISTS journal_shared_idx
  ON journal (user_id, visited_at DESC) WHERE visibility = 'friends';
