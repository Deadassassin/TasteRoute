import { tasteOverlap, cleanHandle } from '../src/social.js';

let fail = 0;
const show = (name, got, check) => {
  const ok = check(got);
  if (!ok) fail++;
  console.log(`${ok ? 'ok  ' : 'BAD '} ${name} -> ${JSON.stringify(got)}`);
};

const A = { preferred_cuisines: ['Thai', 'Japanese', 'Mexican'], vibe_tags: ['Cozy', 'Casual'], dietary_restrictions: [], price_comfort: 2 };

show('identical taste scores high',
  tasteOverlap(A, A)?.score, (v) => v === 100);

show('nothing in common but both answered',
  tasteOverlap(A, { preferred_cuisines: ['French'], vibe_tags: ['Lively'], price_comfort: 4 })?.score,
  (v) => v >= 0 && v < 20);

show('partial overlap reads as a lot of common ground',
  tasteOverlap(A, { preferred_cuisines: ['Thai', 'Japanese', 'Korean'], vibe_tags: ['Cozy'], price_comfort: 2 })?.score,
  (v) => v >= 60 && v <= 90);

// The bug this file exists to avoid: blank optional fields must not read as disagreement.
const bare = { preferred_cuisines: ['Thai', 'Japanese', 'Mexican'] };
show('unanswered dimensions drop out, not score zero',
  tasteOverlap(bare, { preferred_cuisines: ['Thai', 'Japanese', 'Mexican'] })?.score, (v) => v === 100);

show('nothing to compare returns null',
  tasteOverlap({}, {}), (v) => v === null);

show('symmetric either way round',
  [tasteOverlap(A, bare)?.score, tasteOverlap(bare, A)?.score], (v) => v[0] === v[1]);

show('shared items are listed',
  tasteOverlap(A, { preferred_cuisines: ['thai', 'french'] })?.shared.cuisines, (v) => JSON.stringify(v) === '["thai"]');

show('only_theirs is what to try',
  tasteOverlap(A, { preferred_cuisines: ['Thai', 'Ethiopian'] })?.only_theirs.cuisines,
  (v) => JSON.stringify(v) === '["ethiopian"]');

show('allergens never appear in the result',
  JSON.stringify(tasteOverlap({ ...A, allergens: ['Peanuts'] }, A)), (v) => !v.toLowerCase().includes('peanut'));

for (const [raw, want] of [['Macy', 'macy'], ['@Macy_99', 'macy_99'], ['ab', null], ['a'.repeat(21), null], ['has space', null], ['', null], [null, null], ['Ünicode', null]]) {
  show(`handle ${JSON.stringify(raw)}`, cleanHandle(raw), (v) => v === want);
}

console.log(fail ? `\n${fail} failure(s)` : '\nall social cases pass');
process.exit(fail ? 1 : 0);
