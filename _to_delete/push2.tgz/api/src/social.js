/**
 * How alike two people's taste is, as a number they will both see.
 *
 * The rule that shapes all of this: A DIMENSION NOBODY ANSWERED IS NOT A DISAGREEMENT. If neither
 * of you has set any vibes, "vibes" must drop out of the average entirely rather than score 0 or
 * a neutral 0.5 — otherwise two people with identical, strongly-stated cuisine taste are told they
 * are a 40% match because they both left three optional fields blank. That was exactly the bug in
 * the app's own restaurant match score, and it is the same bug here.
 *
 * Returns null when there is genuinely nothing to compare, so the UI can say "not enough to go on"
 * instead of printing a confident 0%.
 */

const WEIGHTS = { cuisines: 0.45, vibes: 0.25, diets: 0.15, price: 0.15 };

const norm = (list) => [
  ...new Set((Array.isArray(list) ? list : []).map((v) => String(v).trim().toLowerCase()).filter(Boolean)),
];

/**
 * Overlap over union. Deliberately NOT "how many of mine do you have": that is asymmetric, and a
 * comparison two people are both looking at has to read the same from either side.
 */
function jaccard(a, b) {
  if (!a.length && !b.length) return null;
  const setB = new Set(b);
  const shared = a.filter((v) => setB.has(v));
  const union = new Set([...a, ...b]).size;
  return { value: union ? shared.length / union : null, shared };
}

function priceCloseness(a, b) {
  const x = Number(a), y = Number(b);
  if (!Number.isFinite(x) || !Number.isFinite(y) || x < 1 || y < 1) return null;
  // 1..4, so the worst possible gap is 3.
  return 1 - Math.min(1, Math.abs(x - y) / 3);
}

export function tasteOverlap(a = {}, b = {}) {
  const mine = {
    cuisines: norm(a.preferred_cuisines ?? a.cuisines),
    vibes: norm(a.vibe_tags ?? a.vibes),
    diets: norm(a.dietary_restrictions ?? a.diets),
  };
  const theirs = {
    cuisines: norm(b.preferred_cuisines ?? b.cuisines),
    vibes: norm(b.vibe_tags ?? b.vibes),
    diets: norm(b.dietary_restrictions ?? b.diets),
  };

  const parts = {
    cuisines: jaccard(mine.cuisines, theirs.cuisines),
    vibes: jaccard(mine.vibes, theirs.vibes),
    diets: jaccard(mine.diets, theirs.diets),
  };
  const price = priceCloseness(a.price_comfort, b.price_comfort);

  let weighted = 0;
  let weight = 0;
  for (const [key, part] of Object.entries(parts)) {
    if (!part || part.value == null) continue;
    weighted += WEIGHTS[key] * part.value;
    weight += WEIGHTS[key];
  }
  if (price != null) {
    weighted += WEIGHTS.price * price;
    weight += WEIGHTS.price;
  }
  if (!weight) return null;

  // Renormalised over what was actually answered, then eased. Raw Jaccard is a harsh scale for
  // something a person reads as "how alike are we" — sharing three of five cuisines is a lot of
  // common ground and scores 0.43 flat. The curve is monotonic, so it never reorders anybody.
  const raw = weighted / weight;
  const score = Math.round(100 * Math.pow(raw, 0.7));

  return {
    score,
    weight_answered: Number(weight.toFixed(2)),
    shared: {
      cuisines: parts.cuisines?.shared ?? [],
      vibes: parts.vibes?.shared ?? [],
      diets: parts.diets?.shared ?? [],
    },
    // What each of you likes that the other has not said they do — the useful half of a comparison,
    // because it is the part that turns into "you should try".
    only_theirs: {
      cuisines: theirs.cuisines.filter((v) => !mine.cuisines.includes(v)),
      vibes: theirs.vibes.filter((v) => !mine.vibes.includes(v)),
    },
    only_mine: {
      cuisines: mine.cuisines.filter((v) => !theirs.cuisines.includes(v)),
      vibes: mine.vibes.filter((v) => !theirs.vibes.includes(v)),
    },
  };
}

/** a-z, 0-9 and underscore, 3-20 chars. Rejected rather than silently mangled. */
export function cleanHandle(raw) {
  const handle = String(raw ?? '').trim().replace(/^@/, '').toLowerCase();
  return /^[a-z0-9_]{3,20}$/.test(handle) ? handle : null;
}
