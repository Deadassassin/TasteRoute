import { all, one, query } from '../db.js';
import { HttpError, int, str } from '../http.js';
import { limit } from '../ratelimit.js';
import { cleanHandle, tasteOverlap } from '../social.js';

/**
 * Friends, and the two things friends are for here: comparing taste, and seeing where somebody
 * actually ate.
 *
 * THE PRIVACY SHAPE, because every handler below depends on it:
 *  - You are found by a handle you chose, never by email, phone number or an uploaded contact list.
 *  - A friendship is mutual and requires an accept. There is no "follow".
 *  - A visit is private unless its owner marked that single visit 'friends' when they logged it.
 *    Nothing here can change the visibility of a visit in bulk, and there is no 'public' value.
 *  - Taste is shared with accepted friends only, and only the parts the app already treats as
 *    preferences. Allergens are NEVER returned to another user: that is health information, and
 *    it is not what anybody meant by comparing food taste.
 */

const FEED_LIMIT = 60;

/** Everything another person is allowed to see about you, in one place so it cannot drift. */
const PUBLIC_USER = `u.id, u.handle, u.display_name, u.bio`;

const shapeUser = (row) => ({
  id: row.id,
  handle: row.handle ?? null,
  display_name: row.display_name ?? '',
  bio: row.bio ?? '',
});

async function friendIdsOf(userId) {
  const rows = await all(
    `SELECT CASE WHEN requester_id = $1 THEN addressee_id ELSE requester_id END AS id
     FROM friend_links
     WHERE status = 'accepted' AND (requester_id = $1 OR addressee_id = $1)`,
    [userId],
  );
  return rows.map((r) => Number(r.id));
}

async function assertFriends(userId, otherId) {
  const link = await one(
    `SELECT 1 FROM friend_links
     WHERE status = 'accepted'
       AND ((requester_id = $1 AND addressee_id = $2) OR (requester_id = $2 AND addressee_id = $1))`,
    [userId, otherId],
  );
  if (!link) throw new HttpError(403, 'not_friends');
}

/** Your own handle and bio. A handle is optional — an account without one simply cannot be found. */
export async function putHandle(req, body, user) {
  limit(`handle:${user.id}`, 10, 60 * 60_000);
  const raw = body.handle;
  let handle = null;
  if (raw != null && String(raw).trim() !== '') {
    handle = cleanHandle(raw);
    if (!handle) throw new HttpError(400, 'handle_invalid');
  }
  try {
    await query('UPDATE users SET handle = $2, bio = $3 WHERE id = $1', [user.id, handle, str(body.bio, 280)]);
  } catch (e) {
    // The partial unique index is the only thing that can fail here.
    if (String(e?.code) === '23505') throw new HttpError(409, 'handle_taken');
    throw e;
  }
  return { ok: true, handle, bio: str(body.bio, 280) };
}

/**
 * Accepted friends, plus requests in both directions.
 *
 * Incoming and outgoing are separated because they need different buttons, and a single "pending"
 * list where you cannot tell which ones are waiting on YOU is the reason friend requests get
 * ignored in every app that ships one.
 */
export async function listFriends(req, body, user) {
  const rows = await all(
    `SELECT f.id, f.status, f.requester_id, f.addressee_id, f.created_at, ${PUBLIC_USER}
     FROM friend_links f
     JOIN users u ON u.id = CASE WHEN f.requester_id = $1 THEN f.addressee_id ELSE f.requester_id END
     WHERE f.requester_id = $1 OR f.addressee_id = $1
     ORDER BY f.created_at DESC`,
    [user.id],
  );
  const friends = [], incoming = [], outgoing = [];
  for (const row of rows) {
    const entry = { link_id: Number(row.id), user: shapeUser(row), since: row.created_at };
    if (row.status === 'accepted') friends.push(entry);
    else if (Number(row.addressee_id) === Number(user.id)) incoming.push(entry);
    else outgoing.push(entry);
  }
  return { friends, incoming, outgoing };
}

export async function requestFriend(req, body, user) {
  limit(`friendreq:${user.id}`, 30, 60 * 60_000);
  const handle = cleanHandle(body.handle);
  if (!handle) throw new HttpError(400, 'handle_invalid');
  const target = await one('SELECT id FROM users WHERE lower(handle) = $1 AND disabled_at IS NULL', [handle]);
  if (!target) throw new HttpError(404, 'no_such_handle');
  if (Number(target.id) === Number(user.id)) throw new HttpError(400, 'thats_you');

  // If they already asked you, asking back is an accept. Anything else here is a dead end where
  // two people stare at each other's pending requests forever.
  const existing = await one(
    `SELECT id, status, requester_id FROM friend_links
     WHERE (requester_id = $1 AND addressee_id = $2) OR (requester_id = $2 AND addressee_id = $1)`,
    [user.id, target.id],
  );
  if (existing) {
    if (existing.status === 'accepted') return { ok: true, status: 'accepted' };
    if (Number(existing.requester_id) !== Number(user.id)) {
      await query(`UPDATE friend_links SET status = 'accepted', responded_at = now() WHERE id = $1`, [existing.id]);
      return { ok: true, status: 'accepted' };
    }
    return { ok: true, status: 'pending' };
  }

  await query('INSERT INTO friend_links (requester_id, addressee_id) VALUES ($1, $2)', [user.id, target.id]);
  return { ok: true, status: 'pending' };
}

export async function respondFriend(req, body, user, params) {
  const id = int(params.id, 1, Number.MAX_SAFE_INTEGER, 0);
  const link = await one('SELECT id, addressee_id, status FROM friend_links WHERE id = $1', [id]);
  // Only the person who was asked can accept, and saying so with a 404 rather than a 403 avoids
  // confirming that a link id exists to somebody who has nothing to do with it.
  if (!link || Number(link.addressee_id) !== Number(user.id)) throw new HttpError(404, 'no_such_request');
  if (body.accept === false) {
    await query('DELETE FROM friend_links WHERE id = $1', [id]);
    return { ok: true, status: 'declined' };
  }
  await query(`UPDATE friend_links SET status = 'accepted', responded_at = now() WHERE id = $1`, [id]);
  return { ok: true, status: 'accepted' };
}

export async function removeFriend(req, body, user, params) {
  const id = int(params.id, 1, Number.MAX_SAFE_INTEGER, 0);
  await query('DELETE FROM friend_links WHERE id = $1 AND (requester_id = $2 OR addressee_id = $2)', [id, user.id]);
  return { ok: true };
}

/**
 * One friend: who they are, how alike your taste is, and the visits they chose to share.
 *
 * Note what is not in the SELECT — email, allergens, favourites, and any visit that is still
 * 'private'. A friend screen that quietly widens as the schema grows is how this kind of feature
 * leaks, so the columns are named explicitly and the visibility filter is in the WHERE clause
 * rather than applied afterwards in JavaScript.
 */
export async function getFriend(req, body, user, params) {
  const otherId = int(params.userId, 1, Number.MAX_SAFE_INTEGER, 0);
  await assertFriends(user.id, otherId);

  const person = await one(`SELECT ${PUBLIC_USER} FROM users u WHERE u.id = $1`, [otherId]);
  if (!person) throw new HttpError(404, 'no_such_user');

  const mine = await one('SELECT taste FROM profiles WHERE user_id = $1', [user.id]);
  const theirs = await one('SELECT taste FROM profiles WHERE user_id = $1', [otherId]);
  const visits = await all(
    `SELECT id, place_id, name, rating, note, visited_at FROM journal
     WHERE user_id = $1 AND visibility = 'friends'
     ORDER BY visited_at DESC LIMIT $2`,
    [otherId, FEED_LIMIT],
  );

  return {
    user: shapeUser(person),
    taste: theirs?.taste ?? {},
    overlap: tasteOverlap(mine?.taste ?? {}, theirs?.taste ?? {}),
    visits,
  };
}

/** Everything your friends chose to share, newest first. Nothing else can reach this query. */
export async function friendFeed(req, body, user) {
  const ids = await friendIdsOf(user.id);
  if (!ids.length) return { visits: [] };
  const rows = await all(
    `SELECT j.id, j.place_id, j.name, j.rating, j.note, j.visited_at, ${PUBLIC_USER}
     FROM journal j JOIN users u ON u.id = j.user_id
     WHERE j.user_id = ANY($1::bigint[]) AND j.visibility = 'friends'
     ORDER BY j.visited_at DESC LIMIT $2`,
    [ids, FEED_LIMIT],
  );
  return {
    visits: rows.map((r) => ({
      id: Number(r.id),
      place_id: r.place_id,
      name: r.name,
      rating: r.rating,
      note: r.note,
      visited_at: r.visited_at,
      by: shapeUser(r),
    })),
  };
}
